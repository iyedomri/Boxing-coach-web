#!/usr/bin/env python3
"""Build the public static homepage for Vercel without publishing private dashboards."""
import pathlib
import shutil
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parent
OUTPUT = ROOT / "vercel-static"

subprocess.run([sys.executable, str(ROOT / "build.py")], cwd=ROOT, check=True)

if OUTPUT.exists():
    shutil.rmtree(OUTPUT)
OUTPUT.mkdir(parents=True)
shutil.copy2(ROOT / "index.html", OUTPUT / "index.html")

# The function needs these templates, but they must not be in the public output.
for name in ("admin.html", "login.html", "owner.html"):
    if not (ROOT / name).is_file():
        raise SystemExit("Missing function template: " + name)

public_files = sorted(path.name for path in OUTPUT.iterdir() if path.is_file())
if public_files != ["index.html"]:
    raise SystemExit("Unsafe Vercel static output; only index.html may be public")
print("Vercel static output: only index.html (private pages stay behind the function)")

"""API isolation regressions for the member portal.

These tests invoke the HTTP handler over socketpair connections; they do not bind
or start a listening web server. Runtime state and signing keys live in a temp dir.
Run from the project root with: python3 -m unittest discover -s tests
"""
import importlib.util
import hashlib
import json
import os
import pathlib
import re
import socket
import tempfile
import threading
import unittest


ROOT = pathlib.Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("kilani_server_under_test", ROOT / "server.py")
server = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(server)


class QuietHandler(server.Handler):
    def log_message(self, *_args):
        pass


class DummyServer:
    pass


class MemberAPITest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.old_state_file = server.STATE_FILE
        self.old_secret_file = server.SECRET_FILE
        self.old_storage_backend = server.STORAGE_BACKEND
        self.old_member_pepper_env = os.environ.get("MEMBER_CODE_PEPPER")
        os.environ["MEMBER_CODE_PEPPER"] = "test-only-pepper-key-with-more-than-32-bytes"
        server.STORAGE_BACKEND = "file"
        server.STATE_FILE = pathlib.Path(self.tmp.name) / "state.json"
        server.SECRET_FILE = pathlib.Path(self.tmp.name) / ".session_secret"
        server._attempts.clear()
        server._member_attempts.clear()

        self.member = {
            "id": "member-a", "name": "Member A", "phone": "private phone",
            "goal": "Fat loss", "planId": "p4", "planName": "Starter",
            "mode": "private", "sessionsTotal": 4, "sessionsUsed": 1,
            "start": "2026-10-01", "end": "2026-11-01", "price": 180,
            "paid": True, "note": "COACH-ONLY NOTE",
            "memberView": {
                "note": "MEMBER MESSAGE", "programMonth": "October",
                "programText": "PRIVATE PROGRAM TEXT",
                "visibility": {
                    "showMembership": False, "showProgram": False,
                    "showNutrition": False, "showSessions": False,
                    "showBilling": False, "showOffers": False,
                    "showNote": False, "showProgress": False,
                },
                "nutrition": {"kcal": 2000, "protein": 150},
            },
            "progress": [{
                "date": "2026-10-20", "weight": 70, "waist": 80,
                "bodyFat": 18, "note": "COACH-ONLY PROGRESS NOTE",
            }],
        }
        self.other = {
            "id": "member-b", "name": "Other Member", "note": "OTHER MEMBER PRIVATE NOTE",
            "sessionsTotal": 8, "sessionsUsed": 2,
            "start": "2026-10-01", "end": "2026-11-01", "progress": [],
        }
        state = server._new_state()
        state["roster"] = json.dumps([self.member, self.other])
        state["plans"] = json.dumps({"Fat loss": {"month": "October"}})
        state["offers"] = json.dumps({"plans": {}, "addons": []})
        state["memberAccess"] = {
            "member-a": server.make_member_code_hash("member-a", "12345678"),
            "member-b": server.make_member_code_hash("member-b", "87654321"),
        }
        server.save_state(state)

    def tearDown(self):
        server.STATE_FILE = self.old_state_file
        server.SECRET_FILE = self.old_secret_file
        server.STORAGE_BACKEND = self.old_storage_backend
        if self.old_member_pepper_env is None:
            os.environ.pop("MEMBER_CODE_PEPPER", None)
        else:
            os.environ["MEMBER_CODE_PEPPER"] = self.old_member_pepper_env
        self.tmp.cleanup()

    def request(self, method, path, body=None, cookie=None, extra_headers=None):
        handler_sock, client_sock = socket.socketpair()
        client_sock.settimeout(3)
        payload = "" if body is None else (body if isinstance(body, str) else json.dumps(body))
        request = (
            f"{method} {path} HTTP/1.1\r\n"
            "Host: localhost\r\n"
            "Connection: close\r\n"
        )
        for key, value in (extra_headers or {}).items():
            request += f"{key}: {value}\r\n"
        if payload:
            request += (
                "Content-Type: application/json\r\n"
                f"Content-Length: {len(payload.encode())}\r\n"
            )
        if cookie:
            request += f"Cookie: {cookie}\r\n"
        client_sock.sendall((request + "\r\n" + payload).encode())

        def run_handler():
            try:
                QuietHandler(handler_sock, ("127.0.0.1", 45678), DummyServer())
            finally:
                handler_sock.close()

        thread = threading.Thread(target=run_handler, daemon=True)
        thread.start()
        chunks = []
        try:
            while True:
                chunk = client_sock.recv(65536)
                if not chunk:
                    break
                chunks.append(chunk)
        except socket.timeout as exc:
            self.fail(f"HTTP handler did not close its response: {exc}")
        finally:
            client_sock.close()
        thread.join(timeout=3)
        raw = b"".join(chunks).decode("latin1")
        headers, separator, response = raw.partition("\r\n\r\n")
        self.assertTrue(separator, f"No HTTP response received: {raw!r}")
        status = int(headers.splitlines()[0].split()[1])
        return status, headers, response

    @staticmethod
    def cookie_from(headers):
        match = re.search(r"Set-Cookie: ([^;]+)", headers, re.IGNORECASE)
        if not match:
            raise AssertionError("Expected Set-Cookie header")
        return match.group(1)

    def member_login(self, code="12345678"):
        status, headers, body = self.request("POST", "/api/member/login", {"code": code})
        self.assertEqual(status, 200, body)
        return self.cookie_from(headers), json.loads(body)["member"]

    def test_member_payload_is_self_only_and_respects_visibility(self):
        self.assertEqual(self.request("GET", "/api/member/me")[0], 401)
        status, headers, body = self.request(
            "POST", "/api/member/login", {"code": "12345678"}
        )
        self.assertEqual(status, 200, body)
        self.assertIn("HttpOnly", headers)
        self.assertIn("SameSite=Lax", headers)
        member = json.loads(body)["member"]
        self.assertEqual(member["id"], "member-a")
        self.assertEqual((member["start"], member["end"]), ("2026-10-01", "2026-11-01"))
        self.assertEqual(member["planName"], "")
        self.assertEqual(member["mode"], "")
        self.assertEqual(member["sessionsTotal"], 0)
        self.assertEqual(member["sessionsUsed"], 0)
        self.assertEqual(member["price"], 0)
        self.assertIsNone(member["paid"])
        self.assertEqual(member["memberView"]["note"], "")
        self.assertEqual(member["memberView"]["programText"], "")
        self.assertEqual(member["memberView"]["nutrition"], {})
        self.assertEqual(member["progress"], [])
        for private_text in (
            "Other Member", "COACH-ONLY NOTE", "OTHER MEMBER PRIVATE NOTE",
            "PRIVATE PROGRAM TEXT", "MEMBER MESSAGE", "COACH-ONLY PROGRESS NOTE",
            "private phone", "memberAccess",
        ):
            self.assertNotIn(private_text, body)

    def test_checkin_requires_enabled_sessions_and_updates_only_self(self):
        cookie, _ = self.member_login()
        self.assertEqual(
            self.request("POST", "/api/member/checkin", {"sessionsUsed": 2}, cookie)[0], 403
        )
        self.assertEqual(self.request("POST", "/api/member/checkin", {"sessionsUsed": 2})[0], 401)

        state = server.load_state()
        roster = json.loads(state["roster"])
        roster[0]["memberView"]["visibility"]["showSessions"] = True
        state["roster"] = json.dumps(roster)
        server.save_state(state)
        status, _, body = self.request(
            "POST", "/api/member/checkin", {"sessionsUsed": 3}, cookie
        )
        self.assertEqual(status, 200, body)
        self.assertEqual(json.loads(body)["sessionsUsed"], 3)
        saved = json.loads(server.STATE_FILE.read_text())
        roster = json.loads(saved["roster"])
        self.assertEqual(roster[0]["sessionsUsed"], 3)
        self.assertEqual(roster[1]["sessionsUsed"], 2)

    def test_code_reset_revokes_session_and_duplicate_codes_are_rejected(self):
        old_cookie, _ = self.member_login()
        self.assertEqual(
            self.request("POST", "/api/member/access", {
                "memberId": "member-a", "code": "23456789",
            })[0], 401
        )
        coach_cookie = "kilani_coach=" + server.make_token()
        status, _, _ = self.request("POST", "/api/member/access", {
            "memberId": "member-a", "code": "23456789",
        }, coach_cookie)
        self.assertEqual(status, 200)
        self.assertEqual(self.request("GET", "/api/member/me", cookie=old_cookie)[0], 401)
        self.assertEqual(
            self.request("POST", "/api/member/access", {
                "memberId": "member-b", "code": "23456789",
            }, coach_cookie)[0], 409
        )
        new_cookie, member = self.member_login("23456789")
        self.assertEqual(member["id"], "member-a")
        self.assertEqual(self.request("GET", "/api/member/me", cookie=new_cookie)[0], 200)

    def test_coach_login_upgrades_legacy_pin_hash(self):
        salt = "legacy-pin-salt"
        old_hash = "sha256$%s$%s" % (
            salt, hashlib.sha256((salt + ":19595555:coach").encode()).hexdigest()
        )
        state = server.load_state()
        state["pin"] = old_hash
        server.save_state(state)
        status, headers, _ = self.request("POST", "/login", "pin=19595555")
        self.assertEqual(status, 303)
        upgraded = server.load_state()["pin"]
        self.assertTrue(upgraded.startswith("pbkdf2$"))
        cookie_value = self.cookie_from(headers).split("=", 1)[1]
        self.assertTrue(server.token_ok(cookie_value))

    def test_member_login_upgrades_legacy_access_hash(self):
        salt = "legacy-member-salt"
        old_hash = "sha256$%s$%s" % (
            salt, hashlib.sha256((salt + ":member-a:12345678:member").encode()).hexdigest()
        )
        state = server.load_state()
        state["memberAccess"]["member-a"] = old_hash
        server.save_state(state)
        cookie, member = self.member_login("12345678")
        self.assertEqual(member["id"], "member-a")
        upgraded = server.load_state()["memberAccess"]["member-a"]
        self.assertTrue(upgraded.startswith("pbkdf2$"))
        self.assertTrue(server.member_code_lookup_value(upgraded))
        self.assertEqual(self.request("GET", "/api/member/me", cookie=cookie)[0], 200)

    def test_forwarded_client_ip_is_used_only_from_configured_proxy(self):
        old_trusted_proxies = os.environ.get("TRUSTED_PROXY_IPS")
        try:
            server._member_attempts.clear()
            os.environ["TRUSTED_PROXY_IPS"] = "127.0.0.1"
            status, _, _ = self.request(
                "POST", "/api/member/login", {"code": "99999999"},
                extra_headers={"X-Forwarded-For": "203.0.113.77"},
            )
            self.assertEqual(status, 401)
            self.assertIn("203.0.113.77", server._member_attempts)

            server._member_attempts.clear()
            os.environ.pop("TRUSTED_PROXY_IPS", None)
            status, _, _ = self.request(
                "POST", "/api/member/login", {"code": "99999999"},
                extra_headers={"X-Forwarded-For": "203.0.113.88"},
            )
            self.assertEqual(status, 401)
            self.assertIn("127.0.0.1", server._member_attempts)
            self.assertNotIn("203.0.113.88", server._member_attempts)
        finally:
            server._member_attempts.clear()
            if old_trusted_proxies is None:
                os.environ.pop("TRUSTED_PROXY_IPS", None)
            else:
                os.environ["TRUSTED_PROXY_IPS"] = old_trusted_proxies

    def test_request_security_guards_and_response_headers(self):
        status, _, body = self.request(
            "POST", "/api/member/login", {"code": "12345678"},
            extra_headers={"Origin": "https://attacker.example", "Sec-Fetch-Site": "cross-site"},
        )
        self.assertEqual(status, 403, body)
        status, _, body = self.request("POST", "/api/member/login", [])
        self.assertEqual(status, 400, body)
        status, _, body = self.request(
            "POST", "/api/member/login", extra_headers={
                "Content-Length": str(server.MAX_REQUEST_BODY + 1),
            },
        )
        self.assertEqual(status, 413, body)
        status, headers, _ = self.request("GET", "/healthz")
        self.assertEqual(status, 200)
        self.assertIn("Content-Security-Policy", headers)
        self.assertIn("X-Content-Type-Options: nosniff", headers)
        self.assertIn("Cache-Control: no-store", headers)
        status, _, _ = self.request(
            "POST", "/api/member/logout", extra_headers={"Origin": "http://localhost"}
        )
        self.assertEqual(status, 200)
        status, secure_headers, _ = self.request(
            "POST", "/api/member/logout", extra_headers={
                "Origin": "https://localhost", "X-Forwarded-Proto": "https, http",
            }
        )
        self.assertEqual(status, 200)
        self.assertIn("Set-Cookie:", secure_headers)
        self.assertIn("; Secure", secure_headers)
        self.assertIn("Strict-Transport-Security:", secure_headers)

    def test_public_api_is_limited_and_private_state_is_not_served(self):
        self.assertEqual(self.request("GET", "/api/state")[0], 401)
        status, _, body = self.request("GET", "/api/public-plan")
        self.assertEqual(status, 200)
        self.assertEqual(set(json.loads(body)), {"plans", "offers"})
        self.assertNotIn("Member A", body)
        self.assertNotIn("memberAccess", body)
        self.assertEqual(self.request("GET", "/state.json")[0], 404)


if __name__ == "__main__":
    unittest.main()

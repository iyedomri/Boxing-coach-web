#!/usr/bin/env python3
"""
KILANI — Boxing Club server (MySQL storage by default; optional JSON demo mode).

What it does that the static demo can't:

  * /                → public website (index.html)
  * /admin.html      → coach dashboard, ONLY after a real server-side login
  * /login           → password page (PIN checked on the server, not in the browser)
  * /logout          → clears the session
  * /api/state       → GET (auth required) / POST (auth required) shared JSON state
                       → roster, payments, plans and notes sync across his devices

Security notes
  * MySQL is the default store. The coach PIN and member access codes are saved as
    salted hashes; roster, progress, programs, offers and payments use private tables.
  * STORAGE_BACKEND=file is available only for a local JSON-file demo/migration.
  * Session cookie is HttpOnly + SameSite=Lax, value signed with HMAC-SHA256.
  * Login is rate-limited: 5 wrong attempts → 60 s lockout per IP.
  * The dashboard HTML is never sent to an unauthenticated client.

Run: set MySQL environment variables, then python3 server.py (PORT=8080 by default).
If the MySQL tables are empty, an existing state.json is imported once; otherwise a
new database is initialized with demo PIN 16976614. Change the PIN in Settings.
"""

import base64
import hashlib
import hmac
import http.cookies
import ipaddress
import json
import os
import pathlib
import re
import secrets
import sys
import threading
import time
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

ROOT = pathlib.Path(__file__).parent
STATE_FILE = ROOT / "state.json"
SECRET_FILE = ROOT / ".session_secret"
MEMBER_CODE_PEPPER_FILE = ROOT / ".member_code_pepper"

PORT = int(os.environ.get("PORT", "8080"))
HOST = "0.0.0.0"
STORAGE_BACKEND = os.environ.get("STORAGE_BACKEND", "mysql").strip().lower()

DEFAULT_PIN = "16976614"  # local demo only; Vercel requires COACH_INITIAL_PIN for first DB init
LOCKOUT_AFTER = 5
LOCKOUT_SECONDS = 60
PBKDF2_ITERATIONS = 310_000
MAX_HASH_ITERATIONS = 1_000_000
# Vercel Functions have a 4.5 MB request/response cap; leave headroom for framing.
MAX_REQUEST_BODY = 4 * 1024 * 1024
SESSION_AGE = 60 * 60 * 12          # 12 h
COOKIE = "kilani_coach"
MEMBER_COOKIE = "kilani_member"
OWNER_COOKIE = "kilani_owner"
MEMBER_SESSION_AGE = 60 * 60 * 24 * 7   # 7 days
OWNER_SESSION_AGE = 60 * 60 * 4         # 4 hours
OWNER_GRANT_SECONDS = 30 * 60           # creator-selected 30-minute support grant
OWNER_AUDIT_LIMIT = 100
OWNER_REQUEST_LIMIT = 50
OWNER_SCOPES = {"site_controls", "payment_status"}

_lock = threading.Lock()
_attempts = {}                      # coach IP -> [fails, locked_until]
_member_attempts = {}               # member IP -> [fails, locked_until]
_owner_attempts = {}                # owner IP -> [fails, locked_until]


def _running_on_vercel():
    return os.environ.get("VERCEL", "").strip() == "1"


def _initial_coach_pin():
    """Never seed a production Vercel database with the public demo PIN."""
    if _running_on_vercel():
        pin = os.environ.get("COACH_INITIAL_PIN", "").strip()
        if not re.fullmatch(r"[0-9]{8,10}", pin):
            raise RuntimeError(
                "Set COACH_INITIAL_PIN (8–10 digits) in Vercel before initializing an empty database. "
                "Remove it after the coach has changed the PIN in Settings."
            )
        return pin
    return DEFAULT_PIN


# ----------------------------------------------------------------- state ---
def _new_state():
    return {
        "pin": hash_pin(_initial_coach_pin()),  # versioned PBKDF2 hash
        "roster": "",
        "payments": "",
        "plans": "",
        "notes": "",
        "offers": "",
        "memberAccess": {},
        "ownerControl": _new_owner_control(),
    }


def _new_owner_control():
    # Payment/booking features start paused: neither D17 checkout nor live booking
    # has been integrated. The owner may configure operational switches later.
    return {
        "settings": {
            "maintenanceMode": False,
            "paymentsPaused": True,
            "bookingsPaused": True,
            "payoutLabel": "Managed securely in D17 merchant tools",
        },
        "requests": [],
        "audit": [],
    }


def _normalize_owner_control(owner):
    if not isinstance(owner, dict):
        return _new_owner_control()
    defaults = _new_owner_control()
    settings = owner.get("settings")
    if not isinstance(settings, dict):
        settings = defaults["settings"]
    else:
        settings = dict(settings)
        for key, value in defaults["settings"].items():
            if key not in settings:
                settings[key] = value
        for key in ("maintenanceMode", "paymentsPaused", "bookingsPaused"):
            if not isinstance(settings.get(key), bool):
                settings[key] = defaults["settings"][key]
        settings["payoutLabel"] = str(settings.get("payoutLabel") or "")[:80]
    requests = owner.get("requests") if isinstance(owner.get("requests"), list) else []
    audit = owner.get("audit") if isinstance(owner.get("audit"), list) else []
    return {
        "settings": settings,
        "requests": [item for item in requests if isinstance(item, dict)][-OWNER_REQUEST_LIMIT:],
        "audit": [item for item in audit if isinstance(item, dict)][-OWNER_AUDIT_LIMIT:],
    }


def _derive_hash(material, salt, iterations=PBKDF2_ITERATIONS):
    return hashlib.pbkdf2_hmac(
        "sha256", material.encode("utf-8"), bytes.fromhex(salt), iterations
    ).hex()


def hash_pin(pin, salt=None):
    salt = salt or secrets.token_hex(16)
    material = salt + ":" + pin + ":coach"
    digest = _derive_hash(material, salt)
    return "pbkdf2$%d$%s$%s" % (PBKDF2_ITERATIONS, salt, digest)


def verify_pin(pin, stored):
    if not isinstance(stored, str):
        return False
    try:
        if stored.startswith("sha256$"):
            _, salt, expected = stored.split("$", 2)
            actual = hashlib.sha256((salt + ":" + pin + ":coach").encode()).hexdigest()
        else:
            scheme, rounds, salt, expected = stored.split("$", 3)
            iterations = int(rounds)
            if scheme != "pbkdf2" or not (1_000 <= iterations <= MAX_HASH_ITERATIONS):
                return False
            actual = _derive_hash(salt + ":" + pin + ":coach", salt, iterations)
        return hmac.compare_digest(actual, expected)
    except (ValueError, TypeError):
        return False


def pin_needs_rehash(stored):
    try:
        scheme, rounds, _salt, _digest = stored.split("$", 3)
        return scheme != "pbkdf2" or int(rounds) < PBKDF2_ITERATIONS
    except (AttributeError, ValueError):
        return True

def _merge_state_defaults(current):
    if not isinstance(current, dict):
        current = {}
    changed = False
    defaults = {
        "roster": "", "payments": "", "plans": "", "notes": "",
        "offers": "", "memberAccess": {},
    }
    if "pin" not in current:
        current["pin"] = hash_pin(DEFAULT_PIN)
        changed = True
    for key, value in defaults.items():
        if key not in current:
            current[key] = value
            changed = True
    if not isinstance(current.get("memberAccess"), dict):
        current["memberAccess"] = {}
        changed = True
    original_owner = current.get("ownerControl")
    normalized_owner = _normalize_owner_control(original_owner)
    if original_owner != normalized_owner:
        changed = True
    current["ownerControl"] = normalized_owner
    return current, changed


def _load_legacy_state():
    """Read an existing JSON store for one-time migration into MySQL."""
    if not STATE_FILE.exists():
        return _new_state()
    try:
        current = json.loads(STATE_FILE.read_text(encoding="utf-8"))
    except Exception:
        return _new_state()
    current, _ = _merge_state_defaults(current)
    return current


def _load_file_state():
    with _lock:
        if not STATE_FILE.exists():
            STATE_FILE.write_text(json.dumps(_new_state(), indent=2), encoding="utf-8")
            print("· created state.json (demo PIN %s)" % DEFAULT_PIN)
        try:
            os.chmod(STATE_FILE, 0o600)
        except Exception:
            pass
        try:
            current = json.loads(STATE_FILE.read_text(encoding="utf-8"))
            current, changed = _merge_state_defaults(current)
            if changed:
                STATE_FILE.write_text(json.dumps(current, indent=2), encoding="utf-8")
                try:
                    os.chmod(STATE_FILE, 0o600)
                except Exception:
                    pass
            return current
        except Exception:
            return _new_state()


def _save_file_state(state):
    with _lock:
        tmp = STATE_FILE.with_suffix(".tmp")
        tmp.write_text(json.dumps(state, indent=2), encoding="utf-8")
        try:
            os.chmod(tmp, 0o600)
        except Exception:
            pass
        tmp.replace(STATE_FILE)
        try:
            os.chmod(STATE_FILE, 0o600)
        except Exception:
            pass


def _mysql_config():
    required = ("MYSQL_HOST", "MYSQL_USER", "MYSQL_PASSWORD", "MYSQL_DATABASE")
    missing = [key for key in required if not os.environ.get(key)]
    if missing:
        raise RuntimeError(
            "MySQL storage is enabled, but these environment variables are missing: "
            + ", ".join(missing)
            + ". Set them before starting server.py (or set STORAGE_BACKEND=file for local demo mode)."
        )
    try:
        port = int(os.environ.get("MYSQL_PORT", "3306"))
    except ValueError as exc:
        raise RuntimeError("MYSQL_PORT must be a number, normally 3306") from exc
    if not 1 <= port <= 65535:
        raise RuntimeError("MYSQL_PORT must be between 1 and 65535")
    host = os.environ["MYSQL_HOST"].strip()
    if not host:
        raise RuntimeError("MYSQL_HOST cannot be blank")
    local_hosts = {"localhost", "127.0.0.1", "::1"}
    is_local = host.lower() in local_hosts
    config = {
        "host": host,
        "port": port,
        "user": os.environ["MYSQL_USER"],
        "password": os.environ["MYSQL_PASSWORD"],
        "database": os.environ["MYSQL_DATABASE"],
        "connection_timeout": 8,
        "charset": "utf8mb4",
        "use_unicode": True,
    }
    disable_tls = os.environ.get("MYSQL_SSL_DISABLED", "").strip().lower() in ("1", "true", "yes")
    ssl_ca = os.environ.get("MYSQL_SSL_CA") or ""
    ssl_ca_pem = os.environ.get("MYSQL_SSL_CA_PEM") or ""
    if ssl_ca and ssl_ca_pem:
        raise RuntimeError("Set either MYSQL_SSL_CA (file path) or MYSQL_SSL_CA_PEM, not both")
    if ssl_ca_pem:
        ca_path = pathlib.Path(os.environ.get("TMPDIR", "/tmp")) / "kilani-mysql-ca.pem"
        try:
            if not ca_path.exists() or ca_path.read_text(encoding="utf-8") != ssl_ca_pem:
                ca_path.write_text(ssl_ca_pem, encoding="utf-8")
                os.chmod(ca_path, 0o600)
        except OSError as exc:
            raise RuntimeError("Unable to prepare MYSQL_SSL_CA_PEM for MySQL TLS") from exc
        ssl_ca = str(ca_path)
    if disable_tls:
        if not is_local:
            raise RuntimeError("Refusing unencrypted MySQL over a remote host; enable TLS instead")
        config["ssl_disabled"] = True
    elif not is_local or ssl_ca:
        # Require certificate and host verification for remote DB connections.
        config["ssl_verify_cert"] = True
        config["ssl_verify_identity"] = True
        if ssl_ca:
            config["ssl_ca"] = ssl_ca
    return config


_mysql_pool = None
_mysql_pool_signature = None
_mysql_pool_lock = threading.Lock()


def _mysql_pool_size():
    try:
        size = int(os.environ.get("MYSQL_POOL_SIZE", "2"))
    except ValueError as exc:
        raise RuntimeError("MYSQL_POOL_SIZE must be an integer between 1 and 10") from exc
    if not 1 <= size <= 10:
        raise RuntimeError("MYSQL_POOL_SIZE must be between 1 and 10")
    return size


def _mysql_connect():
    """Reuse a small per-instance pool; Vercel must still use a DB-side pooler."""
    global _mysql_pool, _mysql_pool_signature
    config = _mysql_config()
    pool_size = _mysql_pool_size()
    signature = hashlib.sha256(
        json.dumps({"config": config, "pool_size": pool_size}, sort_keys=True, default=str).encode()
    ).hexdigest()
    try:
        from mysql.connector.pooling import MySQLConnectionPool
    except ImportError as exc:
        raise RuntimeError(
            "MySQL driver is not installed. Run: pip install -r requirements.txt"
        ) from exc
    with _mysql_pool_lock:
        if _mysql_pool is None or _mysql_pool_signature != signature:
            _mysql_pool = MySQLConnectionPool(
                pool_name="kilani_%s" % signature[:16],
                pool_size=pool_size,
                **config,
            )
            _mysql_pool_signature = signature
        pool = _mysql_pool
    return pool.get_connection()


def _decode_json_value(value, default):
    if value is None or value == "":
        return default
    if isinstance(value, (dict, list, int, float, bool)):
        return value
    if isinstance(value, bytes):
        value = value.decode("utf-8", "replace")
    try:
        return json.loads(value)
    except (TypeError, ValueError):
        return default


def _mysql_state_values(state):
    roster = _decode_json_value(state.get("roster"), [])
    payments = _decode_json_value(state.get("payments"), [])
    plans = _decode_json_value(state.get("plans"), {})
    offers = _decode_json_value(state.get("offers"), {})
    access = state.get("memberAccess") or {}
    if not isinstance(roster, list):
        roster = []
    if not isinstance(payments, list):
        payments = []
    if not isinstance(plans, dict):
        plans = {}
    if not isinstance(offers, dict):
        offers = {}
    if not isinstance(access, dict):
        access = {}
    return (
        str(state.get("pin") or hash_pin(DEFAULT_PIN)),
        json.dumps(roster, ensure_ascii=False),
        json.dumps(payments, ensure_ascii=False),
        json.dumps(plans, ensure_ascii=False),
        str(state.get("notes") or ""),
        json.dumps(offers, ensure_ascii=False),
        [(str(member_id), str(code_hash)) for member_id, code_hash in access.items() if member_id and code_hash],
    )


def _mysql_store_state(cursor, state):
    pin, roster, payments, plans, notes, offers, access = _mysql_state_values(state)
    cursor.execute(
        """INSERT INTO kilani_app_state
           (id, pin_hash, roster_json, payments_json, plans_json, notes, offers_json)
           VALUES (1, %s, %s, %s, %s, %s, %s)
           ON DUPLICATE KEY UPDATE
             pin_hash=VALUES(pin_hash), roster_json=VALUES(roster_json),
             payments_json=VALUES(payments_json), plans_json=VALUES(plans_json),
             notes=VALUES(notes), offers_json=VALUES(offers_json)""",
        (pin, roster, payments, plans, notes, offers),
    )
    cursor.execute("DELETE FROM kilani_member_access")
    if access:
        cursor.executemany(
            "INSERT INTO kilani_member_access (member_id, code_hash) VALUES (%s, %s)",
            access,
        )
    owner_control = state.get("ownerControl") if isinstance(state.get("ownerControl"), dict) else _new_owner_control()
    cursor.execute(
        """INSERT INTO kilani_owner_control (id, control_json) VALUES (1, %s)
           ON DUPLICATE KEY UPDATE control_json=VALUES(control_json)""",
        (json.dumps(owner_control, ensure_ascii=False),),
    )


_mysql_schema_ready = False
_mysql_init_lock = threading.Lock()


def _ensure_mysql_schema():
    global _mysql_schema_ready
    if _mysql_schema_ready:
        return
    with _mysql_init_lock:
        if _mysql_schema_ready:
            return
        connection = _mysql_connect()
        cursor = connection.cursor()
        try:
            cursor.execute(
                """CREATE TABLE IF NOT EXISTS kilani_app_state (
                    id TINYINT UNSIGNED NOT NULL PRIMARY KEY,
                    pin_hash VARCHAR(255) NOT NULL,
                    roster_json JSON NOT NULL,
                    payments_json JSON NOT NULL,
                    plans_json JSON NOT NULL,
                    notes LONGTEXT NOT NULL,
                    offers_json JSON NOT NULL,
                    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
                        ON UPDATE CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"""
            )
            cursor.execute(
                """CREATE TABLE IF NOT EXISTS kilani_member_access (
                    member_id VARCHAR(191) NOT NULL PRIMARY KEY,
                    code_hash VARCHAR(255) NOT NULL,
                    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
                        ON UPDATE CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"""
            )
            cursor.execute(
                """CREATE TABLE IF NOT EXISTS kilani_owner_control (
                    id TINYINT UNSIGNED NOT NULL PRIMARY KEY,
                    control_json JSON NOT NULL,
                    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
                        ON UPDATE CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"""
            )
            connection.commit()
            cursor.execute("SELECT id FROM kilani_app_state WHERE id=1")
            if cursor.fetchone() is None:
                legacy = _load_legacy_state()
                _mysql_store_state(cursor, legacy)
                connection.commit()
                if STATE_FILE.exists():
                    print("· imported existing state.json into MySQL (original file kept as backup)")
                else:
                    print("· initialized MySQL state (demo PIN %s)" % DEFAULT_PIN)
            _mysql_schema_ready = True
        except Exception:
            connection.rollback()
            raise
        finally:
            cursor.close()
            connection.close()


def _mysql_load_state():
    _ensure_mysql_schema()
    connection = _mysql_connect()
    cursor = connection.cursor(dictionary=True)
    try:
        cursor.execute("SELECT * FROM kilani_app_state WHERE id=1")
        row = cursor.fetchone()
        if not row:
            raise RuntimeError("MySQL application state row is missing")
        cursor.execute("SELECT member_id, code_hash FROM kilani_member_access")
        access = {str(item["member_id"]): str(item["code_hash"]) for item in cursor.fetchall()}
        cursor.execute("SELECT control_json FROM kilani_owner_control WHERE id=1")
        control_row = cursor.fetchone()
        owner_control = _decode_json_value(
            control_row.get("control_json") if control_row else None, _new_owner_control()
        )
        owner_control = _normalize_owner_control(owner_control)
        roster = _decode_json_value(row.get("roster_json"), [])
        payments = _decode_json_value(row.get("payments_json"), [])
        plans = _decode_json_value(row.get("plans_json"), {})
        offers = _decode_json_value(row.get("offers_json"), {})
        return {
            "pin": row.get("pin_hash") or hash_pin(DEFAULT_PIN),
            "roster": json.dumps(roster if isinstance(roster, list) else [], ensure_ascii=False),
            "payments": json.dumps(payments if isinstance(payments, list) else [], ensure_ascii=False),
            "plans": json.dumps(plans if isinstance(plans, dict) else {}, ensure_ascii=False),
            "notes": row.get("notes") or "",
            "offers": json.dumps(offers if isinstance(offers, dict) else {}, ensure_ascii=False),
            "memberAccess": access,
            "ownerControl": owner_control,
        }
    finally:
        cursor.close()
        connection.close()


def _mysql_save_state(state):
    _ensure_mysql_schema()
    with _lock:
        connection = _mysql_connect()
        cursor = connection.cursor()
        try:
            _mysql_store_state(cursor, state)
            connection.commit()
        except Exception:
            connection.rollback()
            raise
        finally:
            cursor.close()
            connection.close()


def load_state():
    if _running_on_vercel() and STORAGE_BACKEND != "mysql":
        raise RuntimeError("Vercel production requires persistent MySQL storage; file storage is not supported")
    if STORAGE_BACKEND == "mysql":
        return _mysql_load_state()
    if STORAGE_BACKEND in ("file", "json"):
        return _load_file_state()
    raise RuntimeError("Unknown STORAGE_BACKEND: %s (use mysql or file)" % STORAGE_BACKEND)


def save_state(state):
    if _running_on_vercel() and STORAGE_BACKEND != "mysql":
        raise RuntimeError("Vercel production requires persistent MySQL storage; file storage is not supported")
    if STORAGE_BACKEND == "mysql":
        return _mysql_save_state(state)
    if STORAGE_BACKEND in ("file", "json"):
        return _save_file_state(state)
    raise RuntimeError("Unknown STORAGE_BACKEND: %s (use mysql or file)" % STORAGE_BACKEND)

def secret():
    configured = os.environ.get("SESSION_SECRET")
    if configured:
        if len(configured.encode()) < 32:
            raise RuntimeError("SESSION_SECRET must be at least 32 bytes")
        return configured.encode()
    if _running_on_vercel():
        raise RuntimeError("SESSION_SECRET must be set as a stable private Vercel environment variable")
    if SECRET_FILE.exists():
        key = SECRET_FILE.read_bytes()
        if len(key) < 32:
            raise RuntimeError(".session_secret must contain at least 32 bytes")
        try:
            os.chmod(SECRET_FILE, 0o600)
        except OSError:
            pass
        return key
    key = secrets.token_bytes(32)
    SECRET_FILE.write_bytes(key)
    try:
        os.chmod(SECRET_FILE, 0o600)
    except OSError:
        pass
    return key


def member_code_pepper():
    configured = os.environ.get("MEMBER_CODE_PEPPER")
    if configured:
        if len(configured.encode()) < 32:
            raise RuntimeError("MEMBER_CODE_PEPPER must be at least 32 bytes")
        return configured.encode()
    if _running_on_vercel():
        raise RuntimeError("MEMBER_CODE_PEPPER must be set as a stable private Vercel environment variable")
    if MEMBER_CODE_PEPPER_FILE.exists():
        key = MEMBER_CODE_PEPPER_FILE.read_bytes()
        if len(key) < 32:
            raise RuntimeError(".member_code_pepper must contain at least 32 bytes")
        try:
            os.chmod(MEMBER_CODE_PEPPER_FILE, 0o600)
        except OSError:
            pass
        return key
    key = secrets.token_bytes(32)
    MEMBER_CODE_PEPPER_FILE.write_bytes(key)
    try:
        os.chmod(MEMBER_CODE_PEPPER_FILE, 0o600)
    except OSError:
        pass
    return key


# ------------------------------------------------------------------ auth ---
def make_token(pin_hash=None):
    if pin_hash is None:
        pin_hash = load_state().get("pin", "")
    stamp = str(int(time.time()))
    pin_fingerprint = hashlib.sha256((pin_hash or "").encode()).hexdigest()
    payload = (stamp + "." + pin_fingerprint).encode()
    sig = hmac.new(secret(), payload, hashlib.sha256).hexdigest()
    return payload.decode() + "." + sig


def token_ok(token):
    if not token:
        return False
    try:
        stamp, pin_fingerprint, sig = token.split(".", 2)
        payload = (stamp + "." + pin_fingerprint).encode()
        good = hmac.new(secret(), payload, hashlib.sha256).hexdigest()
        if not hmac.compare_digest(sig, good):
            return False
        age = time.time() - int(stamp)
        if not (0 <= age < SESSION_AGE):
            return False
        state = load_state()
        current = hashlib.sha256((state.get("pin", "") or "").encode()).hexdigest()
        return hmac.compare_digest(pin_fingerprint, current)
    except (ValueError, TypeError):
        return False

def member_code_lookup(code):
    return hmac.new(
        member_code_pepper(), b"kilani-member-code-index:" + str(code).encode("utf-8"), hashlib.sha256
    ).hexdigest()


def member_code_lookup_value(stored):
    try:
        parts = stored.split("$")
        if len(parts) == 5 and parts[0] == "pbkdf2":
            return parts[4]
    except (AttributeError, TypeError):
        pass
    return None


def make_member_code_hash(member_id, code, salt=None):
    salt = salt or secrets.token_hex(16)
    material = salt + ":" + member_id + ":" + code + ":member"
    digest = _derive_hash(material, salt)
    lookup = member_code_lookup(code)
    return "pbkdf2$%d$%s$%s$%s" % (PBKDF2_ITERATIONS, salt, digest, lookup)


def verify_member_code(member_id, code, stored):
    if not isinstance(stored, str):
        return False
    try:
        if stored.startswith("sha256$"):
            _, salt, expected = stored.split("$", 2)
            actual = hashlib.sha256((salt + ":" + member_id + ":" + code + ":member").encode()).hexdigest()
        else:
            parts = stored.split("$")
            if len(parts) not in (4, 5) or parts[0] != "pbkdf2":
                return False
            iterations = int(parts[1])
            salt, expected = parts[2], parts[3]
            if not (1_000 <= iterations <= MAX_HASH_ITERATIONS):
                return False
            material = salt + ":" + member_id + ":" + code + ":member"
            actual = _derive_hash(material, salt, iterations)
        return hmac.compare_digest(actual, expected)
    except (ValueError, TypeError):
        return False


def member_code_needs_rehash(stored):
    try:
        parts = stored.split("$")
        return not (
            len(parts) == 5 and parts[0] == "pbkdf2"
            and int(parts[1]) >= PBKDF2_ITERATIONS
        )
    except (AttributeError, ValueError):
        return True

def member_access_fingerprint(stored):
    return hashlib.sha256((stored or "").encode()).hexdigest()


def owner_access_key():
    key = os.environ.get("OWNER_ACCESS_KEY", "")
    if not key:
        return None
    encoded = key.encode("utf-8")
    if len(encoded) < 32:
        raise RuntimeError("OWNER_ACCESS_KEY must be at least 32 bytes")
    return encoded


def make_owner_token():
    key = owner_access_key()
    if not key:
        raise RuntimeError("OWNER_ACCESS_KEY is not configured")
    stamp = str(int(time.time()))
    fingerprint = hashlib.sha256(key).hexdigest()
    payload = (stamp + "." + fingerprint).encode()
    sig = hmac.new(secret(), payload, hashlib.sha256).hexdigest()
    return payload.decode() + "." + sig


def owner_token_ok(token):
    if not token:
        return False
    try:
        key = owner_access_key()
        if not key:
            return False
        stamp, fingerprint, sig = token.split(".", 2)
        payload = (stamp + "." + fingerprint).encode()
        expected = hmac.new(secret(), payload, hashlib.sha256).hexdigest()
        age = time.time() - int(stamp)
        current = hashlib.sha256(key).hexdigest()
        return (
            0 <= age < OWNER_SESSION_AGE
            and hmac.compare_digest(sig, expected)
            and hmac.compare_digest(fingerprint, current)
        )
    except (ValueError, TypeError, RuntimeError):
        return False


def make_member_token(member_id, access_hash):
    claim = (member_id + "|" + str(int(time.time())) + "|" + member_access_fingerprint(access_hash)).encode()
    encoded = base64.urlsafe_b64encode(claim).decode().rstrip("=")
    sig = hmac.new(secret(), claim, hashlib.sha256).hexdigest()
    return encoded + "." + sig


def member_token_claim(token):
    if not token or "." not in token:
        return None
    encoded, sig = token.rsplit(".", 1)
    try:
        padded = encoded + "=" * (-len(encoded) % 4)
        claim = base64.urlsafe_b64decode(padded.encode())
        good = hmac.new(secret(), claim, hashlib.sha256).hexdigest()
        if not hmac.compare_digest(sig, good):
            return None
        member_id, stamp, fingerprint = claim.decode().rsplit("|", 2)
        age = time.time() - int(stamp)
        if age < 0 or age >= MEMBER_SESSION_AGE:
            return None
        return member_id, fingerprint
    except Exception:
        return None


# ---------------------------------------------------------------- server ---
class RequestTooLarge(Exception):
    pass


class InvalidRequestBody(Exception):
    pass


class Handler(BaseHTTPRequestHandler):
    server_version = "KilaniClub"
    sys_version = ""

    # ---------- helpers ----------
    def _send(self, code, body=b"", ctype="text/html; charset=utf-8", extra=None):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "same-origin")
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Permitted-Cross-Domain-Policies", "none")
        self.send_header("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
        self.send_header(
            "Content-Security-Policy",
            "default-src 'self' data:; img-src 'self' data: blob:; "
            "style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; "
            "connect-src 'self'; font-src 'self' data:; object-src 'none'; "
            "base-uri 'self'; form-action 'self'",
        )
        if self.secure_cookie():
            self.send_header("Strict-Transport-Security", "max-age=15552000")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def _json(self, code, obj, extra=None):
        self._send(code, json.dumps(obj).encode(), "application/json", extra)

    def _redirect(self, where, extra=None):
        self.send_response(303)
        self.send_header("Location", where)
        self.send_header("Cache-Control", "no-store")
        self.send_header("Referrer-Policy", "same-origin")
        self.send_header("X-Content-Type-Options", "nosniff")
        if self.secure_cookie():
            self.send_header("Strict-Transport-Security", "max-age=15552000")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.send_header("Content-Length", "0")
        self.end_headers()

    def _cookies(self):
        try:
            return http.cookies.SimpleCookie(self.headers.get("Cookie", ""))
        except Exception:
            return {}

    def _cookied(self, name):
        c = self._cookies()
        return c[name].value if name in c else None

    def authed(self):
        return token_ok(self._cookied(COOKIE))

    def owner_authed(self):
        return owner_token_ok(self._cookied(OWNER_COOKIE))

    def _coach_session_fingerprint(self):
        token = self._cookied(COOKIE)
        if not token or not self.authed():
            return None
        return hashlib.sha256(token.encode()).hexdigest()

    def _active_owner_grant(self):
        fingerprint = self._coach_session_fingerprint()
        if not fingerprint:
            return None
        control = _normalize_owner_control(load_state().get("ownerControl"))
        now = int(time.time())
        for request in reversed(control["requests"]):
            if request.get("status") != "approved":
                continue
            if int(request.get("grantExpiresAt") or 0) <= now:
                continue
            stored = str(request.get("coachTokenFingerprint") or "")
            if hmac.compare_digest(stored, fingerprint):
                return request
        return None

    def _owner_access(self):
        if self.owner_authed():
            return {"role": "owner", "scope": "all"}
        grant = self._active_owner_grant()
        if grant:
            return {"role": "temporary", "scope": grant.get("grantedScope"), "request": grant}
        return None

    def _record_owner_audit(self, control, action, actor, scope="", request_id=""):
        entry = {
            "at": int(time.time()), "action": str(action)[:80],
            "actor": str(actor)[:80], "scope": str(scope)[:40],
            "requestId": str(request_id)[:32],
        }
        control.setdefault("audit", []).append(entry)
        control["audit"] = control["audit"][-OWNER_AUDIT_LIMIT:]

    def _owner_session_payload(self):
        try:
            configured = bool(owner_access_key())
        except RuntimeError:
            configured = False
        access = self._owner_access()
        if not access:
            return {
                "role": "coach_needs_request" if self.authed() else "none",
                "ownerConfigured": configured,
            }
        state = load_state()
        control = _normalize_owner_control(state.get("ownerControl"))
        settings = control["settings"]
        d17 = {
            "provider": "D17",
            "integrationReady": False,
            "message": "D17 integration is in progress but not live. Keep online checkout off until merchant setup, official integration details, and payment callbacks are verified.",
            "payoutLabel": settings.get("payoutLabel", "Managed securely in D17 merchant tools"),
        }
        if access["role"] == "owner":
            return {
                "role": "owner", "ownerConfigured": configured,
                "settings": settings,
                "requests": [self._public_owner_request(r) for r in reversed(control["requests"])],
                "audit": list(reversed(control["audit"][-30:])),
                "payment": d17,
            }
        grant = access.get("request") or {}
        return {
            "role": "temporary", "scope": access.get("scope"),
            "expiresAt": int(grant.get("grantExpiresAt") or 0),
            "settings": settings if access.get("scope") == "site_controls" else None,
            "payment": d17,
        }

    @staticmethod
    def _public_owner_request(request):
        return {
            "id": str(request.get("id") or ""),
            "scope": str(request.get("scope") or ""),
            "reason": str(request.get("reason") or ""),
            "status": str(request.get("status") or ""),
            "requestedAt": int(request.get("requestedAt") or 0),
            "decisionAt": int(request.get("decisionAt") or 0),
            "grantExpiresAt": int(request.get("grantExpiresAt") or 0),
            "grantedScope": str(request.get("grantedScope") or ""),
        }

    def _maintenance_enabled(self):
        control = _normalize_owner_control(load_state().get("ownerControl"))
        return bool(control["settings"].get("maintenanceMode"))

    def _maintenance_response(self, path):
        self.close_connection = True
        if path.startswith("/api/"):
            return self._json(503, {"error": "The site is temporarily in maintenance mode."})
        body = ("<!doctype html><html lang='en'><meta charset='utf-8'>"
                "<meta name='viewport' content='width=device-width,initial-scale=1'>"
                "<title>Temporarily paused · Boxing Club</title>"
                "<style>body{margin:0;min-height:100vh;display:grid;place-items:center;"
                "background:#F2EDE1;color:#1E2A22;font:16px system-ui,sans-serif}"
                ".card{max-width:540px;padding:42px;border-radius:22px;background:#fff;"
                "box-shadow:0 20px 60px #1e2a221a}small{letter-spacing:.14em;text-transform:uppercase;"
                "color:#C05B33;font-weight:800}h1{font-size:clamp(2rem,8vw,3.4rem);line-height:1;margin:16px 0}"
                "p{color:#526057;line-height:1.7}</style><main class='card'>"
                "<small>Boxing Club · Ribat, Monastir</small><h1>We’re taking a short break.</h1>"
                "<p>The website is temporarily paused for maintenance. Please check back soon or contact the coach.</p>"
                "</main></html>").encode()
        return self._send(503, body, extra={"Retry-After": "300"})

    def _maintenance_blocked(self, path):
        if path in ("/owner", "/owner.html", "/owner/login", "/api/site-status", "/healthz") or path.startswith("/api/owner/"):
            return False
        if not self._maintenance_enabled():
            return False
        return not self.owner_authed()

    def member_id(self):
        claim = member_token_claim(self._cookied(MEMBER_COOKIE))
        if not claim:
            return None
        member_id, fingerprint = claim
        state = load_state()
        stored = state.get("memberAccess", {}).get(member_id, "")
        if not stored or not hmac.compare_digest(fingerprint, member_access_fingerprint(stored)):
            return None
        return member_id

    def client_ip(self):
        # Vercel overwrites its forwarded visitor-IP headers at the platform edge;
        # trust these only when running inside Vercel. Other proxies must be explicitly trusted below.
        if _running_on_vercel():
            for header in ("X-Vercel-Forwarded-For", "X-Real-Ip", "X-Forwarded-For"):
                forwarded = self.headers.get(header, "").split(",", 1)[0].strip()
                try:
                    if forwarded:
                        return str(ipaddress.ip_address(forwarded))
                except ValueError:
                    continue
        # Honor X-Forwarded-For only when the socket peer is explicitly trusted.
        # The proxy must overwrite (not append untrusted values to) this header.
        try:
            peer = ipaddress.ip_address(self.client_address[0])
        except ValueError:
            return self.client_address[0]
        trusted = []
        for value in os.environ.get("TRUSTED_PROXY_IPS", "").split(","):
            try:
                trusted.append(ipaddress.ip_network(value.strip(), strict=False))
            except ValueError:
                continue
        if not any(peer in network for network in trusted):
            return str(peer)
        forwarded = self.headers.get("X-Forwarded-For", "").split(",", 1)[0].strip()
        try:
            return str(ipaddress.ip_address(forwarded)) if forwarded else str(peer)
        except ValueError:
            return str(peer)

    def secure_cookie(self):
        # The trusted reverse proxy must overwrite this header with the client scheme.
        forwarded = self.headers.get("X-Forwarded-Proto", "")
        return forwarded.split(",", 1)[0].strip().lower() == "https"

    def cookie_value(self, token, max_age, name=COOKIE, same_site="Lax"):
        value = "%s=%s; Path=/; Max-Age=%d; HttpOnly; SameSite=%s" % (name, token, max_age, same_site)
        if self.secure_cookie():
            value += "; Secure"
        return value

    def read_body(self):
        raw_length = self.headers.get("Content-Length")
        if not raw_length:
            return b""
        try:
            n = int(raw_length)
        except ValueError as exc:
            raise InvalidRequestBody("invalid content length") from exc
        if n < 0:
            raise InvalidRequestBody("invalid content length")
        if n > MAX_REQUEST_BODY:
            raise RequestTooLarge()
        return self.rfile.read(n) if n else b""

    def read_json_object(self):
        try:
            value = json.loads(self.read_body().decode("utf-8") or "{}")
        except (RequestTooLarge, InvalidRequestBody):
            raise
        except Exception:
            return None
        return value if isinstance(value, dict) else None

    def same_origin_post(self):
        fetch_site = (self.headers.get("Sec-Fetch-Site") or "").lower()
        if fetch_site == "cross-site":
            return False
        origin = self.headers.get("Origin")
        if not origin:
            return True
        try:
            parsed = urllib.parse.urlsplit(origin)
        except ValueError:
            return False
        request_host = (self.headers.get("Host") or "").lower()
        return parsed.scheme in ("http", "https") and bool(request_host) and parsed.netloc.lower() == request_host

    def file(self, name):
        path = ROOT / name
        if not path.exists():
            self._send(404, b"Not found")
            return
        self._send(200, path.read_bytes())

    def member_payload(self, m):
        view = m.get("memberView") or {}
        if not isinstance(view, dict):
            view = {}
        visibility = view.get("visibility") or {}
        if not isinstance(visibility, dict):
            visibility = {}
        show_membership = visibility.get("showMembership", True) is not False
        show_program = visibility.get("showProgram", True) is not False
        show_sessions = visibility.get("showSessions", True) is not False
        show_billing = visibility.get("showBilling", True) is not False
        show_note = visibility.get("showNote", True) is not False
        show_nutrition = visibility.get("showNutrition", True) is not False
        show_progress = visibility.get("showProgress", True) is not False
        expose_formula = show_membership or show_sessions
        return {
            "id": m.get("id"), "name": m.get("name", "Member"),
            "goal": m.get("goal", "Fat loss"),
            "planId": m.get("planId") if expose_formula else None,
            "planName": m.get("planName", "Training plan") if expose_formula else "",
            "mode": m.get("mode", "private") if expose_formula else "",
            "sessionsTotal": int(m.get("sessionsTotal", 0) or 0) if (expose_formula or show_program) else 0,
            "sessionsUsed": int(m.get("sessionsUsed", 0) or 0) if expose_formula else 0,
            # Start/end are deliberately always available for the required countdown.
            "start": m.get("start"), "end": m.get("end"),
            "price": float(m.get("price", 0) or 0) if show_billing else 0,
            "paid": bool(m.get("paid", False)) if show_billing else None,
            "memberView": {
                "note": view.get("note", "") if show_note else "",
                "programText": view.get("programText", "") if show_program else "",
                "programMonth": view.get("programMonth", "") if show_program else "",
                "visibility": visibility,
                "nutrition": (view.get("nutrition", {}) if isinstance(view.get("nutrition", {}), dict) else {}) if show_nutrition else {},
            },
            "progress": ([{"date": item.get("date"), "weight": item.get("weight"), "waist": item.get("waist"), "bodyFat": item.get("bodyFat")} for item in (m.get("progress", []) or []) if isinstance(item, dict)] if show_progress else []),
        }

    # ---------- pages ----------
    def login_page(self, message=""):
        html = (ROOT / "login.html")
        if not html.exists():
            self._send(500, b"login.html missing")
            return
        body = html.read_bytes()
        if message:
            body = body.replace(b"<!--MSG-->", message.encode())
        else:
            body = body.replace(b"<!--MSG-->", b"")
        self._send(200, body)

    def serve_admin(self):
        """Serve the dashboard with the shared state booted in, so it works even
        before the first fetch finishes."""
        state = load_state()
        boot = {k: state.get(k) for k in ("roster", "payments", "plans", "notes", "offers")}
        html = (ROOT / "admin.html").read_text(encoding="utf-8")
        boot_json = json.dumps(boot).replace("<", "\\u003c").replace(">", "\\u003e").replace("&", "\\u0026")
        inject = (
            "<script>window.KILANI_API='api/state';"
            "window.KILANI_STATE=" + boot_json + ";</script>\n"
        )
        html = html.replace("<script>\n", inject + "<script>\n", 1)
        self._send(200, html.encode())

    def do_GET(self):
        path = urllib.parse.urlparse(self.path).path
        if self._maintenance_blocked(path):
            return self._maintenance_response(path)

        if path in ("/owner", "/owner.html", "/owner/login"):
            return self.file("owner.html")
        if path == "/api/owner/session":
            return self._json(200, self._owner_session_payload())
        if path == "/api/owner/request-status":
            fingerprint = self._coach_session_fingerprint()
            if not fingerprint:
                return self._json(401, {"error": "coach login required"})
            control = _normalize_owner_control(load_state().get("ownerControl"))
            own = [self._public_owner_request(r) for r in control["requests"]
                   if hmac.compare_digest(str(r.get("coachTokenFingerprint") or ""), fingerprint)]
            return self._json(200, {"requests": list(reversed(own[-5:]))})
        if path == "/api/site-status":
            control = _normalize_owner_control(load_state().get("ownerControl"))
            settings = control["settings"]
            return self._json(200, {
                "maintenanceMode": bool(settings["maintenanceMode"]),
                "paymentsPaused": bool(settings["paymentsPaused"]),
                "bookingsPaused": bool(settings["bookingsPaused"]),
                "checkoutReady": False,
                "bookingReady": False,
                "paymentsEnabled": False,
                "bookingsEnabled": False,
                "provider": "D17",
            })

        if path in ("/", "/index.html"): 
            return self.file("index.html")
        if path == "/login":
            if self.authed():
                return self._redirect("/admin.html")
            return self.login_page()
        if path in ("/admin.html", "/admin"):
            if not self.authed():
                return self._redirect("/login")
            return self.serve_admin()
        if path == "/logout":
            cleared = COOKIE + "=; Path=/; Max-Age=0; HttpOnly; SameSite=Lax"
            if self.secure_cookie():
                cleared += "; Secure"
            return self._redirect("/login", {"Set-Cookie": cleared})
        if path == "/api/state":
            if not self.authed():
                return self._json(401, {"error": "auth required"})
            state = load_state()
            return self._json(200, {
                "roster": state.get("roster", ""),
                "payments": state.get("payments", ""),
                "plans": state.get("plans", ""),
                "notes": state.get("notes", ""),
                "offers": state.get("offers", ""),
            })
        if path == "/api/public-plan":
            # Public member-facing plans and offer catalogue only. No member data.
            state = load_state()
            return self._json(200, {
                "plans": state.get("plans", ""),
                "offers": state.get("offers", ""),
            })
        if path == "/api/member/me":
            member_id = self.member_id()
            if not member_id:
                return self._json(401, {"error": "member login required"})
            state = load_state()
            try:
                members = json.loads(state.get("roster") or "[]")
            except Exception:
                members = []
            member = next((m for m in members if m.get("id") == member_id), None)
            if not member:
                return self._json(401, {"error": "member not found"})
            return self._json(200, {"member": self.member_payload(member)})
        if path == "/healthz":
            return self._json(200, {"ok": True, "time": int(time.time())})

        # Only known public assets may be served. Never expose state.json,
        # .session_secret, .member_code_pepper, server.py, README, src/ or other workspace files.
        clean = path.lstrip("/")
        target = (ROOT / clean).resolve()
        assets = (ROOT / "assets").resolve()
        allowed_ext = {".webp", ".png", ".jpg", ".jpeg", ".svg", ".ico", ".woff", ".woff2"}
        if target.is_file() and assets in target.parents and target.suffix.lower() in allowed_ext:
            ctype = {
                ".webp": "image/webp", ".png": "image/png", ".jpg": "image/jpeg",
                ".jpeg": "image/jpeg", ".svg": "image/svg+xml", ".ico": "image/x-icon",
                ".woff": "font/woff", ".woff2": "font/woff2",
            }[target.suffix.lower()]
            return self._send(200, target.read_bytes(), ctype)

        return self._send(404, b"Not found")

    def do_POST(self):
        if not self.same_origin_post():
            return self._json(403, {"error": "cross-origin request rejected"})
        path = urllib.parse.urlparse(self.path).path
        if self._maintenance_blocked(path):
            return self._maintenance_response(path)
        try:
            return self._do_POST()
        except RequestTooLarge:
            self.close_connection = True
            return self._json(413, {"error": "request body too large"})
        except InvalidRequestBody:
            self.close_connection = True
            return self._json(400, {"error": "invalid content length"})

    def _do_POST(self):
        path = urllib.parse.urlparse(self.path).path
        ip = self.client_ip()

        if path == "/api/owner/login":
            incoming = self.read_json_object()
            if incoming is None:
                return self._json(400, {"error": "bad json"})
            try:
                configured_key = owner_access_key()
            except RuntimeError as exc:
                return self._json(503, {"error": str(exc)})
            if not configured_key:
                return self._json(503, {"error": "Owner access is not configured. Set OWNER_ACCESS_KEY in the private environment."})
            fails, locked = _owner_attempts.get(ip, [0, 0])
            if locked and time.time() < locked:
                return self._json(429, {"error": "Too many owner-login attempts. Try again later."})
            candidate = incoming.get("key")
            valid = isinstance(candidate, str) and hmac.compare_digest(candidate.encode("utf-8"), configured_key)
            if valid:
                _owner_attempts.pop(ip, None)
                token = make_owner_token()
                return self._json(200, {"ok": True}, {
                    "Set-Cookie": self.cookie_value(token, OWNER_SESSION_AGE, OWNER_COOKIE, "Strict")
                })
            fails += 1
            if fails >= LOCKOUT_AFTER:
                _owner_attempts[ip] = [0, time.time() + LOCKOUT_SECONDS]
                return self._json(429, {"error": "Too many owner-login attempts. Try again in 60 seconds."})
            _owner_attempts[ip] = [fails, 0]
            return self._json(401, {"error": "Owner key not recognised."})

        if path == "/api/owner/logout":
            cookie = OWNER_COOKIE + "=; Path=/; Max-Age=0; HttpOnly; SameSite=Strict"
            if self.secure_cookie():
                cookie += "; Secure"
            return self._json(200, {"ok": True}, {"Set-Cookie": cookie})

        if path == "/api/owner/request":
            fingerprint = self._coach_session_fingerprint()
            if not fingerprint:
                return self._json(401, {"error": "coach login required"})
            incoming = self.read_json_object()
            if incoming is None:
                return self._json(400, {"error": "bad json"})
            scope = str(incoming.get("scope") or "")
            reason = str(incoming.get("reason") or "").strip()
            if scope not in OWNER_SCOPES:
                return self._json(400, {"error": "Choose a valid access request type."})
            if not 8 <= len(reason) <= 240:
                return self._json(400, {"error": "Explain the request in 8–240 characters."})
            # Do not allow overlapping approved grants for the same coach session:
            # otherwise revoking the newest grant could leave an older one active.
            if self._active_owner_grant():
                return self._json(409, {"error": "This coach session already has active temporary access."})
            state = load_state()
            control = _normalize_owner_control(state.get("ownerControl"))
            if any(
                r.get("status") == "pending"
                and hmac.compare_digest(str(r.get("coachTokenFingerprint") or ""), fingerprint)
                for r in control["requests"]
            ):
                return self._json(409, {"error": "You already have a pending request."})
            request = {
                "id": secrets.token_urlsafe(9), "scope": scope, "reason": reason,
                "status": "pending", "requestedAt": int(time.time()),
                "coachTokenFingerprint": fingerprint,
            }
            control["requests"].append(request)
            control["requests"] = control["requests"][-OWNER_REQUEST_LIMIT:]
            self._record_owner_audit(control, "access requested", "coach", scope, request["id"])
            state["ownerControl"] = control
            save_state(state)
            return self._json(201, {"ok": True, "request": self._public_owner_request(request)})

        if path == "/api/owner/decision":
            if not self.owner_authed():
                return self._json(401, {"error": "creator login required"})
            incoming = self.read_json_object()
            if incoming is None or not isinstance(incoming.get("approve"), bool):
                return self._json(400, {"error": "bad decision"})
            request_id = str(incoming.get("requestId") or "")
            state = load_state()
            control = _normalize_owner_control(state.get("ownerControl"))
            request = next((r for r in control["requests"] if r.get("id") == request_id), None)
            if not request or request.get("status") != "pending":
                return self._json(404, {"error": "pending request not found"})
            now = int(time.time())
            request["decisionAt"] = now
            if incoming["approve"]:
                scope = str(request.get("scope") or "")
                if scope not in OWNER_SCOPES:
                    return self._json(400, {"error": "request scope is invalid"})
                request["status"] = "approved"
                request["grantedScope"] = scope
                request["grantExpiresAt"] = now + OWNER_GRANT_SECONDS
                action = "temporary access approved"
            else:
                request["status"] = "denied"
                request["grantExpiresAt"] = 0
                action = "temporary access denied"
            self._record_owner_audit(control, action, "creator", request.get("grantedScope") or request.get("scope"), request_id)
            state["ownerControl"] = control
            save_state(state)
            return self._json(200, {"ok": True, "request": self._public_owner_request(request)})

        if path == "/api/owner/revoke":
            if not self.owner_authed():
                return self._json(401, {"error": "creator login required"})
            incoming = self.read_json_object()
            if incoming is None:
                return self._json(400, {"error": "bad json"})
            request_id = str(incoming.get("requestId") or "")
            state = load_state()
            control = _normalize_owner_control(state.get("ownerControl"))
            request = next((r for r in control["requests"] if r.get("id") == request_id), None)
            if not request or request.get("status") != "approved":
                return self._json(404, {"error": "active grant not found"})
            request["status"] = "revoked"
            request["grantExpiresAt"] = int(time.time())
            self._record_owner_audit(control, "temporary access revoked", "creator", request.get("grantedScope"), request_id)
            state["ownerControl"] = control
            save_state(state)
            return self._json(200, {"ok": True})

        if path == "/api/owner/settings":
            access = self._owner_access()
            if not access:
                return self._json(401, {"error": "owner access required"})
            if access["role"] != "owner" and access.get("scope") != "site_controls":
                return self._json(403, {"error": "this temporary grant cannot change site controls"})
            incoming = self.read_json_object()
            if incoming is None:
                return self._json(400, {"error": "bad json"})
            allowed = ("maintenanceMode", "paymentsPaused", "bookingsPaused")
            changed = [key for key in allowed if key in incoming]
            if not changed or any(not isinstance(incoming[key], bool) for key in changed):
                return self._json(400, {"error": "send one or more boolean site controls"})
            state = load_state()
            control = _normalize_owner_control(state.get("ownerControl"))
            for key in changed:
                control["settings"][key] = incoming[key]
            state["ownerControl"] = control
            actor = "creator" if access["role"] == "owner" else "coach temporary grant"
            self._record_owner_audit(control, "site controls updated: " + ", ".join(changed), actor, access.get("scope", "all"))
            save_state(state)
            return self._json(200, {"ok": True, "settings": control["settings"]})

        # ---------------- coach login ----------------
        if path == "/login": 
            form = urllib.parse.parse_qs(self.read_body().decode("utf-8", "replace"))
            pin = (form.get("pin", [""])[0] or "").strip()
            fails, locked = _attempts.get(ip, [0, 0])
            if locked and time.time() < locked:
                return self.login_page("Too many attempts — wait %d s." % int(locked - time.time()))

            state = load_state()
            if re.fullmatch(r"[0-9]{8,10}", pin) and verify_pin(pin, state.get("pin", "")):
                if pin_needs_rehash(state.get("pin", "")):
                    state["pin"] = hash_pin(pin)
                    save_state(state)
                _attempts.pop(ip, None)
                return self._redirect("/admin.html", {
                    "Set-Cookie": self.cookie_value(make_token(state.get("pin", "")), SESSION_AGE)
                })

            fails += 1
            if fails >= LOCKOUT_AFTER:
                _attempts[ip] = [0, time.time() + LOCKOUT_SECONDS]
                return self.login_page("Too many attempts — wait %d s." % LOCKOUT_SECONDS)
            _attempts[ip] = [fails, 0]
            return self.login_page("Wrong code. %d attempt(s) left." % (LOCKOUT_AFTER - fails))

        # ---------------- member portal login ----------------
        if path == "/api/member/login":
            try:
                incoming = json.loads(self.read_body().decode("utf-8") or "{}")
            except (RequestTooLarge, InvalidRequestBody):
                raise
            except Exception:
                return self._json(400, {"error": "bad json"})
            if not isinstance(incoming, dict):
                return self._json(400, {"error": "bad json"})
            code = str(incoming.get("code") or "").strip()
            fails, locked = _member_attempts.get(ip, [0, 0])
            if locked and time.time() < locked:
                return self._json(429, {"error": "Too many attempts — wait %d s." % int(locked - time.time())})
            state = load_state()
            try:
                members = json.loads(state.get("roster") or "[]")
            except Exception:
                members = []
            matched = None
            if re.fullmatch(r"[0-9]{8,10}", code):
                supplied_lookup = member_code_lookup(code)
                for candidate in members:
                    candidate_id = candidate.get("id")
                    stored = state.get("memberAccess", {}).get(candidate_id, "")
                    indexed = member_code_lookup_value(stored)
                    if indexed and not hmac.compare_digest(indexed, supplied_lookup):
                        continue
                    if stored and verify_member_code(candidate_id or "", code, stored):
                        matched = candidate
                        break
            if matched:
                _member_attempts.pop(ip, None)
                access_hash = state.get("memberAccess", {}).get(matched["id"], "")
                if member_code_needs_rehash(access_hash):
                    access_hash = make_member_code_hash(matched["id"], code)
                    state.setdefault("memberAccess", {})[matched["id"]] = access_hash
                    save_state(state)
                cookie = self.cookie_value(make_member_token(matched["id"], access_hash), MEMBER_SESSION_AGE, MEMBER_COOKIE)
                return self._json(200, {"ok": True, "member": self.member_payload(matched)}, {"Set-Cookie": cookie})
            fails += 1
            if fails >= LOCKOUT_AFTER:
                _member_attempts[ip] = [0, time.time() + LOCKOUT_SECONDS]
                return self._json(429, {"error": "Too many attempts — wait 60 s."})
            _member_attempts[ip] = [fails, 0]
            return self._json(401, {"error": "Code not recognised. Check with your coach."})

        if path == "/api/member/logout":
            cookie = MEMBER_COOKIE + "=; Path=/; Max-Age=0; HttpOnly; SameSite=Lax"
            if self.secure_cookie():
                cookie += "; Secure"
            return self._json(200, {"ok": True}, {"Set-Cookie": cookie})

        if path == "/api/member/checkin":
            member_id = self.member_id()
            if not member_id:
                return self._json(401, {"error": "member login required"})
            try:
                incoming = json.loads(self.read_body().decode("utf-8") or "{}")
                used = int(incoming.get("sessionsUsed"))
            except (RequestTooLarge, InvalidRequestBody):
                raise
            except Exception:
                return self._json(400, {"error": "bad session count"})
            state = load_state()
            try:
                members = json.loads(state.get("roster") or "[]")
            except Exception:
                members = []
            member = next((m for m in members if m.get("id") == member_id), None)
            if not member:
                return self._json(404, {"error": "member not found"})
            member_view = member.get("memberView") or {}
            visibility = member_view.get("visibility") or {} if isinstance(member_view, dict) else {}
            if isinstance(visibility, dict) and visibility.get("showSessions", True) is False:
                return self._json(403, {"error": "session check-in is not enabled for this member"})
            member["sessionsUsed"] = max(0, min(int(member.get("sessionsTotal", 0) or 0), used))
            state["roster"] = json.dumps(members, ensure_ascii=False)
            save_state(state)
            return self._json(200, {"ok": True, "sessionsUsed": member["sessionsUsed"]})

        # ---------------- create/reset a member's access code (coach only) ----------------
        if path == "/api/member/access":
            if not self.authed():
                return self._json(401, {"error": "coach login required"})
            try:
                incoming = json.loads(self.read_body().decode("utf-8") or "{}")
            except (RequestTooLarge, InvalidRequestBody):
                raise
            except Exception:
                return self._json(400, {"error": "bad json"})
            if not isinstance(incoming, dict):
                return self._json(400, {"error": "bad json"})
            member_id = str(incoming.get("memberId") or "")
            code = str(incoming.get("code") or "")
            if not re.fullmatch(r"[0-9]{8,10}", code):
                return self._json(400, {"error": "member code must be 8–10 digits"})
            state = load_state()
            try:
                members = json.loads(state.get("roster") or "[]")
            except Exception:
                members = []
            if not any(m.get("id") == member_id for m in members):
                return self._json(404, {"error": "member not found"})
            access = state.setdefault("memberAccess", {})
            supplied_lookup = member_code_lookup(code)
            for other_id, stored in access.items():
                if other_id == member_id or not stored:
                    continue
                indexed = member_code_lookup_value(stored)
                duplicate = hmac.compare_digest(indexed, supplied_lookup) if indexed else verify_member_code(other_id, code, stored)
                if duplicate:
                    return self._json(409, {"error": "that access code is already assigned"})
            access[member_id] = make_member_code_hash(member_id, code)
            save_state(state)
            return self._json(200, {"ok": True})

        # ---------------- shared state ----------------
        if path == "/api/state":
            if not self.authed():
                return self._json(401, {"error": "auth required"})
            try:
                incoming = json.loads(self.read_body().decode("utf-8") or "{}")
            except (RequestTooLarge, InvalidRequestBody):
                raise
            except Exception:
                return self._json(400, {"error": "bad json"})
            if not isinstance(incoming, dict):
                return self._json(400, {"error": "bad json"})
            state = load_state()
            for key in ("roster", "payments", "plans", "notes", "offers"):
                if key in incoming:
                    val = incoming[key]
                    state[key] = val if isinstance(val, str) else json.dumps(val)
            if "roster" in incoming:
                try:
                    valid_ids = {m.get("id") for m in json.loads(state.get("roster") or "[]")}
                    access = state.setdefault("memberAccess", {})
                    state["memberAccess"] = {k: v for k, v in access.items() if k in valid_ids}
                except Exception:
                    pass
            # optional PIN change: {"newPin": "12345678"}
            new_pin = str(incoming.get("newPin") or "").strip()
            if new_pin:
                if not re.fullmatch(r"[0-9]{8,10}", new_pin):
                    return self._json(400, {"error": "PIN must be 8–10 digits"})
                state["pin"] = hash_pin(new_pin)
            save_state(state)
            return self._json(200, {"ok": True})

        return self._send(404, b"Not found")


def main():
    try:
        state = load_state()
        secret()
        member_code_pepper()
    except Exception as exc:
        print("Storage initialization failed: %s" % exc, file=sys.stderr)
        sys.exit(1)
    httpd = ThreadingHTTPServer((HOST, PORT), Handler)
    print("Kilani Boxing Club server on http://%s:%d" % (HOST, PORT))
    print("  storage      %s" % STORAGE_BACKEND)
    print("  /            public website")
    print("  /admin.html  coach dashboard (server login required)")
    if verify_pin(DEFAULT_PIN, state.get("pin", "")):
        print("  demo PIN     %s  → change it in Settings" % DEFAULT_PIN)
    else:
        print("  coach PIN    loaded from storage (not shown)")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nstopped")


if __name__ == "__main__":
    main()

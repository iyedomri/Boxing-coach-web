"""Vercel routing and production fail-closed regression tests."""
import email.message
import importlib.util
import json
import pathlib
import tempfile
import threading
import unittest
import urllib.request
from http.server import ThreadingHTTPServer
from unittest.mock import patch

ROOT = pathlib.Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("kilani_vercel_adapter_under_test", ROOT / "api" / "index.py")
vercel_adapter = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(vercel_adapter)

SERVER_SPEC = importlib.util.spec_from_file_location("kilani_vercel_server_under_test", ROOT / "server.py")
server = importlib.util.module_from_spec(SERVER_SPEC)
SERVER_SPEC.loader.exec_module(server)


class VercelRoutingTest(unittest.TestCase):
    def test_rewrite_route_is_restored_and_other_query_parameters_survive(self):
        restored = vercel_adapter._restore_original_path(
            "/api?__vercel_route=%2Fapi%2Fsite-status&cache=no"
        )
        self.assertEqual(restored, "/api/site-status?cache=no")

    def test_route_rejects_ambiguous_or_external_values(self):
        self.assertEqual(
            vercel_adapter._restore_original_path(
                "/api?__vercel_route=%2Fadmin&__vercel_route=%2Fowner"
            ),
            "/__invalid_vercel_route__",
        )
        self.assertEqual(
            vercel_adapter._restore_original_path(
                "/api?__vercel_route=https%3A%2F%2Fexample.test%2F"
            ),
            "/__invalid_vercel_route__",
        )
        self.assertEqual(
            vercel_adapter._restore_original_path("/api?__vercel_route=%2F%2Felsewhere"),
            "/__invalid_vercel_route__",
        )

    def test_vercel_config_publishes_only_public_homepage_and_routes_private_pages(self):
        config = json.loads((ROOT / "vercel.json").read_text(encoding="utf-8"))
        self.assertEqual(config["outputDirectory"], "vercel-static")
        self.assertEqual(config["buildCommand"], "python3 vercel_build.py")
        routes = {item["source"]: item["destination"] for item in config["rewrites"]}
        self.assertEqual(routes["/admin.html"], "/api?__vercel_route=/admin.html")
        self.assertIn("/api/:path*", routes)
        self.assertIn("index.html", config["functions"]["api/index.py"]["includeFiles"])

    def test_vercel_handler_restores_route_and_dispatches_through_existing_backend(self):
        httpd = ThreadingHTTPServer(("127.0.0.1", 0), vercel_adapter.handler)
        thread = threading.Thread(target=httpd.serve_forever, daemon=True)
        thread.start()
        try:
            url = "http://127.0.0.1:%d/api?__vercel_route=%%2Fhealthz" % httpd.server_address[1]
            with urllib.request.urlopen(url, timeout=3) as response:
                self.assertEqual(response.status, 200)
                payload = json.loads(response.read().decode("utf-8"))
            self.assertTrue(payload["ok"])
        finally:
            httpd.shutdown()
            httpd.server_close()
            thread.join(timeout=3)


class VercelProductionSafetyTest(unittest.TestCase):
    def test_vercel_requires_stable_session_secret_in_environment(self):
        with tempfile.TemporaryDirectory() as directory:
            secret_path = pathlib.Path(directory) / ".session_secret"
            secret_path.write_bytes(b"a" * 32)
            old = server.SECRET_FILE
            try:
                server.SECRET_FILE = secret_path
                with patch.dict("os.environ", {"VERCEL": "1", "SESSION_SECRET": ""}, clear=False):
                    with self.assertRaisesRegex(RuntimeError, "SESSION_SECRET"):
                        server.secret()
            finally:
                server.SECRET_FILE = old

    def test_vercel_requires_stable_member_pepper_in_environment(self):
        with tempfile.TemporaryDirectory() as directory:
            pepper_path = pathlib.Path(directory) / ".member_code_pepper"
            pepper_path.write_bytes(b"b" * 32)
            old = server.MEMBER_CODE_PEPPER_FILE
            try:
                server.MEMBER_CODE_PEPPER_FILE = pepper_path
                with patch.dict("os.environ", {"VERCEL": "1", "MEMBER_CODE_PEPPER": ""}, clear=False):
                    with self.assertRaisesRegex(RuntimeError, "MEMBER_CODE_PEPPER"):
                        server.member_code_pepper()
            finally:
                server.MEMBER_CODE_PEPPER_FILE = old

    def test_empty_vercel_database_requires_a_private_initial_coach_pin(self):
        with patch.dict("os.environ", {"VERCEL": "1", "COACH_INITIAL_PIN": ""}, clear=False):
            with self.assertRaisesRegex(RuntimeError, "COACH_INITIAL_PIN"):
                server._new_state()
        with patch.dict("os.environ", {"VERCEL": "1", "COACH_INITIAL_PIN": "12345678"}, clear=False):
            state = server._new_state()
            self.assertTrue(server.verify_pin("12345678", state["pin"]))

    def test_vercel_rejects_local_json_storage(self):
        old = server.STORAGE_BACKEND
        try:
            server.STORAGE_BACKEND = "file"
            with patch.dict("os.environ", {"VERCEL": "1"}, clear=False):
                with self.assertRaisesRegex(RuntimeError, "persistent MySQL"):
                    server.load_state()
        finally:
            server.STORAGE_BACKEND = old

    def test_vercel_uses_platform_forwarded_client_ip(self):
        request = server.Handler.__new__(server.Handler)
        request.headers = email.message.Message()
        request.headers["X-Vercel-Forwarded-For"] = "203.0.113.42"
        request.client_address = ("127.0.0.1", 12345)
        with patch.dict("os.environ", {"VERCEL": "1"}, clear=False):
            self.assertEqual(request.client_ip(), "203.0.113.42")

    def test_mysql_pool_size_is_bounded(self):
        with patch.dict("os.environ", {"MYSQL_POOL_SIZE": "3"}, clear=False):
            self.assertEqual(server._mysql_pool_size(), 3)
        with patch.dict("os.environ", {"MYSQL_POOL_SIZE": "20"}, clear=False):
            with self.assertRaisesRegex(RuntimeError, "between 1 and 10"):
                server._mysql_pool_size()


if __name__ == "__main__":
    unittest.main()

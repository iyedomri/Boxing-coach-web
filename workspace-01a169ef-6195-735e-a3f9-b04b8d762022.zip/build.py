#!/usr/bin/env python3
"""Build the self-contained public site, coach dashboard, and owner console."""
import base64
import pathlib
import re

ROOT = pathlib.Path(__file__).parent
SRC = ROOT / "src"

FILES = {
    "coachaction": "coach-action",
    "coachring": "coach-ring",
    "coachbag": "coach-bag",
    "posteradults": "poster-adults",
    "posterprivate": "poster-private",
}


def b64(name):
    data = base64.b64encode((ROOT / "assets" / f"{FILES.get(name, name)}.webp").read_bytes()).decode()
    return "data:image/webp;base64," + data


def inline_images(html):
    for name in sorted(set(re.findall(r"\{\{IMG:([a-z]+)\}\}", html))):
        print("  embedding:", name)
        html = html.replace("{{IMG:%s}}" % name, b64(name))
    return html


def page(title, description, css_files, body, js_files, extra_head=""):
    css = "\n".join((SRC / f).read_text(encoding="utf-8") for f in css_files)
    js = "\n".join((SRC / f).read_text(encoding="utf-8") for f in js_files)
    body = inline_images(body)
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{title}</title>
<meta name="description" content="{description}">
<meta name="theme-color" content="#1E2A22">
<meta name="robots" content="noindex, nofollow" />
<link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><rect width='100' height='100' rx='50' fill='%231E2A22'/><text x='50' y='63' font-family='Helvetica' font-size='34' font-weight='bold' fill='%23E4A02C' text-anchor='middle'>BK</text></svg>">{extra_head}
<style>
{css}
</style>
</head>
<body>
{body}
<script>
{js}
</script>
</body>
</html>
"""


# ---------------------------------------------------------------- website --
site_body = (SRC / "body.html").read_text(encoding="utf-8")
site = page(
    "Kilani — Boxing Club · Private Coaching &amp; Boxe Anglaise · Ribat Monastir",
    "Private 1:1 coaching and boxe anglaise classes (adultes, juniors, cadets) with Mohamed Ben Kilani, "
    "2x Sahel Regional Champion, at Boxing Club in Ribat, Monastir. Monthly abonnements with training plan, "
    "nutrition and session tracking. Website made by Iyed Omri (@iyver).",
    ["styles.css"], site_body, ["app.js"],
)
(ROOT / "index.html").write_text(site, encoding="utf-8")
print(f"built index.html · {(ROOT / 'index.html').stat().st_size / 1024:.0f} KB")

# ---------------------------------------------------------------- coach app --
admin_body = (SRC / "admin-body.html").read_text(encoding="utf-8")
admin = page(
    "Coach space — Boxing Club Kilani",
    "Private coaching dashboard: members, attendance, monthly plan, payments.",
    ["styles.css", "admin.css"], admin_body, ["admin.js"],
)
(ROOT / "admin.html").write_text(admin, encoding="utf-8")
print(f"built admin.html · {(ROOT / 'admin.html').stat().st_size / 1024:.0f} KB")

# server-side login page (used by server.py)
(ROOT / "login.html").write_text((SRC / "login.html").read_text(encoding="utf-8"), encoding="utf-8")
print("built login.html")

# Separate creator-only operations console. The HTML shell has no private data;
# all owner-only reads and actions are enforced by authenticated server APIs.
owner_body = (SRC / "owner-body.html").read_text(encoding="utf-8")
owner = page(
    "Creator Owner Console — Boxing Club Kilani",
    "Private site operations and time-limited creator approvals.",
    ["styles.css", "owner.css"], owner_body, ["owner.js"],
)
(ROOT / "owner.html").write_text(owner, encoding="utf-8")
print(f"built owner.html · {(ROOT / 'owner.html').stat().st_size / 1024:.0f} KB")

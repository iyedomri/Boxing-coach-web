"""Pure unit tests for MySQL state serialization; no MySQL server required."""
import importlib.util
import json
import pathlib
import tempfile
import unittest
from unittest.mock import patch

ROOT = pathlib.Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("kilani_mysql_storage_under_test", ROOT / "server.py")
server = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(server)


class MySQLStorageUnitTest(unittest.TestCase):
    def test_state_serializes_to_mysql_json_columns_and_access_hash_rows(self):
        state = {
            "pin": "sha256$salt$hash",
            "roster": json.dumps([{"id": "m1", "name": "Member"}]),
            "payments": "[]",
            "plans": json.dumps({"Fat loss": {"month": "October"}}),
            "notes": "private coach note",
            "offers": json.dumps({"plans": {"p4": {"active": True}}, "addons": []}),
            "memberAccess": {"m1": "sha256$salt$digest"},
        }
        pin, roster, payments, plans, notes, offers, access = server._mysql_state_values(state)
        self.assertEqual(pin, state["pin"])
        self.assertEqual(json.loads(roster), [{"id": "m1", "name": "Member"}])
        self.assertEqual(json.loads(payments), [])
        self.assertEqual(json.loads(plans), {"Fat loss": {"month": "October"}})
        self.assertEqual(notes, "private coach note")
        self.assertEqual(json.loads(offers)["plans"]["p4"]["active"], True)
        self.assertEqual(access, [("m1", "sha256$salt$digest")])

    def test_owner_control_is_serialized_into_its_separate_mysql_table(self):
        class CaptureCursor:
            def __init__(self):
                self.calls = []
            def execute(self, sql, params=None):
                self.calls.append((sql, params))
            def executemany(self, sql, params):
                self.calls.append((sql, list(params)))

        state = server._new_state()
        state["ownerControl"]["settings"]["maintenanceMode"] = True
        cursor = CaptureCursor()
        server._mysql_store_state(cursor, state)
        owner_call = next(call for call in cursor.calls if "kilani_owner_control" in call[0])
        stored = json.loads(owner_call[1][0])
        self.assertTrue(stored["settings"]["maintenanceMode"])
        self.assertTrue(stored["settings"]["paymentsPaused"])
        self.assertTrue(stored["settings"]["bookingsPaused"])

    def test_mysql_backend_requires_connection_settings(self):
        names = ("MYSQL_HOST", "MYSQL_USER", "MYSQL_PASSWORD", "MYSQL_DATABASE", "MYSQL_PORT")
        with patch.dict("os.environ", {name: "" for name in names}, clear=False):
            with self.assertRaisesRegex(RuntimeError, "MYSQL_HOST"):
                server._mysql_config()

    def test_mysql_port_range_is_validated(self):
        config_values = {
            "MYSQL_HOST": "localhost", "MYSQL_PORT": "65536",
            "MYSQL_USER": "app", "MYSQL_PASSWORD": "test-only",
            "MYSQL_DATABASE": "kilani",
        }
        with patch.dict("os.environ", config_values, clear=False):
            with self.assertRaisesRegex(RuntimeError, "between 1 and 65535"):
                server._mysql_config()

    def test_remote_mysql_requires_verified_tls(self):
        config_values = {
            "MYSQL_HOST": "db.example.test", "MYSQL_PORT": "3306",
            "MYSQL_USER": "app", "MYSQL_PASSWORD": "test-only",
            "MYSQL_DATABASE": "kilani", "MYSQL_SSL_CA": "",
            "MYSQL_SSL_DISABLED": "",
        }
        with patch.dict("os.environ", config_values, clear=False):
            config = server._mysql_config()
            self.assertTrue(config["ssl_verify_cert"])
            self.assertTrue(config["ssl_verify_identity"])
            self.assertNotIn("ssl_disabled", config)
        with patch.dict("os.environ", dict(config_values, MYSQL_SSL_DISABLED="1"), clear=False):
            with self.assertRaisesRegex(RuntimeError, "remote host"):
                server._mysql_config()

    def test_local_mysql_can_explicitly_disable_tls_for_development(self):
        config_values = {
            "MYSQL_HOST": "127.0.0.1", "MYSQL_PORT": "3306",
            "MYSQL_USER": "app", "MYSQL_PASSWORD": "test-only",
            "MYSQL_DATABASE": "kilani", "MYSQL_SSL_CA": "",
            "MYSQL_SSL_DISABLED": "1",
        }
        with patch.dict("os.environ", config_values, clear=False):
            config = server._mysql_config()
        self.assertTrue(config["ssl_disabled"])
        self.assertNotIn("ssl_verify_cert", config)

    def test_mysql_json_column_decoder_accepts_connector_values_and_text(self):
        self.assertEqual(server._decode_json_value({"key": 1}, {}), {"key": 1})
        self.assertEqual(server._decode_json_value('["a", "b"]', []), ["a", "b"])
        self.assertEqual(server._decode_json_value(b'{"ok":true}', {}), {"ok": True})
        self.assertEqual(server._decode_json_value("not-json", {}), {})

    def test_legacy_json_state_is_available_for_first_database_import(self):
        with tempfile.TemporaryDirectory() as directory:
            path = pathlib.Path(directory) / "state.json"
            old_path = server.STATE_FILE
            try:
                server.STATE_FILE = path
                legacy = {
                    "pin": "sha256$old$salted-hash",
                    "roster": '[{"id":"legacy-member"}]',
                    "memberAccess": {"legacy-member": "sha256$salt$code-hash"},
                }
                path.write_text(json.dumps(legacy), encoding="utf-8")
                imported = server._load_legacy_state()
                self.assertEqual(json.loads(imported["roster"]), [{"id": "legacy-member"}])
                self.assertEqual(imported["memberAccess"]["legacy-member"], "sha256$salt$code-hash")
                self.assertEqual(imported["pin"], legacy["pin"])
                self.assertIn("offers", imported)
            finally:
                server.STATE_FILE = old_path


if __name__ == "__main__":
    unittest.main()

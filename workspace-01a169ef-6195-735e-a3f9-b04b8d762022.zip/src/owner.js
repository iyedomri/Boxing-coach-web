(function () {
  'use strict';
  var $ = function (selector) { return document.querySelector(selector); };
  var state = { role: 'none', scope: '', settings: {}, timer: null };

  function esc(value) {
    return String(value == null ? '' : value).replace(/[&<>"']/g, function (ch) {
      return ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' })[ch];
    });
  }
  function when(seconds) {
    if (!seconds) return '—';
    return new Date(seconds * 1000).toLocaleString('en-GB', { day:'2-digit', month:'short', hour:'2-digit', minute:'2-digit' });
  }
  function say(id, text, good) {
    var el = $(id);
    if (!el) return;
    el.textContent = text || '';
    el.style.color = good ? '#536b3a' : '';
  }
  async function api(url, options) {
    var response = await fetch(url, Object.assign({ cache:'no-store', credentials:'same-origin' }, options || {}));
    var data = {};
    try { data = await response.json(); } catch (e) {}
    if (!response.ok) throw new Error(data.error || ('Request failed (' + response.status + ')'));
    return data;
  }
  function showOnly(id) {
    ['#ownerLoginPanel','#ownerCoachPanel','#ownerDashboard'].forEach(function (selector) {
      var el = $(selector); if (el) el.hidden = selector !== id;
    });
  }
  function setSwitches(settings, allowEdit) {
    settings = settings || {};
    [['#maintenanceMode','maintenanceMode'],['#paymentsPaused','paymentsPaused'],['#bookingsPaused','bookingsPaused']].forEach(function (pair) {
      var input = $(pair[0]); input.checked = settings[pair[1]] === true; input.disabled = !allowEdit;
    });
    $('#saveOwnerControls').hidden = !allowEdit;
    $('#ownerControlCard').hidden = !allowEdit;
    $('#siteStateChip').textContent = settings.maintenanceMode ? 'MAINTENANCE' : 'LIVE SITE';
    $('#siteStateChip').classList.toggle('owner-chip--warn', !!settings.maintenanceMode);
  }
  function renderRequests(requests) {
    var host = $('#ownerRequestList');
    var pending = (requests || []).filter(function (item) { return item.status === 'pending'; }).length;
    $('#requestCount').textContent = pending + ' PENDING';
    if (!requests || !requests.length) {
      host.innerHTML = '<p class="owner-empty">No creator-access requests yet.</p>';
      return;
    }
    host.innerHTML = requests.map(function (item) {
      var scope = item.scope === 'site_controls' ? 'Site controls' : 'D17 setup status';
      var status = String(item.status || 'unknown').replace(/_/g, ' ');
      var actions = '';
      if (item.status === 'pending') {
        actions = '<button class="owner-button owner-button--primary" data-decision="approve" data-request="' + esc(item.id) + '">Approve · 30 min</button>' +
          '<button class="owner-button owner-button--quiet" data-decision="deny" data-request="' + esc(item.id) + '">Deny</button>';
      } else if (item.status === 'approved' && item.grantExpiresAt * 1000 > Date.now()) {
        actions = '<button class="owner-button owner-button--danger" data-revoke="' + esc(item.id) + '">Revoke now</button>';
      }
      var until = item.status === 'approved' ? ' · expires ' + when(item.grantExpiresAt) : '';
      return '<article class="owner-request"><div class="owner-request__main">' +
        '<div class="owner-request__meta"><span class="owner-request__scope">' + esc(scope) + '</span>' +
        '<span class="owner-request__status">' + esc(status) + until + '</span></div>' +
        '<p class="owner-request__reason">' + esc(item.reason) + '</p>' +
        '<small class="owner-request__time">Requested ' + esc(when(item.requestedAt)) + '</small></div>' +
        '<div class="owner-request__actions">' + actions + '</div></article>';
    }).join('');
  }
  function renderAudit(items) {
    var host = $('#ownerAuditList');
    if (!items || !items.length) { host.innerHTML = '<p class="owner-empty">Owner actions will appear here.</p>'; return; }
    host.innerHTML = items.map(function (item) {
      return '<div class="owner-audit-row"><time>' + esc(when(item.at)) + '</time><span><b>' + esc(item.actor || 'user') + '</b> · ' + esc(item.action || '') + '</span></div>';
    }).join('');
  }
  function render(data) {
    state.role = data.role || 'none';
    state.scope = data.scope || '';
    if (state.role === 'owner') {
      showOnly('#ownerDashboard');
      $('#ownerRoleLabel').textContent = 'CREATOR OWNER';
      $('#ownerWelcome').textContent = 'Site operations';
      $('#ownerExpiry').textContent = 'Full creator access. Owner key is separate from Kilani’s coach PIN.';
      setSwitches(data.settings, true);
      renderRequests(data.requests || []);
      renderAudit(data.audit || []);
      $('#ownerRequestsCard').hidden = false;
      $('#ownerAuditCard').hidden = false;
    } else if (state.role === 'temporary') {
      showOnly('#ownerDashboard');
      $('#ownerRoleLabel').textContent = 'TEMPORARY · ' + (state.scope === 'site_controls' ? 'SITE CONTROLS' : 'PAYMENT STATUS');
      $('#ownerWelcome').textContent = 'Creator-approved access';
      $('#ownerExpiry').textContent = 'Expires ' + when(data.expiresAt) + '. This grant is tied to Kilani’s coach session and is not permanent.';
      var canControls = state.scope === 'site_controls';
      setSwitches(data.settings, canControls);
      $('#ownerRequestsCard').hidden = true;
      $('#ownerAuditCard').hidden = true;
    } else if (state.role === 'coach_needs_request') {
      showOnly('#ownerCoachPanel');
    } else {
      showOnly('#ownerLoginPanel');
      if (data.ownerConfigured === false) say('#ownerLoginMessage', 'Owner access is not configured. Set a private OWNER_ACCESS_KEY (32+ characters) in the deployment environment, then redeploy.');
    }
    var payment = data.payment || {};
    $('#d17CheckoutState').textContent = payment.integrationReady ? 'Connected' : 'In progress · not live';
    $('#paymentStateChip').textContent = payment.integrationReady ? 'CONNECTED' : 'IN PROGRESS';
    $('#paymentStateChip').classList.toggle('owner-chip--warn', !payment.integrationReady);
    $('#payoutLabel').textContent = payment.payoutLabel || 'Managed securely in D17 merchant tools';
    $('#d17Message').textContent = payment.message || 'D17 integration is in progress; merchant setup and verification are still required.';
  }
  async function refresh() {
    try { render(await api('/api/owner/session')); }
    catch (error) {
      showOnly('#ownerLoginPanel');
      say('#ownerLoginMessage', error.message || 'Owner API is unavailable. Open this on the protected server.');
    }
  }
  async function refreshOwnerFeed() {
    try {
      var data = await api('/api/owner/session');
      if (state.role !== 'owner' || data.role !== 'owner') { render(data); return; }
      renderRequests(data.requests || []);
      renderAudit(data.audit || []);
    } catch (e) {}
  }
  async function checkTemporaryGrant() {
    try {
      var data = await api('/api/owner/session');
      if (data.role !== 'temporary' || data.scope !== state.scope) { render(data); return; }
      $('#ownerExpiry').textContent = 'Expires ' + when(data.expiresAt) + '. This grant is tied to Kilani’s coach session and is not permanent.';
    } catch (e) { refresh(); }
  }
  async function saveSettings() {
    var payload = {
      maintenanceMode: $('#maintenanceMode').checked,
      paymentsPaused: $('#paymentsPaused').checked,
      bookingsPaused: $('#bookingsPaused').checked
    };
    $('#saveOwnerControls').disabled = true;
    try {
      var data = await api('/api/owner/settings', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(payload) });
      setSwitches(data.settings, true);
      say('#ownerControlMessage', 'Site switches saved.', true);
    } catch (error) {
      say('#ownerControlMessage', error.message || 'Could not save controls.');
    } finally { $('#saveOwnerControls').disabled = false; }
  }
  async function decide(requestId, approve) {
    var promptText = approve
      ? 'Approve this exact request for 30 minutes? It will be limited to the requested scope.'
      : 'Deny this access request?';
    if (!window.confirm(promptText)) return;
    try {
      await api('/api/owner/decision', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({requestId:requestId,approve:approve}) });
      await refresh();
    } catch (error) { window.alert(error.message || 'Decision could not be saved.'); }
  }
  async function revoke(requestId) {
    if (!window.confirm('Revoke Kilani’s temporary access now?')) return;
    try {
      await api('/api/owner/revoke', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({requestId:requestId}) });
      await refresh();
    } catch (error) { window.alert(error.message || 'Grant could not be revoked.'); }
  }

  document.addEventListener('DOMContentLoaded', function () {
    $('#ownerLoginForm').addEventListener('submit', async function (event) {
      event.preventDefault();
      var key = $('#ownerKey').value;
      try {
        await api('/api/owner/login', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({key:key}) });
        $('#ownerKey').value = '';
        await refresh();
      } catch (error) { say('#ownerLoginMessage', error.message || 'Sign-in failed.'); }
    });
    $('#saveOwnerControls').addEventListener('click', saveSettings);
    $('#ownerRefreshRequests').addEventListener('click', refreshOwnerFeed);
    $('#ownerLogout').addEventListener('click', async function () {
      if (state.role === 'temporary') { window.location.href = '/admin.html'; return; }
      try { await api('/api/owner/logout', { method:'POST' }); } catch (e) {}
      window.location.href = '/owner';
    });
    $('#ownerRequestList').addEventListener('click', function (event) {
      var decision = event.target.closest('[data-decision]');
      if (decision) { decide(decision.getAttribute('data-request'), decision.getAttribute('data-decision') === 'approve'); return; }
      var revokeButton = event.target.closest('[data-revoke]');
      if (revokeButton) revoke(revokeButton.getAttribute('data-revoke'));
    });
    refresh();
    state.timer = setInterval(function () {
      if (state.role === 'temporary') checkTemporaryGrant();
      else if (state.role === 'owner') refreshOwnerFeed();
    }, 15000);
  });
})();

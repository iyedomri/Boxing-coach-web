"""Owner Console and temporary creator-grant API regressions (file-store tests)."""
import importlib.util
import json
import os
import pathlib
import re
import socket
import tempfile
import threading
import unittest
from unittest.mock import patch

ROOT = pathlib.Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("kilani_owner_api_under_test", ROOT / "server.py")
server = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(server)


class QuietHandler(server.Handler):
    def log_message(self, *_args):
        pass


class DummyServer:
    pass


class OwnerAPITest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.old_state = server.STATE_FILE
        self.old_secret = server.SECRET_FILE
        self.old_storage = server.STORAGE_BACKEND
        self.old_key = os.environ.get("OWNER_ACCESS_KEY")
        self.old_secret_env = os.environ.get("SESSION_SECRET")
        server.STATE_FILE = pathlib.Path(self.tmp.name) / "state.json"
        server.SECRET_FILE = pathlib.Path(self.tmp.name) / ".session_secret"
        server.STORAGE_BACKEND = "file"
        os.environ["OWNER_ACCESS_KEY"] = "owner-test-key-with-at-least-32-bytes-1234"
        os.environ["SESSION_SECRET"] = "stable-test-session-secret-at-least-32-bytes"
        server._owner_attempts.clear()
        server._attempts.clear()
        server.save_state(server._new_state())
        state = server.load_state()
        self.coach_cookie = "kilani_coach=" + server.make_token(state["pin"])
        self.owner_cookie = None

    def tearDown(self):
        server.STATE_FILE = self.old_state
        server.SECRET_FILE = self.old_secret
        server.STORAGE_BACKEND = self.old_storage
        if self.old_key is None:
            os.environ.pop("OWNER_ACCESS_KEY", None)
        else:
            os.environ["OWNER_ACCESS_KEY"] = self.old_key
        if self.old_secret_env is None:
            os.environ.pop("SESSION_SECRET", None)
        else:
            os.environ["SESSION_SECRET"] = self.old_secret_env
        server._owner_attempts.clear()
        server._attempts.clear()
        self.tmp.cleanup()

    def request(self, method, path, body=None, cookie=None, extra_headers=None):
        handler_sock, client_sock = socket.socketpair()
        client_sock.settimeout(3)
        payload = "" if body is None else (body if isinstance(body, str) else json.dumps(body))
        request = f"{method} {path} HTTP/1.1\r\nHost: localhost\r\nConnection: close\r\n"
        for key, value in (extra_headers or {}).items():
            request += f"{key}: {value}\r\n"
        if payload:
            request += "Content-Type: application/json\r\n" + f"Content-Length: {len(payload.encode())}\r\n"
        if cookie:
            request += f"Cookie: {cookie}\r\n"
        client_sock.sendall((request + "\r\n" + payload).encode())

        def run_handler():
            try:
                QuietHandler(handler_sock, ("127.0.0.1", 45679), DummyServer())
            finally:
                handler_sock.close()
        thread = threading.Thread(target=run_handler, daemon=True)
        thread.start()
        chunks = []
        try:
            while True:
                chunk = client_sock.recv(65536)
                if not chunk:
                    break
                chunks.append(chunk)
        finally:
            client_sock.close()
        thread.join(timeout=3)
        raw = b"".join(chunks).decode("latin1")
        headers, separator, response = raw.partition("\r\n\r\n")
        self.assertTrue(separator, f"No HTTP response: {raw!r}")
        status = int(headers.splitlines()[0].split()[1])
        return status, headers, response

    @staticmethod
    def cookie_from(headers):
        match = re.search(r"Set-Cookie: ([^;]+)", headers, re.IGNORECASE)
        if not match:
            raise AssertionError("Expected Set-Cookie header")
        return match.group(1)

    def owner_login(self):
        status, headers, body = self.request("POST", "/api/owner/login", {"key": os.environ["OWNER_ACCESS_KEY"]})
        self.assertEqual(status, 200, body)
        self.assertIn("HttpOnly", headers)
        self.assertIn("SameSite=Strict", headers)
        self.owner_cookie = self.cookie_from(headers)
        return self.owner_cookie

    def request_access(self, scope="site_controls", reason="Need to pause the booking controls"):
        status, _, body = self.request(
            "POST", "/api/owner/request", {"scope": scope, "reason": reason}, self.coach_cookie
        )
        self.assertEqual(status, 201, body)
        return json.loads(body)["request"]["id"]

    def test_owner_key_minimum_length_is_enforced(self):
        with patch.dict(os.environ, {"OWNER_ACCESS_KEY": "too-short"}):
            with self.assertRaisesRegex(RuntimeError, "at least 32 bytes"):
                server.owner_access_key()
            status, _, body = self.request("POST", "/api/owner/login", {"key": "too-short"})
        self.assertEqual(status, 503, body)

    def test_scoped_grant_expires_after_exactly_30_minutes_and_site_status_stays_disabled(self):
        fixed_now = int(server.time.time())
        with patch.object(server.time, "time", return_value=fixed_now):
            self.coach_cookie = "kilani_coach=" + server.make_token(server.load_state()["pin"])
            request_id = self.request_access()
            owner = self.owner_login()
            status, _, body = self.request("POST", "/api/owner/decision", {
                "requestId": request_id, "approve": True,
            }, owner)
            self.assertEqual(status, 200, body)
            decision = json.loads(body)["request"]
            self.assertEqual(decision["grantExpiresAt"] - decision["decisionAt"], 30 * 60)

            status, _, body = self.request("GET", "/api/owner/session", cookie=self.coach_cookie)
            self.assertEqual(status, 200, body)
            payload = json.loads(body)
            self.assertEqual(payload["role"], "temporary")
            self.assertEqual(payload["scope"], "site_controls")
            self.assertEqual(payload["expiresAt"], decision["grantExpiresAt"])
            status, _, body = self.request("POST", "/api/owner/request", {
                "scope": "payment_status", "reason": "Check payment readiness while grant is active",
            }, self.coach_cookie)
            self.assertEqual(status, 409, body)

            status, _, body = self.request("POST", "/api/owner/settings", {
                "maintenanceMode": True, "paymentsPaused": False, "bookingsPaused": False,
            }, self.coach_cookie)
            self.assertEqual(status, 200, body)
            saved = json.loads(body)["settings"]
            self.assertTrue(saved["maintenanceMode"])
            self.assertFalse(saved["paymentsPaused"])
            self.assertFalse(saved["bookingsPaused"])

            status, _, body = self.request("GET", "/api/site-status")
            self.assertEqual(status, 200, body)
            public = json.loads(body)
            self.assertTrue(public["maintenanceMode"])
            self.assertFalse(public["paymentsEnabled"])
            self.assertFalse(public["bookingsEnabled"])
            self.assertFalse(public["checkoutReady"])
            self.assertEqual(public["provider"], "D17")

            with patch.object(server.time, "time", return_value=decision["grantExpiresAt"]):
                status, _, body = self.request("GET", "/api/owner/session", cookie=self.coach_cookie)
                self.assertEqual(status, 200)
                self.assertEqual(json.loads(body)["role"], "coach_needs_request")
                status, _, body = self.request("POST", "/api/owner/settings", {
                    "maintenanceMode": False,
                }, self.coach_cookie)
                self.assertEqual(status, 401, body)

    def test_payment_status_scope_is_read_only_and_owner_can_deny_requests(self):
        request_id = self.request_access("payment_status", "Need to check whether D17 is connected")
        owner = self.owner_login()
        status, _, body = self.request("POST", "/api/owner/decision", {
            "requestId": request_id, "approve": True,
        }, owner)
        self.assertEqual(status, 200, body)
        status, _, body = self.request("POST", "/api/owner/settings", {
            "maintenanceMode": True,
        }, self.coach_cookie)
        self.assertEqual(status, 403, body)
        status, _, body = self.request("GET", "/api/owner/session", cookie=self.coach_cookie)
        self.assertEqual(status, 200)
        payload = json.loads(body)
        self.assertEqual(payload["role"], "temporary")
        self.assertIsNone(payload["settings"])
        self.assertFalse(payload["payment"]["integrationReady"])

        second_session_time = int(server.time.time()) + 2
        with patch.object(server.time, "time", return_value=second_session_time):
            self.coach_cookie = "kilani_coach=" + server.make_token(server.load_state()["pin"])
            denied_id = self.request_access("payment_status", "Need the creator to review a D17 issue")
            status, _, body = self.request("POST", "/api/owner/decision", {
                "requestId": denied_id, "approve": False,
            }, owner)
            self.assertEqual(status, 200, body)
        self.assertEqual(json.loads(body)["request"]["status"], "denied")
        state = server.load_state()["ownerControl"]
        self.assertTrue(any(row["action"] == "temporary access denied" for row in state["audit"]))

    def test_owner_approval_queue_requires_owner_and_grants_are_revocable(self):
        status, _, body = self.request("POST", "/api/owner/request", {
            "scope": "site_controls", "reason": "Change maintenance controls",
        })
        self.assertEqual(status, 401, body)
        request_id = self.request_access()
        status, _, body = self.request("GET", "/api/owner/request-status", cookie=self.coach_cookie)
        self.assertEqual(status, 200, body)
        own = json.loads(body)["requests"]
        self.assertEqual(len(own), 1)
        self.assertEqual(own[0]["id"], request_id)
        self.assertNotIn("coachTokenFingerprint", body)

        status, _, body = self.request("GET", "/api/owner/session")
        self.assertEqual(json.loads(body)["role"], "none")
        self.assertEqual(status, 200)
        owner = self.owner_login()
        status, _, body = self.request("GET", "/api/owner/session", cookie=owner)
        owner_payload = json.loads(body)
        self.assertEqual(owner_payload["role"], "owner")
        self.assertEqual(owner_payload["requests"][0]["id"], request_id)
        self.assertNotIn("coachTokenFingerprint", body)

        status, _, body = self.request("POST", "/api/owner/decision", {
            "requestId": request_id, "approve": True,
        })
        self.assertEqual(status, 401, body)
        status, _, body = self.request("POST", "/api/owner/decision", {
            "requestId": request_id, "approve": True,
        }, owner)
        self.assertEqual(status, 200, body)
        status, _, body = self.request("POST", "/api/owner/revoke", {"requestId": request_id}, owner)
        self.assertEqual(status, 200, body)
        self.assertEqual(server.load_state()["ownerControl"]["requests"][0]["status"], "revoked")
        status, _, body = self.request("GET", "/api/owner/session", cookie=self.coach_cookie)
        self.assertEqual(json.loads(body)["role"], "coach_needs_request")

    def test_maintenance_blocks_public_routes_but_keeps_owner_console_available(self):
        owner = self.owner_login()
        state = server.load_state()
        state["ownerControl"]["settings"]["maintenanceMode"] = True
        server.save_state(state)
        status, _, _ = self.request("GET", "/")
        self.assertEqual(status, 503)
        status, _, body = self.request("GET", "/owner")
        self.assertEqual(status, 200)
        self.assertIn("Creator controls", body)
        status, _, body = self.request("GET", "/api/owner/session", cookie=owner)
        self.assertEqual(status, 200)
        self.assertEqual(json.loads(body)["role"], "owner")
        status, _, body = self.request("GET", "/", cookie=owner)
        self.assertEqual(status, 200)
        self.assertIn("Kilani", body)


if __name__ == "__main__":
    unittest.main()

"""Authentication and credential-storage security regression tests."""
import hashlib
import importlib.util
import json
import pathlib
import tempfile
import unittest
from unittest.mock import patch

ROOT = pathlib.Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("kilani_auth_security_under_test", ROOT / "server.py")
server = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(server)


class AuthSecurityTest(unittest.TestCase):
    def test_pin_hash_uses_pbkdf2_and_legacy_sha256_is_upgraded(self):
        fresh = server.hash_pin("12345678")
        self.assertTrue(fresh.startswith("pbkdf2$"))
        self.assertTrue(server.verify_pin("12345678", fresh))
        self.assertFalse(server.verify_pin("87654321", fresh))
        self.assertFalse(server.pin_needs_rehash(fresh))

        salt = "abc123legacy"
        legacy = "sha256$%s$%s" % (
            salt, hashlib.sha256((salt + ":12345678:coach").encode()).hexdigest()
        )
        self.assertTrue(server.verify_pin("12345678", legacy))
        self.assertTrue(server.pin_needs_rehash(legacy))

    def test_member_code_hash_uses_pbkdf2_and_accepts_legacy_hash_for_upgrade(self):
        with patch.dict("os.environ", {"MEMBER_CODE_PEPPER": "test-only-pepper-key-with-more-than-32-bytes"}):
            fresh = server.make_member_code_hash("m-1", "12345678")
            self.assertTrue(fresh.startswith("pbkdf2$"))
            self.assertEqual(len(fresh.split("$")), 5)
            self.assertEqual(server.member_code_lookup_value(fresh), server.member_code_lookup("12345678"))
            self.assertTrue(server.verify_member_code("m-1", "12345678", fresh))
            self.assertFalse(server.verify_member_code("m-2", "12345678", fresh))
            self.assertFalse(server.member_code_needs_rehash(fresh))

            salt = "abc123legacy"
            legacy = "sha256$%s$%s" % (
                salt, hashlib.sha256((salt + ":m-1:12345678:member").encode()).hexdigest()
            )
            self.assertTrue(server.verify_member_code("m-1", "12345678", legacy))
            self.assertTrue(server.member_code_needs_rehash(legacy))

    def test_changing_coach_pin_invalidates_previously_signed_cookie(self):
        with tempfile.TemporaryDirectory() as directory:
            old_backend, old_state, old_secret = server.STORAGE_BACKEND, server.STATE_FILE, server.SECRET_FILE
            try:
                server.STORAGE_BACKEND = "file"
                server.STATE_FILE = pathlib.Path(directory) / "state.json"
                server.SECRET_FILE = pathlib.Path(directory) / ".session_secret"
                state = server._new_state()
                server.save_state(state)
                token = server.make_token(state["pin"])
                self.assertTrue(server.token_ok(token))
                state["pin"] = server.hash_pin("12345679")
                server.save_state(state)
                self.assertFalse(server.token_ok(token))
            finally:
                server.STORAGE_BACKEND, server.STATE_FILE, server.SECRET_FILE = old_backend, old_state, old_secret


if __name__ == "__main__":
    unittest.main()

# Security audit report — 23 October 2026

## Executive summary

The site and its Python backend were reviewed for authentication, member-data isolation, Owner Console grants, request handling, output safety, static-file exposure, session handling, maintenance controls, and MySQL transport configuration. The review added credential hardening, request guards, response security headers, trusted-proxy handling, owner-only APIs, and regression tests.

**Result:** all 36 automated tests and the Python/JavaScript syntax checks passed after adding Vercel deployment support. This is a code-level audit with regression tests—not a penetration test, production certification, or live database verification.

## Changes made in this audit

- **Coach PIN and member access codes:** use salted PBKDF2-HMAC-SHA256 with 310,000 iterations. Legacy salted SHA-256 credentials remain verifiable and are upgraded after a successful login. Member-code records include a keyed lookup digest so code-only login does not require an expensive PBKDF2 check for every roster member; raw codes are not stored.
- **Key handling:** local development may generate `.session_secret` and `.member_code_pepper` when environment values are absent. Vercel refuses to fall back to local files and requires stable `SESSION_SECRET` and `MEMBER_CODE_PEPPER` environment values of at least 32 bytes. `OWNER_ACCESS_KEY` is separate and never stored in the database or page source. Losing/changing the member-code pepper requires resetting member access codes.
- **Owner Console:** creator login uses the separate environment key and a signed four-hour HttpOnly cookie with `SameSite=Strict`. Kilani requests one of two fixed scopes from the coach dashboard; the creator must approve. A grant is bound to that coach session, expires after exactly 30 minutes, cannot overlap another active grant for the same session, and can be revoked. Approval, denial, revocation and switch changes are written to the `kilani_owner_control` audit state.
- **Session invalidation:** coach session tokens are signed and bound to the current PIN hash; changing the PIN invalidates old coach sessions. Member sessions are bound to the current member-code hash, so resetting a code revokes that member's existing sessions. Owner sessions are invalidated if the Owner Access Key changes.
- **Operations controls:** maintenance, payments-paused, and bookings-paused flags are separate. Maintenance keeps the owner routes accessible. Payment and booking readiness remain hardcoded off; no owner switch can activate D17 checkout or live booking.
- **POST protections:** reject mismatched `Origin` values and `Sec-Fetch-Site: cross-site`; reject malformed content lengths; cap request bodies at 4 MiB to remain below Vercel's function payload limit. Vercel's overwritten visitor-IP headers are trusted only inside Vercel; other proxies require explicit trusted-IP configuration.
- **Browser response protections:** CSP, `nosniff`, same-origin referrer policy, no-store caching, restrictive permissions policy, and conditional HSTS. Coach/member cookies use `HttpOnly` and `SameSite=Lax`; owner cookies use `HttpOnly` and `SameSite=Strict`; `Secure` is set when the trusted reverse proxy reports HTTPS.
- **Remote MySQL:** remote connections require TLS certificate and hostname verification; disabling TLS is rejected for non-loopback hosts. A small per-instance connection pool is used for serverless reuse. Vercel still requires a provider-side/serverless pooler appropriate to its scale, and no live database connection has been tested.
- **Input shape handling:** member and owner login, member-code management, owner requests/decisions/settings, and coach state writes reject malformed or non-object JSON rather than treating it as a valid request.

## Existing controls reviewed

- Coach and member APIs require their respective signed sessions. Creator-only decision, revoke, and settings endpoints require a valid owner cookie; Kilani’s access-request endpoint requires an authenticated coach session. Coach, owner, and member login have five-failure, 60-second in-process throttles.
- Member responses are filtered by per-member visibility and contain only the authenticated member's record. Check-ins are restricted to that member; check-in is denied when session visibility is off.
- Public endpoints expose published plans/offers and a non-sensitive site-status payload only. Private notes, payment/formula fields when hidden, access-code hashes, and other members' records are not part of the member payload.
- Local static serving is allow-listed to known public assets and does not expose workspace files such as `state.json`, `.env`, secret files, or server source. The Vercel build publishes only the public homepage in its static output; coach login, the protected dashboard, owner page, and APIs route through the Python Function. The owner HTML is a data-free shell and every private read/action is API-authorized.
- Coach/member-supplied program and offer text is escaped before HTML insertion. Owner request reasons, statuses, audit actions, and identifiers are also escaped in the console.
- MySQL queries use fixed SQL statements and bound values; credentials are environment-configured rather than committed.

## Test report

| Check | Result |
|---|---|
| `python3 -m unittest discover -s tests -v` | **36 passed** |
| Coach/member credential hashing, legacy upgrades, and session invalidation | Passed |
| Member isolation, visibility filtering, access-code reset, and check-in permissions | Passed |
| Owner-key length validation, creator-only decisions, request isolation, scope limits, 30-minute expiry, overlap prevention, revocation, audit events, and maintenance bypass | Passed |
| Owner state serialization to the separate MySQL control table | Passed (unit mock; no DB connection) |
| Static acceptance checks for separate console and no card/CVV inputs | Passed |
| Origin rejection, oversized-body response, security headers, and trusted-proxy/Vercel IP handling | Passed |
| Vercel rewrite path restoration, private output routing, production key requirements, MySQL-only storage and initial-PIN guard | Passed |
| MySQL configuration, remote-TLS policy, JSON serialization, pool-size bounds, and legacy import unit tests | Passed |
| `python3 -m py_compile server.py build.py vercel_build.py api/index.py` | Passed |
| `python3 vercel_build.py` — output contains only `index.html` | Passed |
| `node --check src/app.js`, `src/admin.js`, and `src/owner.js` | Passed |

The MySQL tests are unit/configuration tests only. No database host or credentials are configured in this workspace, so a live MySQL connection, real certificate chain, migration against a production database, and remote TLS handshake **were not tested**. No external penetration test or dependency vulnerability scan was run.

## Required before production deployment

1. Create a private GitHub repository and connect it to Vercel. The workspace has no Git repository or Vercel project/account connection; no production deployment has been attempted.
2. Provision remote MySQL with TLS, backups, and an appropriate serverless connection pooler. Use a least-privilege database account and verify backup restoration.
3. Configure the Vercel production environment variables: `STORAGE_BACKEND=mysql`, MySQL credentials, stable `SESSION_SECRET`, `MEMBER_CODE_PEPPER`, and `OWNER_ACCESS_KEY` if the Owner Console is needed. On an empty database, set a private 8–10 digit `COACH_INITIAL_PIN` for first initialization, change it in Settings, then remove the variable and redeploy. Do not use the local demo PIN in production.
4. Keep the Vercel output directory as `vercel-static`; it contains only the public `index.html`. Do not change the output directory to the project root or publish the coach dashboard as a static file. Test that `/admin.html` redirects to `/login` when logged out and that private APIs reject unauthenticated requests.
5. Enable Vercel Firewall/platform-level rate limits for `/login`, `/api/member/login`, and `/api/owner/login`. The in-memory 5-failure lockout remains per function instance and is not a distributed rate limiter. Consider MFA or stronger coach authentication.
6. Confirm Vercel domain/HTTPS setup, MySQL TLS validation, backups, monitoring, and recovery before public launch. Vercel's forwarded IP and scheme headers are read within Vercel; no custom reverse-proxy configuration is required for a standard Vercel deployment.
7. Cash is arranged in person with the coach. Keep D17 checkout and live bookings unavailable until official merchant setup/API details, required credentials, verified payment callbacks, and end-to-end tests are available. Never collect or store full card numbers/CVV or full bank-account details in this app; provider-managed payouts stay in the merchant account.

The site is **prepared for Vercel routing but not deployed or production-verified**: no GitHub repo, Vercel project, database credentials, or production secrets have been supplied. Live MySQL connectivity, TLS handshake, Vercel build/runtime, backups, and D17 integration have not been tested against real services.

/* =========================================================================
   KILANI — COACH DASHBOARD (admin)
   Server mode: gated login + shared server state across devices.
   Static-file fallback: demo-only PIN gate + browser storage.
   ========================================================================= */
(function () {
  'use strict';

  /* ------------------------------------------------------------ storage --
     Two modes:
       · static file  → localStorage (demo)
       · server       → window.KILANI_STATE + POST api/state (shared, syncs devices)
  ------------------------------------------------------------------------ */
  var API = window.KILANI_API || null;
  var BOOT = window.KILANI_STATE || {};
  var MEM = {};
  var KEYMAP = {
    kilani_admin_roster_v1: 'roster',
    kilani_admin_payments_v1: 'payments',
    kilani_admin_plans_v1: 'plans',
    kilani_admin_notes_v1: 'notes',
    kilani_admin_offers_v1: 'offers'
  };
  function apiKey(k) { return KEYMAP[k] || null; }

  function lsGet(k, d) {
    if (API) {
      var ak = apiKey(k);
      if (ak && BOOT[ak] != null && BOOT[ak] !== '') return BOOT[ak];
      if (ak && k in MEM) return MEM[k];
      if (ak && BOOT[ak] != null) return BOOT[ak] === '' ? d : BOOT[ak];
      return d;
    }
    try { var v = localStorage.getItem(k); return v === null ? (k in MEM ? MEM[k] : d) : v; }
    catch (e) { return k in MEM ? MEM[k] : d; }
  }
  function lsSet(k, v) {
    MEM[k] = v;
    if (API) {
      var ak = apiKey(k);
      if (ak) { BOOT[ak] = v; sync(); }
      return;
    }
    try { localStorage.setItem(k, v); } catch (e) {}
  }
  function lsDel(k) {
    delete MEM[k];
    if (API) {
      var ak = apiKey(k);
      if (ak) { BOOT[ak] = ''; sync(); }
      return;
    }
    try { localStorage.removeItem(k); } catch (e) {}
  }

  var syncTimer = null;
  function sync() {
    if (!API) return;
    clearTimeout(syncTimer);
    syncTimer = setTimeout(function () {
      var payload = { roster: BOOT.roster || '', payments: BOOT.payments || '', plans: BOOT.plans || '', notes: BOOT.notes || '', offers: BOOT.offers || '' };
      try {
        fetch(API, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) })
          .then(function (r) { if (r.status === 401) window.location.href = '/login'; })
          .catch(function () {});
      } catch (e) {}
    }, 400);
  }
  function ssGet(k) { try { return sessionStorage.getItem(k); } catch (e) { return MEM['ss:' + k] || null; } }
  function ssSet(k, v) { MEM['ss:' + k] = v; try { sessionStorage.setItem(k, v); } catch (e) {} }
  function ssDel(k) { delete MEM['ss:' + k]; try { sessionStorage.removeItem(k); } catch (e) {} }

  var K = {
    roster: 'kilani_admin_roster_v1',
    pay: 'kilani_admin_payments_v1',
    plans: 'kilani_admin_plans_v1',
    notes: 'kilani_admin_notes_v1',
    offers: 'kilani_admin_offers_v1',
    pin: 'kilani_admin_pin_v1',
    public: 'kilani_membership_v1',
    session: 'kilani_admin_unlocked'
  };

  /* PIN = 1959 → sha256("kilani:1959:coach"); djb2 is the offline fallback */
  var PIN_SHA = 'fdd209a20b87a2fb9ca38fbf413948e42dfcce0893684766d0def36167407500';
  var PIN_DJB = '2402493807';

  function djb2(s) {
    var h = 5381;
    for (var i = 0; i < s.length; i++) h = ((h * 33) ^ s.charCodeAt(i)) >>> 0;
    return String(h);
  }
  function sha256(s) {
    if (!window.crypto || !crypto.subtle || !window.TextEncoder) return Promise.resolve(null);
    return crypto.subtle.digest('SHA-256', new TextEncoder().encode(s)).then(function (buf) {
      return Array.prototype.map.call(new Uint8Array(buf), function (b) {
        return ('0' + b.toString(16)).slice(-2);
      }).join('');
    }).catch(function () { return null; });
  }
  function checkPin(pin) {
    var msg = 'kilani:' + pin + ':coach';
    var stored = lsGet(K.pin, null);
    if (stored) {
      /* stored as "sha:<hex>" or "djb:<num>" */
      return sha256(msg).then(function (h) {
        if (stored.indexOf('sha:') === 0) return h ? 'sha:' + h === stored : false;
        return 'djb:' + djb2(msg) === stored;
      });
    }
    return sha256(msg).then(function (h) {
      if (h) return h === PIN_SHA;
      return djb2(msg) === PIN_DJB;
    });
  }

  /* ------------------------------------------------------------- helpers -- */
  function $(s, r) { return (r || document).querySelector(s); }
  function $$(s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); }
  function pad(n) { return n < 10 ? '0' + n : '' + n; }
  function iso(d) { return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()); }
  function today() { return iso(new Date()); }
  function parse(s) { return new Date(s + 'T00:00:00'); }
  function addDays(s, n) { var d = parse(s); d.setDate(d.getDate() + n); return iso(d); }
  function addMonth(s) { var d = parse(s); var day = d.getDate(); d.setMonth(d.getMonth() + 1); if (d.getDate() < day) d.setDate(0); return iso(d); }
  function fmt(s) { return parse(s).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }); }
  function daysLeft(m) { return Math.round((parse(m.end) - parse(today())) / 86400000); }
  function dt(n) { return n + ' DT'; }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]; }); }
  function initials(n) { return n.trim().split(/\s+/).slice(0, 2).map(function (w) { return w[0]; }).join('').toUpperCase(); }
  function toast(m) {
    var t = $('#toast'); $('#toastTxt').textContent = m;
    t.classList.add('is-on'); clearTimeout(t._t);
    t._t = setTimeout(function () { t.classList.remove('is-on'); }, 3200);
  }
  function status(m) {
    var d = daysLeft(m);
    if (d < 0) return { k: 'expired', label: 'Expired', cls: 'st--out', d: d };
    if (d <= 7) return { k: 'expiring', label: d + ' d left', cls: 'st--soon', d: d };
    return { k: 'active', label: 'Active', cls: 'st--ok', d: d };
  }

  /* ---------------------------------------------------------------- data -- */
  var PLANS = {
    p4: { name: 'Starter', mode: 'private', sessions: 4, price: 180 },
    p8: { name: 'Fighter', mode: 'private', sessions: 8, price: 320 },
    p12: { name: 'Corner', mode: 'private', sessions: 12, price: 430 },
    g4: { name: 'Boxing Fit', mode: 'group', sessions: 4, price: 90 },
    g8: { name: 'Double Round', mode: 'group', sessions: 8, price: 150 },
    gu: { name: 'Unlimited', mode: 'group', sessions: 14, price: 220 }
  };
  var CLASSES = {
    1: [{ t: '18h15', n: 'Juniors', k: 'juniors' }, { t: '19h30', n: 'Adultes', k: 'adultes' }],
    2: [{ t: '18h15', n: 'Cadets', k: 'cadets' }],
    3: [{ t: '18h15', n: 'Juniors', k: 'juniors' }, { t: '19h30', n: 'Adultes', k: 'adultes' }],
    4: [{ t: '18h15', n: 'Cadets', k: 'cadets' }],
    5: [{ t: '17h15', n: 'Juniors', k: 'juniors' }, { t: '18h00', n: 'Adultes', k: 'adultes' }],
    6: []
  };

  var OFFER_SEED = {
    plans: {
      p4:{name:'Starter',price:180,sessions:4,desc:'Once a week, one to one. Technique, pads and a plan you can repeat alone.',features:'4 private sessions / month\nFull boxing technique & pad work\nMonthly training plan\nWhatsApp support\nBody measurements every 2 weeks\nNutrition plan\nVideo technique review',active:true},
      p8:{name:'Fighter',price:320,sessions:8,desc:'Twice a week with the coach. The sweet spot for real transformation.',features:'8 private sessions / month\nFull boxing technique & pad work\nStrength & conditioning program\nMonthly training plan\nNutrition plan + weekly check-in\nBody measurements every 2 weeks\nWhatsApp support 7 days\nVideo technique review',active:true},
      p12:{name:'Corner',price:430,sessions:12,desc:'Three sessions a week. Competition-minded, fully supervised.',features:'12 private sessions / month\nEverything in Fighter\nSparring preparation\nPriority booking on all slots\nCustom meal structure\nDirect coach line',active:true},
      g4:{name:'Boxing Fit',price:90,sessions:4,desc:'One boxe anglaise class a week with the club. High energy, zero experience needed.',features:'4 club classes / month\nBoxe anglaise with coach Kilani\nCardio boxing & conditioning\nMonthly training plan\nWhatsApp group support\nNutrition plan\nPrivate sessions',active:true},
      g8:{name:'Double Round',price:150,sessions:8,desc:'Twice a week in the club class. The most popular way to train here.',features:'8 club classes / month\nBoxe anglaise with coach Kilani\nBoxing skills + strength circuits\nMonthly training plan\nNutrition targets\nBody measurements monthly\nWhatsApp group support',active:true},
      gu:{name:'Unlimited',price:220,sessions:14,desc:'Every group slot on the schedule, plus priority when a spot frees up.',features:'14 club classes / month\nAll class slots on the schedule\nPriority spot when full\nEverything in Double Round\n1 private session offered\nNutrition + measurements',active:true}
    },
    addons:[
      {id:'nutri',name:'Nutrition coaching',price:40,note:'Custom meal structure + 2 revisions',active:true},
      {id:'video',name:'Video technique review',price:30,note:'Send your shadow boxing, get feedback',active:true},
      {id:'kit',name:'Start kit',price:75,note:'Wraps, gloves and a jump rope',active:true}
    ]
  };

  function offerData() {
    var raw = lsGet(K.offers, null);
    if (!raw) { raw = JSON.stringify(OFFER_SEED); lsSet(K.offers, raw); }
    try { return JSON.parse(raw); } catch (e) { return JSON.parse(JSON.stringify(OFFER_SEED)); }
  }
  function applyOfferCatalog() {
    var cfg = offerData();
    Object.keys(PLANS).forEach(function (id) {
      var o = cfg.plans && cfg.plans[id];
      if (!o) return;
      PLANS[id].name = o.name || PLANS[id].name;
      PLANS[id].price = Number(o.price) || 0;
      PLANS[id].sessions = Math.max(1, Number(o.sessions) || PLANS[id].sessions);
      PLANS[id].active = o.active !== false;
      if (o.desc != null) PLANS[id].desc = o.desc;
      if (o.features != null) PLANS[id].features = String(o.features).split(/\n/).filter(Boolean);
    });
    return cfg;
  }
  function renderOffers() {
    var cfg = offerData();
    $('#offerEditor').innerHTML = Object.keys(PLANS).map(function (id) {
      var p = PLANS[id], o = cfg.plans[id] || {}, tier = p.mode === 'private' ? 'Private 1:1' : 'Group class';
      return '<div class="offer-edit" data-offer="' + id + '">' +
        '<div class="offer-edit__head"><div><b>' + tier + '</b><small>' + id.toUpperCase() + ' · public subscription card</small></div>' +
        '<label class="switch"><input type="checkbox" data-o-active' + (o.active !== false ? ' checked' : '') + '><span>Visible</span></label></div>' +
        '<div class="offer-edit__fields"><label>Name<input data-o-name value="' + esc(o.name || p.name) + '"></label>' +
        '<label>Price / month (DT)<input type="number" min="0" step="1" data-o-price value="' + esc(o.price == null ? p.price : o.price) + '"></label>' +
        '<label>Sessions / month<input type="number" min="1" step="1" data-o-sessions value="' + esc(o.sessions == null ? p.sessions : o.sessions) + '"></label></div>' +
        '<label class="offer-edit__wide">Short description<textarea rows="2" data-o-desc>' + esc(o.desc || p.desc || '') + '</textarea></label>' +
        '<label class="offer-edit__wide">Included in offer <small>one feature per line</small><textarea rows="4" data-o-features>' + esc(o.features || (p.feats || []).join('\n')) + '</textarea></label>' +
        '</div>';
    }).join('');
    $('#addonEditor').innerHTML = (cfg.addons || OFFER_SEED.addons).map(function (a) {
      return '<div class="addon-edit" data-addon="' + a.id + '">' +
        '<label class="switch"><input type="checkbox" data-a-active' + (a.active !== false ? ' checked' : '') + '><span>Visible</span></label>' +
        '<label>Name<input data-a-name value="' + esc(a.name) + '"></label>' +
        '<label>Price (DT)<input type="number" min="0" step="1" data-a-price value="' + esc(a.price) + '"></label>' +
        '<label>Description<input data-a-note value="' + esc(a.note) + '"></label></div>';
    }).join('');
  }
  function saveOffers() {
    var old = offerData(), out = { plans:{}, addons:[] };
    $$('#offerEditor .offer-edit').forEach(function (el) {
      var id = el.getAttribute('data-offer');
      out.plans[id] = {
        name: $('[data-o-name]',el).value.trim(),
        price: Math.max(0, +$('[data-o-price]',el).value || 0),
        sessions: Math.max(1, +$('[data-o-sessions]',el).value || 1),
        desc: $('[data-o-desc]',el).value.trim(),
        features: $('[data-o-features]',el).value,
        active: $('[data-o-active]',el).checked
      };
    });
    $$('#addonEditor .addon-edit').forEach(function (el) {
      out.addons.push({id:el.getAttribute('data-addon'),name:$('[data-a-name]',el).value.trim(),
        price:Math.max(0,+$('[data-a-price]',el).value||0),note:$('[data-a-note]',el).value.trim(),active:$('[data-a-active]',el).checked});
    });
    if (!out.addons.length) out.addons = old.addons || [];
    lsSet(K.offers, JSON.stringify(out));
    applyOfferCatalog(); renderAll(); renderOffers();
    toast('Offers saved and published to the member website.');
  }

  function seedRoster() {
    var t = today();
    var raw = [
      ['Yassine Trabelsi', '94 112 233', 'p8', 'Fat loss', 3, -12, 'private'],
      ['Salma Mansouri', '55 908 771', 'g8', 'Boxing skills', 5, -22, 'group'],
      ['Amine Kacem', '22 447 118', 'p12', 'Competition prep', 9, -25, 'private'],
      ['Rami Ayari', '97 660 452', 'g4', 'Cardio / fitness', 1, -3, 'group'],
      ['Sarra Ben Amor', '50 331 907', 'p4', 'Fat loss', 2, -28, 'private'],
      ['Mohamed Aziz Gharbi', '21 774 600', 'g8', 'Muscle gain', 6, -19, 'group'],
      ['Nour Hadj Ali', '94 555 122', 'p4', 'Boxing skills', 4, -34, 'private'],
      ['Wael Jlassi', '26 880 341', 'gu', 'Cardio / fitness', 11, -8, 'group']
    ];
    return raw.map(function (r, i) {
      var p = PLANS[r[2]];
      var start = addDays(t, r[5]);
      return {
        id: 'm' + (i + 1), name: r[0], phone: r[1], planId: r[2], planName: p.name,
        mode: r[6], goal: r[3], sessionsTotal: p.sessions, sessionsUsed: r[4],
        start: start, end: addMonth(start), price: p.price, paid: true, note: ''
      };
    });
  }
  function seedPayments() {
    var out = [], t = new Date();
    for (var m = 5; m >= 0; m--) {
      var d = new Date(t.getFullYear(), t.getMonth() - m, 6);
      out.push({ date: iso(d), member: '—', formula: 'Club revenue', method: 'cash', amount: 1200 + m * 240, status: 'paid' });
    }
    return out;
  }

  var state = {
    page: 'overview',
    filter: 'all',
    search: '',
    sheetClass: 'Adultes',
    sheetDate: today(),
    present: {},
    planGoal: 'Fat loss',
    currentMemberId: null
  };

  function roster() {
    var r = lsGet(K.roster, null);
    if (!r) { r = JSON.stringify(seedRoster()); lsSet(K.roster, r); }
    try { return JSON.parse(r); } catch (e) { return []; }
  }
  function saveRoster(list) { lsSet(K.roster, JSON.stringify(list)); }
  function payments() {
    var p = lsGet(K.pay, null);
    if (!p) { p = JSON.stringify(seedPayments()); lsSet(K.pay, p); }
    try { return JSON.parse(p); } catch (e) { return []; }
  }
  function savePayments(list) { lsSet(K.pay, JSON.stringify(list)); }

  /* member who bought on the public site shows up here too */
  function syncPublicMember() {
    var raw = lsGet(K.public, null);
    if (!raw) return;
    var m;
    try { m = JSON.parse(raw); } catch (e) { return; }
    if (!m || !m.planId) return;
    var list = roster();
    var existing = list.filter(function (x) { return x.name === m.name && x.start === m.start; })[0];
    if (existing) return;
    var p = PLANS[m.planId] || { name: m.planName, sessions: m.sessionsTotal, price: m.price };
    list.unshift({
      id: 'w' + Date.now(), name: m.name || 'New member', phone: m.phone || '—',
      planId: m.planId, planName: p.name, mode: m.mode || 'private', goal: m.goal || 'Fat loss',
      sessionsTotal: m.sessionsTotal || p.sessions, sessionsUsed: m.sessionsUsed || 0,
      start: m.start, end: m.end, price: m.price || p.price, paid: true, note: 'Subscribed on the website'
    });
    saveRoster(list);
  }

  /* ------------------------------------------------------------- render --- */
  function renderAll() {
    applyOfferCatalog();
    syncPublicMember();
    var list = roster();
    $('#navMemberCount').textContent = list.length;
    renderKpis(list);
    renderActions(list);
    renderToday();
    renderChart();
    renderMembers(list);
    renderAttendance(list);
    renderPlans();
    renderOffers();
    renderPayments(list);
  }

  function renderKpis(list) {
    var active = list.filter(function (m) { return status(m).k === 'active'; }).length;
    var soon = list.filter(function (m) { return status(m).k === 'expiring'; }).length;
    var expired = list.filter(function (m) { return status(m).k === 'expired'; }).length;
    var delivered = list.reduce(function (s, m) { return s + (+m.sessionsUsed || 0); }, 0);
    var revenue = list.filter(function (m) { return m.paid; }).reduce(function (s, m) { return s + (+m.price || 0); }, 0);
    $('#kpis').innerHTML =
      '<div class="kpi"><span class="kpi__ic">◉</span><b>' + active + '</b><span>Active members</span><small>' + list.length + ' total</small></div>' +
      '<div class="kpi kpi--warn"><span class="kpi__ic">!</span><b>' + soon + '</b><span>Expiring ≤ 7 days</span><small>' + expired + ' already expired</small></div>' +
      '<div class="kpi"><span class="kpi__ic">✓</span><b>' + delivered + '</b><span>Sessions delivered</span><small>this month</small></div>' +
      '<div class="kpi"><span class="kpi__ic">▤</span><b>' + revenue + '</b><span>Revenue (DT)</span><small>this month</small></div>';
  }

  function renderActions(list) {
    var need = list.filter(function (m) { return status(m).k !== 'active'; })
      .sort(function (a, b) { return daysLeft(a) - daysLeft(b); });
    $('#actionCount').textContent = need.length;
    if (!need.length) {
      $('#actionList').innerHTML = '<p class="muted" style="margin:0">Nothing urgent — everyone is inside their month.</p>';
      return;
    }
    $('#actionList').innerHTML = need.map(function (m) {
      var st = status(m);
      return '<div class="actionrow">' +
        '<div><b>' + esc(m.name) + '</b><small>' + esc(m.planName) + ' · ' +
          (st.k === 'expired' ? 'ended ' + fmt(m.end) : st.d + ' day(s) left · ends ' + fmt(m.end)) + '</small></div>' +
        '<div class="acts">' +
          '<button class="minibtn minibtn--wa" data-wa="' + m.id + '">WhatsApp</button>' +
          '<button class="minibtn" data-renew="' + m.id + '">Renew</button>' +
        '</div></div>';
    }).join('');
  }

  function renderToday() {
    var wd = new Date().getDay();
    var rows = CLASSES[wd] || [];
    $('#todayTag').textContent = new Date().toLocaleDateString('en-GB', { weekday: 'short', day: '2-digit', month: 'short' });
    if (!rows.length) {
      $('#todayClasses').innerHTML = '<p class="muted" style="margin:0">No group class today — private sessions and recovery.</p>';
      return;
    }
    var list = roster();
    var counts = { adultes: 0, juniors: 0, cadets: 0 };
    list.forEach(function (m) {
      if (m.mode === 'group' && status(m).k !== 'expired') counts.adultes++;
    });
    $('#todayClasses').innerHTML = rows.map(function (r) {
      return '<div class="classrow"><span class="t">' + r.t + '</span>' +
        '<span class="n"><b>' + r.n + '</b><small>Boxe anglaise · ' +
        (counts[r.k] || 0) + ' member(s) registered</small></span>' +
        '<span class="badge">' + r.n + '</span></div>';
    }).join('');
  }

  function renderChart() {
    var pays = payments();
    var byMonth = {};
    pays.forEach(function (p) {
      var k = p.date.slice(0, 7);
      byMonth[k] = (byMonth[k] || 0) + (+p.amount || 0);
    });
    var keys = Object.keys(byMonth).sort().slice(-6);
    var max = Math.max.apply(null, keys.map(function (k) { return byMonth[k]; }).concat([1]));
    var short = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    $('#chart').innerHTML = keys.map(function (k) {
      var h = Math.max(6, Math.round(byMonth[k] / max * 100));
      var mi = +k.slice(5, 7) - 1;
      return '<div style="height:' + h + '%" title="' + dt(byMonth[k]) + '"><span>' + short[mi] + '</span></div>';
    }).join('');
  }

  function renderMembers(list) {
    list = list.filter(function (m) {
      var st = status(m).k;
      if (state.filter === 'active' && st !== 'active') return false;
      if (state.filter === 'expiring' && st !== 'expiring') return false;
      if (state.filter === 'expired' && st !== 'expired') return false;
      if (state.search) {
        var q = state.search.toLowerCase();
        if ((m.name + ' ' + m.phone).toLowerCase().indexOf(q) === -1) return false;
      }
      return true;
    });
    var tb = $('#memberTable tbody');
    if (!list.length) {
      tb.innerHTML = '<tr><td colspan="6" style="text-align:center;color:var(--muted);padding:26px">No member matches.</td></tr>';
      return;
    }
    tb.innerHTML = list.map(function (m) {
      var st = status(m);
      var pct = Math.round((m.sessionsUsed / m.sessionsTotal) * 100);
      return '<tr data-member="' + m.id + '">' +
        '<td><div class="who"><span class="ini">' + initials(m.name) + '</span>' +
          '<span><b>' + esc(m.name) + '</b><small>' + esc(m.phone) + '</small></span></div></td>' +
        '<td>' + esc(m.planName) + '<br><small style="color:var(--muted);font-size:.7rem">' + (m.mode === 'private' ? 'Private 1:1' : 'Club class') + '</small></td>' +
        '<td><div class="sessbar"><span class="tb"><i style="width:' + pct + '%"></i></span>' +
          '<small>' + m.sessionsUsed + '/' + m.sessionsTotal + '</small></div></td>' +
        '<td>' + fmt(m.start) + ' → ' + fmt(m.end) + '</td>' +
        '<td><span class="st ' + st.cls + '">' + st.label + '</span></td>' +
        '<td><button class="minibtn" data-open="' + m.id + '">Open</button></td>' +
      '</tr>';
    }).join('');
  }

  function renderAttendance(list) {
    list = list.filter(function (m) { return status(m).k !== 'expired'; });
    $('#attCount').textContent = Object.keys(state.present).filter(function (k) { return state.present[k]; }).length + ' present';
    $('#attList').innerHTML = list.map(function (m) {
      var on = !!state.present[m.id];
      return '<div class="attrow' + (on ? ' is-in' : '') + '" data-att="' + m.id + '">' +
        '<span class="who"><span class="ini">' + initials(m.name) + '</span>' +
        '<span><b>' + esc(m.name) + '</b><small>' + esc(m.planName) + ' · ' + Math.max(0, m.sessionsTotal - m.sessionsUsed) + ' left</small></span></span>' +
        '<span class="attbox">✓</span></div>';
    }).join('') || '<p class="muted" style="margin:0">No active members.</p>';
  }

  var PLAN_SEED = {
    'Fat loss': [
      ['Base — movement quality', 'Session 1 · Technique + intervals — jab mechanics, 6 × 2 min bag, 25 min zone 2\nSession 2 · Full body strength — goblet squat 4×8, push-ups 4×10, row 4×10, carry 3×30 m\nSession 3 · Cardio circuit — 8 rounds: shadow / rope / squat-press / rest'],
      ['Add density', 'Session 1 · Jab–cross–hook on pads 5×3 min + 20 min tempo run\nSession 2 · Lower + upper — deadlift 4×5, split squat 3×10, pull-ups 4×6, press 3×8\nSession 3 · Metcon — 5 rounds: swings, burpees, heavy bag, 90 s rest'],
      ['Intensity block', 'Session 1 · Speed & combinations — 6 × 3 min pads at 80%\nSession 2 · Strength maintenance — squat 4×5 @75%, incline press 4×8, row 4×8\nSession 3 · Long conditioning — 40 min steady + 10 min mobility'],
      ['Sharpen & test', 'Session 1 · Test day — max clean rounds in 12 min, measurements, photos\nSession 2 · Light technique — shadow work 30 min + mobility\nSession 3 · Recovery — walk 40 min, stretch, sleep 8 h']
    ],
    'Muscle gain': [
      ['Overload baseline', 'Session 1 · Push + pad power — bench 4×6, overhead press 3×8, dips 3×8, 4 rounds pads\nSession 2 · Pull + chassis — pull-ups 4×6, row 4×8, face pull 3×15, plank 3×45 s\nSession 3 · Legs — squat 4×6, RDL 3×8, lunge 3×10, calf 4×12'],
      ['Volume +10%', 'Session 1 · Incline press 4×8, lateral raise 3×15, 5 × 2 min power rounds\nSession 2 · Weighted pull-ups 4×5, chest-supported row 4×10, farmer carry\nSession 3 · Front squat 4×5, hip thrust 3×10, hanging knee raise 3×12'],
      ['Peak week', 'Session 1 · Bench 5×5 @80%, push press 4×5, 4 rounds pads\nSession 2 · Deadlift 4×4 @82%, jump squat 3×6, sled 5×20 m\nSession 3 · Accessory — 12 min arms, 12 min shoulders, 10 min core'],
      ['Deload & measure', 'Session 1 · Technique lifts at 60% volume, speed focus\nSession 2 · Mobility 30 min + 6 easy rounds\nSession 3 · Check-in — weight, measurements, photos, adjust calories']
    ],
    'Boxing skills': [
      ['Stance, guard, jab', 'Session 1 · Foundations — stance & balance, jab mechanics 6×2 min, mirror work\nSession 2 · Footwork — ladder drills, pivot, jab + step 5×3 min\nSession 3 · Conditioning — 6 rounds bag, 3 shadow, 10 min rope'],
      ['Jab–cross, movement', 'Session 1 · The 1–2 on pads 6×3 min, weight transfer drills\nSession 2 · Defence — slip, roll, catch, partner drills 5×2 min\nSession 3 · Cardio boxing — 10 × 2 min on / 40 s off, technique first'],
      ['Combinations & angles', 'Session 1 · Three-punch combos 1–2–3 and 1–1–2, 8 rounds\nSession 2 · Step-off counters and pivot after combination\nSession 3 · Controlled technical sparring, 50% power, supervised'],
      ['Put it together', 'Session 1 · Free-flow pads, 8 rounds, coach calls numbers only\nSession 2 · Ring craft — rope work, corner exits\nSession 3 · Test — 3 × 3 min rounds, filmed and reviewed']
    ],
    'Cardio / fitness': [
      ['Get the engine running', 'Session 1 · Intro intervals 8 × 1 min on / 1 min off\nSession 2 · Strength circuit 3 rounds: squat 12, push-up 10, row 12, plank 40 s\nSession 3 · Zone 2 — 30–40 min easy'],
      ['Build the rounds', 'Session 1 · Boxing cardio 10 × 2 min bag rounds\nSession 2 · Full body — goblet squat, press, row, core\nSession 3 · Zone 2 — 40 min nose breathing only'],
      ['Push the ceiling', 'Session 1 · HIIT 6 rounds 30 s hard / 30 s easy\nSession 2 · Strength endurance 5 rounds: swings, push-ups, plank, 200 m row\nSession 3 · Long easy 45 min'],
      ['Test and reset', 'Session 1 · Benchmark — max rounds in 15 min, note the score\nSession 2 · Mobility 30 min flow\nSession 3 · Easy walk + stretch, prep next month']
    ],
    'Competition prep': [
      ['Assessment & base', 'Session 1 · Technical audit, filmed, pick 3 priorities\nSession 2 · Strength base — squat 5×5, press 4×6, pull 4×8\nSession 3 · Roadwork 5 km + 6 rounds shadow'],
      ['Volume', 'Session 1 · Pads 10 rounds, combination volume\nSession 2 · Sparring 6 × 2 min technical\nSession 3 · Hill sprints 8×20 m + core'],
      ['Intensity', 'Session 1 · Hard sparring 8 rounds at competition pace, filmed\nSession 2 · Power — deadlift 4×4, med ball throws, neck & grip\nSession 3 · Recovery — pool / walk / stretch'],
      ['Sharpen', 'Session 1 · Sharp rounds 6 × 2 min, speed over power\nSession 2 · Game plan — video review, opponent patterns\nSession 3 · Weigh-in prep, light session only']
    ]
  };

  function planData(goal) {
    var all = JSON.parse(lsGet(K.plans, '{}'));
    if (!all[goal]) {
      all[goal] = {
        month: new Date().toLocaleDateString('en-GB', { month: 'long', year: 'numeric' }),
        weeks: PLAN_SEED[goal].map(function (w) { return { title: w[0], body: w[1] }; })
      };
      lsSet(K.plans, JSON.stringify(all));
    }
    return { all: all, data: all[goal] };
  }

  function renderPlans() {
    var got = planData(state.planGoal);
    $('#planMonth').value = got.data.month;
    $('#planWeeks').innerHTML = got.data.weeks.map(function (w, i) {
      return '<div class="week">' +
        '<div class="week__head"><span class="week__n">0' + (i + 1) + '</span>' +
        '<input data-week-title="' + i + '" value="' + esc(w.title) + '"></div>' +
        '<textarea rows="3" data-week-body="' + i + '">' + esc(w.body) + '</textarea>' +
      '</div>';
    }).join('');
  }

  function savePlans() {
    var all = JSON.parse(lsGet(K.plans, '{}'));
    var weeks = $$('#planWeeks .week').map(function (w) {
      return {
        title: $('[data-week-title]', w).value,
        body: $('textarea', w).value
      };
    });
    all[state.planGoal] = { month: $('#planMonth').value, weeks: weeks };
    lsSet(K.plans, JSON.stringify(all));
    toast('Plan for ' + state.planGoal + ' published to members.');
  }

  function renderPayments(list) {
    var pays = payments();
    var paid = pays.filter(function (p) { return p.status === 'paid'; }).reduce(function (s, p) { return s + (+p.amount || 0); }, 0);
    var due = list.filter(function (m) { return !m.paid; }).reduce(function (s, m) { return s + (+m.price || 0); }, 0);
    $('#payKpis').innerHTML =
      '<div class="kpi"><b>' + dt(paid) + '</b><span>Collected</span><small>' + pays.length + ' payments</small></div>' +
      '<div class="kpi kpi--warn"><b>' + dt(due) + '</b><span>Outstanding</span><small>' + list.filter(function (m) { return !m.paid; }).length + ' unpaid member(s)</small></div>' +
      '<div class="kpi"><b>' + dt(Math.round(paid / Math.max(1, Object.keys(groupByMonth(pays)).length))) + '</b><span>Monthly average</span><small>last 6 months</small></div>';
    $('#payTable tbody').innerHTML = pays.slice().reverse().map(function (p, i) {
      return '<tr><td>' + fmt(p.date) + '</td><td>' + esc(p.member) + '</td><td>' + esc(p.formula) + '</td>' +
        '<td>' + esc((p.method || '').toUpperCase()) + '</td><td><b>' + dt(p.amount) + '</b></td>' +
        '<td><span class="st ' + (p.status === 'paid' ? 'st--ok' : 'st--out') + '">' + p.status + '</span></td></tr>';
    }).join('');
  }
  function groupByMonth(pays) {
    var o = {};
    pays.forEach(function (p) { o[p.date.slice(0, 7)] = 1; });
    return o;
  }

  /* ------------------------------------------------------------- drawer --- */
  function openMember(id) {
    var list = roster();
    var m = list.filter(function (x) { return x.id === id; })[0];
    if (!m) return;
    state.currentMemberId = id;
    var st = status(m);
    var d = $('#drawerBox');
    var mv = m.memberView || {};
    var vis = mv.visibility || {};
    var nutrition = mv.nutrition || {};
    var history = (m.progress || []).slice().reverse();
    var last = (m.progress || [])[((m.progress || []).length || 1) - 1] || {};
    function on(key) { return vis[key] === false ? '' : ' checked'; }
    d.dataset.memberId = id;
    d.innerHTML =
      '<div class="drawer__head">' +
        '<div><h3>' + esc(m.name) + '</h3><small>' + esc(m.planName) + ' · ' + (m.mode === 'private' ? 'Private 1:1' : 'Club class') + '</small></div>' +
        '<button class="drawer__x" data-closeDrawer aria-label="Close">✕</button>' +
      '</div>' +
      '<div class="drow"><span>Status</span><b><span class="st ' + st.cls + '">' + st.label + '</span></b></div>' +
      '<div class="drow"><span>Phone</span><b>' + esc(m.phone) + '</b></div>' +
      '<div class="drow"><span>Goal</span><b>' + esc(m.goal) + '</b></div>' +
      '<div class="drow"><span>Membership dates</span><b>' + fmt(m.start) + ' → ' + fmt(m.end) + '</b></div>' +
      '<div class="drow"><span>Payment</span><b>' + (m.paid ? 'Paid · ' + dt(m.price) : 'Unpaid · ' + dt(m.price)) + '</b></div>' +

      '<div class="dsec"><h4>Sessions used</h4>' +
        '<div class="counter"><button data-dec="' + m.id + '" aria-label="One session less">−</button>' +
        '<b>' + m.sessionsUsed + ' / ' + m.sessionsTotal + '</b>' +
        '<button data-inc="' + m.id + '" aria-label="One session more">+</button></div></div>' +

      '<div class="dsec"><h4>Abonnement &amp; time control</h4>' +
        '<label class="field dfield"><span>Formula / offer</span><select class="dselect" data-plan="' + m.id + '">' +
          Object.keys(PLANS).map(function (k) {
            return '<option value="' + k + '"' + (k === m.planId ? ' selected' : '') + '>' +
              PLANS[k].name + ' · ' + PLANS[k].sessions + ' sessions · ' + dt(PLANS[k].price) + '</option>';
          }).join('') +
        '</select></label>' +
        '<label class="field dfield"><span>Goal</span><select id="memberGoal" class="dselect">' +
          ['Fat loss','Muscle gain','Boxing skills','Cardio / fitness','Competition prep'].map(function (g) { return '<option' + (g === m.goal ? ' selected' : '') + '>' + g + '</option>'; }).join('') +
        '</select></label>' +
        '<div class="member-fields member-fields--2">' +
          '<label>Start date<input type="date" id="memberStart" value="' + esc(m.start) + '"></label>' +
          '<label>Expiry date<input type="date" id="memberEnd" value="' + esc(m.end) + '"></label>' +
          '<label>Sessions included<input type="number" min="1" id="memberSessionsTotal" value="' + esc(m.sessionsTotal) + '"></label>' +
          '<label>Price (DT)<input type="number" min="0" step="1" id="memberPrice" value="' + esc(m.price) + '"></label>' +
        '</div>' +
      '</div>' +

      '<div class="dsec"><h4>Member portal access</h4>' +
        '<p class="dhelp">Create a private 8-digit code for this member. Share it with them; reset it any time to revoke the old code.</p>' +
        '<button class="minibtn minibtn--primary" data-member-code="' + esc(m.id) + '">Generate / reset access code</button>' +
        '<div class="member-code-msg" id="memberCodeMsg" aria-live="polite"></div></div>' +

      '<div class="dsec"><h4>What this member sees</h4>' +
        '<p class="dhelp">Choose the member-facing sections. Their days remaining and expiry date stay visible in the portal status line.</p>' +
        '<div class="visibility-grid">' +
          '<label><input type="checkbox" data-viewflag="showMembership"' + on('showMembership') + '> Membership details card</label>' +
          '<label><input type="checkbox" data-viewflag="showProgram"' + on('showProgram') + '> Training program</label>' +
          '<label><input type="checkbox" data-viewflag="showNutrition"' + on('showNutrition') + '> Nutrition targets</label>' +
          '<label><input type="checkbox" data-viewflag="showSessions"' + on('showSessions') + '> Sessions &amp; check-in</label>' +
          '<label><input type="checkbox" data-viewflag="showBilling"' + on('showBilling') + '> Billing &amp; renewal</label>' +
          '<label><input type="checkbox" data-viewflag="showOffers"' + on('showOffers') + '> Upgrade / offers buttons</label>' +
          '<label><input type="checkbox" data-viewflag="showNote"' + on('showNote') + '> Coach message</label>' +
          '<label><input type="checkbox" data-viewflag="showProgress"' + on('showProgress') + '> Progress measurements</label>' +
        '</div>' +
        '<label class="field dfield"><span>Member-visible coach message</span><textarea id="memberVisibleNote" rows="3" placeholder="This message appears in their member space…">' + esc(mv.note || '') + '</textarea></label>' +
      '</div>' +

      '<div class="dsec"><h4>Personal program</h4>' +
        '<p class="dhelp">Leave the plan text empty to use the shared monthly program for their goal. Text here overrides it for this member only; one session per line.</p>' +
        '<label class="field dfield"><span>Program month / title</span><input id="memberProgramMonth" value="' + esc(mv.programMonth || '') + '" placeholder="November 2026"></label>' +
        '<label class="field dfield"><span>Individual program</span><textarea id="memberProgramText" rows="6" placeholder="Session 1 · Boxing technique — ...&#10;Session 2 · Strength — ...">' + esc(mv.programText || '') + '</textarea></label>' +
      '</div>' +

      '<div class="dsec"><h4>Personal nutrition targets</h4>' +
        '<div class="member-fields member-fields--4">' +
          '<label>Calories<input type="number" min="0" id="memberKcal" value="' + esc(nutrition.kcal || '') + '" placeholder="auto"></label>' +
          '<label>Protein g<input type="number" min="0" id="memberProtein" value="' + esc(nutrition.protein || '') + '" placeholder="auto"></label>' +
          '<label>Carbs g<input type="number" min="0" id="memberCarbs" value="' + esc(nutrition.carbs || '') + '" placeholder="auto"></label>' +
          '<label>Fat g<input type="number" min="0" id="memberFat" value="' + esc(nutrition.fat || '') + '" placeholder="auto"></label>' +
        '</div>' +
      '</div>' +

      '<div class="dsec"><h4>Progress tracker</h4>' +
        '<div class="member-fields member-fields--3">' +
          '<label>Weight kg<input type="number" min="0" step="0.1" id="trackWeight" placeholder="' + esc(last.weight || '') + '"></label>' +
          '<label>Waist cm<input type="number" min="0" step="0.1" id="trackWaist" placeholder="' + esc(last.waist || '') + '"></label>' +
          '<label>Body fat %<input type="number" min="0" max="100" step="0.1" id="trackBodyFat" placeholder="' + esc(last.bodyFat || '') + '"></label>' +
        '</div>' +
        '<label class="field dfield"><span>Coach-only tracking note</span><input id="trackNote" placeholder="Training / check-in note"></label>' +
        '<button class="minibtn" data-add-progress="' + esc(m.id) + '">Log this check-in</button>' +
        '<div class="progress-history">' + (history.length ? history.slice(0,8).map(function (h) {
          return '<div><time>' + fmt(h.date) + '</time><b>' + (h.weight ? esc(h.weight) + ' kg' : '—') + '</b><span>' + (h.waist ? esc(h.waist) + ' cm waist' : '') + (h.bodyFat ? ' · ' + esc(h.bodyFat) + '% fat' : '') + '</span></div>' + (h.note ? '<small>' + esc(h.note) + '</small>' : '');
        }).join('') : '<p class="dhelp">No check-ins logged yet.</p>') + '</div>' +
      '</div>' +

      '<div class="dsec"><h4>Coach-only note</h4>' +
        '<textarea rows="3" id="memberNote" placeholder="Private note for Kilani only…">' + esc(m.note || '') + '</textarea>' +
      '</div>' +
      '<button class="btn btn--primary btn--block member-save" data-save-member="' + esc(m.id) + '">Save this member</button>' +

      '<div class="dsec"><h4>Actions</h4><div class="dbtns">' +
        '<button class="minibtn minibtn--wa" data-wa="' + m.id + '">Message on WhatsApp</button>' +
        '<button class="minibtn" data-renew="' + m.id + '">Renew one month</button>' +
        '<button class="minibtn" data-paid="' + m.id + '">' + (m.paid ? 'Mark unpaid' : 'Mark paid') + '</button>' +
        '<button class="minibtn" data-del="' + m.id + '">Remove member</button>' +
      '</div></div>';

    $('#memberDrawer').classList.add('is-open');
    $('#memberDrawer').setAttribute('aria-hidden', 'false');
  }
  function closeDrawer() {
    $('#memberDrawer').classList.remove('is-open');
    $('#memberDrawer').setAttribute('aria-hidden', 'true');
    state.currentMemberId = null;
  }
  function randomMemberCode() {
    var a = new Uint32Array(1);
    if (window.crypto && window.crypto.getRandomValues) window.crypto.getRandomValues(a);
    else a[0] = Math.floor(Math.random() * 4294967295);
    return String(10000000 + (a[0] % 90000000));
  }
  function showMemberCode(code, demo) {
    var el = $('#memberCodeMsg');
    if (!el) return;
    el.innerHTML = '<div class="member-code-box"><span>' + (demo ? 'Demo code' : 'Share this code once') + '</span><b>' + esc(code) + '</b><button class="minibtn" data-copy-code="' + esc(code) + '">Copy</button></div>' +
      '<small>' + (demo ? 'Static mode only — this does not create remote member login.' : 'Give this code to the member. Only their own member space will open.') + '</small>';
  }

  /* --------------------------------------------------------------- gate --- */
  var pin = '', fails = 0, lockUntil = 0, lockTimer = null, autoLock = null;

  function paintDots() {
    $$('#pinDots span').forEach(function (s, i) { s.classList.toggle('is-on', i < pin.length); });
    $('#gateEnter').disabled = pin.length < 4;
  }
  function gateMsg(t) { $('#gateMsg').textContent = t || ''; }

  function unlock() {
    ssSet(K.session, String(Date.now()));
    $('#gate').classList.add('is-done');
    $('#adm').hidden = false;
    document.body.classList.add('adm-body');
    renderAll();
    armAutoLock();
  }
  function lock() {
    if (API) { window.location.href = '/logout'; return; }
    ssDel(K.session);
    $('#adm').hidden = true;
    $('#gate').classList.remove('is-done');
    pin = ''; paintDots(); gateMsg('');
    closeDrawer();
    clearTimeout(autoLock);
  }
  function armAutoLock() {
    clearTimeout(autoLock);
    autoLock = setTimeout(function () { lock(); toast('Locked after 15 minutes of inactivity.'); }, 15 * 60 * 1000);
  }

  function submitPin() {
    if (pin.length < 4) return;
    if (Date.now() < lockUntil) return;
    checkPin(pin).then(function (ok) {
      if (ok) { unlock(); return; }
      fails++;
      $('#pinDots').classList.add('is-bad');
      $('.gate__card').classList.add('is-shake');
      setTimeout(function () {
        $('#pinDots').classList.remove('is-bad');
        $('.gate__card').classList.remove('is-shake');
      }, 500);
      pin = ''; paintDots();
      if (fails >= 5) {
        lockUntil = Date.now() + 60000; fails = 0;
        gateMsg('Too many attempts — wait 60 s.');
        lockTimer = setInterval(function () {
          var left = Math.ceil((lockUntil - Date.now()) / 1000);
          if (left <= 0) { clearInterval(lockTimer); gateMsg(''); return; }
          gateMsg('Too many attempts — wait ' + left + ' s.');
        }, 500);
      } else {
        gateMsg('Wrong code. ' + (5 - fails) + ' attempt(s) left.');
      }
    });
  }

  function bindGate() {
    $('#numpad').addEventListener('click', function (e) {
      var b = e.target.closest('button[data-key]');
      if (!b) return;
      if (Date.now() < lockUntil) return;
      var k = b.getAttribute('data-key');
      if (k === 'clear') { pin = ''; gateMsg(''); }
      else if (k === 'back') { pin = pin.slice(0, -1); gateMsg(''); }
      else if (pin.length < 4) { pin += k; gateMsg(''); }
      paintDots();
      if (pin.length === 4) setTimeout(submitPin, 120);
    });
    $('#gateEnter').addEventListener('click', submitPin);
    document.addEventListener('keydown', function (e) {
      if (!$('#gate').classList.contains('is-done')) {
        if (/^[0-9]$/.test(e.key) && pin.length < 4) { pin += e.key; paintDots(); if (pin.length === 4) setTimeout(submitPin, 120); }
        if (e.key === 'Backspace') { pin = pin.slice(0, -1); paintDots(); }
        if (e.key === 'Enter') submitPin();
      } else {
        armAutoLock();
        if (e.key === 'Escape') { closeDrawer(); }
      }
    });
    ['pointerdown', 'touchstart'].forEach(function (name) {
      document.addEventListener(name, function () {
        if ($('#gate').classList.contains('is-done')) armAutoLock();
      }, { passive: true });
    });
  }

  /* ---------------------------------------------------------------- bind -- */
  function setPage(p) {
    state.page = p;
    $$('#admNav button').forEach(function (b) { b.classList.toggle('is-active', b.getAttribute('data-page') === p); });
    $$('.page').forEach(function (s) { s.classList.toggle('is-active', s.getAttribute('data-page') === p); });
    var titles = {
      overview: ['Overview', 'Good ' + (new Date().getHours() < 12 ? 'morning' : new Date().getHours() < 18 ? 'afternoon' : 'evening') + ', coach'],
      members: ['Members', 'Your roster'],
      attendance: ['Attendance', 'Check-in'],
      plans: ['Monthly plan', 'Program of the month'],
      offers: ['Offers', 'Abonnements & extras'],
      payments: ['Payments', 'Money in'],
      settings: ['Settings', 'Access & data']
    }[p];
    $('#pageEyebrow').textContent = titles[0];
    $('#pageTitle').textContent = titles[1];
  }

  function bind() {
    bindGate();
    $('#admNav').addEventListener('click', function (e) {
      var ownerButton = e.target.closest('[data-owner-console]');
      if (ownerButton) { window.location.href = '/owner'; return; }
      var b = e.target.closest('button[data-page]');
      if (b) setPage(b.getAttribute('data-page'));
    });
    var ownerNav = $('#ownerConsoleNav');
    var requestBtn = $('#ownerRequestBtn');
    var requestStatus = $('#ownerRequestStatus');
    var ownerLink = $('#ownerConsoleLink');
    function updateOwnerRequest() {
      if (!API) return;
      fetch('/api/owner/request-status', { cache: 'no-store' }).then(function (r) {
        if (!r.ok) throw new Error('Owner request status unavailable');
        return r.json();
      }).then(function (data) {
        var latest = data.requests && data.requests[0];
        if (!latest) {
          if (requestStatus) requestStatus.textContent = 'No request is open. The creator must approve any temporary access.';
          if (requestBtn) requestBtn.disabled = false;
          if (ownerLink) ownerLink.textContent = 'Open creator controls';
          return;
        }
        if (latest.status === 'pending') {
          if (requestStatus) requestStatus.textContent = 'Request sent; waiting for the creator to approve or deny it.';
          if (requestBtn) requestBtn.disabled = true;
        } else if (latest.status === 'approved' && latest.grantExpiresAt * 1000 > Date.now()) {
          if (requestStatus) requestStatus.textContent = 'Approved for 30 minutes. Access expires at ' + new Date(latest.grantExpiresAt * 1000).toLocaleTimeString() + '.';
          if (requestBtn) requestBtn.disabled = true;
          if (ownerLink) ownerLink.textContent = 'Open approved Owner Console →';
        } else {
          if (requestStatus) requestStatus.textContent = latest.status === 'denied' ? 'The creator declined this request. You can submit a new one if needed.' : 'This grant has expired or was revoked. Request access again if needed.';
          if (requestBtn) requestBtn.disabled = false;
          if (ownerLink) ownerLink.textContent = 'Open creator controls';
        }
      }).catch(function () {
        if (requestStatus) requestStatus.textContent = 'Owner request service is not available.';
      });
    }
    if (!API) {
      if (ownerNav) ownerNav.hidden = true;
      if (requestBtn) { requestBtn.disabled = true; requestBtn.textContent = 'Server mode required'; }
      if (requestStatus) requestStatus.textContent = 'Temporary creator access is available only on the protected server, not in the offline demo.';
    } else {
      updateOwnerRequest();
      setInterval(updateOwnerRequest, 10000);
      if (requestBtn) requestBtn.addEventListener('click', function () {
        var payload = {
          scope: $('#ownerRequestScope').value,
          reason: ($('#ownerRequestReason').value || '').trim()
        };
        if (payload.reason.length < 8) {
          if (requestStatus) requestStatus.textContent = 'Please explain the request in at least 8 characters.';
          return;
        }
        requestBtn.disabled = true;
        fetch('/api/owner/request', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) })
          .then(function (r) { return r.json().then(function (data) { return { ok: r.ok, data: data }; }); })
          .then(function (result) {
            if (!result.ok) throw new Error(result.data.error || 'Could not submit request');
            $('#ownerRequestReason').value = '';
            if (requestStatus) requestStatus.textContent = 'Request sent. The creator must approve it; it will expire after 30 minutes.';
            updateOwnerRequest();
          }).catch(function (err) {
            requestBtn.disabled = false;
            if (requestStatus) requestStatus.textContent = err.message || 'Could not send request.';
          });
      });
    }
    $('#lockBtn').addEventListener('click', lock);
    $('#lockBtn2').addEventListener('click', lock);
    $('#todayLabel').textContent = new Date().toLocaleDateString('en-GB', { weekday: 'long', day: '2-digit', month: 'long' });

    /* members table + filters */
    $('#memberSearch').addEventListener('input', function (e) { state.search = e.target.value; renderMembers(roster()); });
    $('#memberFilters').addEventListener('click', function (e) {
      var b = e.target.closest('button[data-filter]');
      if (!b) return;
      state.filter = b.getAttribute('data-filter');
      $$('#memberFilters button').forEach(function (x) { x.classList.toggle('is-active', x === b); });
      renderMembers(roster());
    });
    $('#memberTable').addEventListener('click', function (e) {
      var tr = e.target.closest('tr[data-member]');
      if (tr) openMember(tr.getAttribute('data-member'));
    });

    /* attendance */
    $('#attList').addEventListener('click', function (e) {
      var row = e.target.closest('[data-att]');
      if (!row) return;
      var id = row.getAttribute('data-att');
      state.present[id] = !state.present[id];
      row.classList.toggle('is-in', !!state.present[id]);
      $('#attCount').textContent = Object.keys(state.present).filter(function (k) { return state.present[k]; }).length + ' present';
    });
    $('#attSave').addEventListener('click', function () {
      var list = roster(), n = 0;
      list.forEach(function (m) {
        if (state.present[m.id]) {
          m.sessionsUsed = Math.min(m.sessionsTotal, m.sessionsUsed + 1);
          n++;
        }
      });
      saveRoster(list); state.present = {}; renderAll();
      toast(n ? n + ' attendance(s) saved.' : 'No one marked present.');
    });
    $('#attDate').value = today();

    /* plans */
    $('#planGoal').addEventListener('change', function (e) { state.planGoal = e.target.value; renderPlans(); });
    $('#planSave').addEventListener('click', savePlans);
    $('#offersSave').addEventListener('click', saveOffers);

    /* notes */
    $('#coachNotes').value = lsGet(K.notes, '');
    $('#saveNotes').addEventListener('click', function () {
      lsSet(K.notes, $('#coachNotes').value); toast('Coach note saved.');
    });

    /* payments */
    $('#addPayment').addEventListener('click', function () {
      var list = roster();
      var name = prompt('Member name for this payment:', list[0] ? list[0].name : 'Walk-in');
      if (!name) return;
      var amount = prompt('Amount in DT:', '150');
      if (!amount) return;
      var pays = payments();
      pays.push({ date: today(), member: name, formula: 'Manual', method: 'cash', amount: +amount, status: 'paid' });
      savePayments(pays); renderPayments(list); renderChart(); toast('Payment recorded.');
    });

    /* quick add member */
    $('#quickAdd').addEventListener('click', function () {
      var name = prompt('New member full name:'); if (!name) return;
      var phone = prompt('Phone / WhatsApp:', '') || '—';
      var which = (prompt('Formula: p4, p8, p12 (private) or g4, g8, gu (club class)', 'g8') || 'g8');
      var p = PLANS[which] || PLANS.g8;
      var list = roster();
      var start = today();
      list.unshift({
        id: 'n' + Date.now(), name: name, phone: phone, planId: PLANS[which] ? which : 'g8',
        planName: p.name, mode: p.mode, goal: 'Fat loss', sessionsTotal: p.sessions, sessionsUsed: 0,
        start: start, end: addMonth(start), price: p.price, paid: true, note: ''
      });
      saveRoster(list); renderAll(); setPage('members'); toast(name + ' added.');
    });

    /* settings */
    $('#savePin').addEventListener('click', function () {
      var a = $('#newPin').value.trim(), b = $('#newPin2').value.trim();
      if (API && !/^[0-9]{8,10}$/.test(a)) return toast('Use 8–10 digits for the server login.');
      if (!API && !/^[0-9]{4}$/.test(a)) return toast('Use exactly 4 digits in offline demo mode.');
      if (a !== b) return toast('The two codes do not match.');
      if (API) {
        fetch(API, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ newPin: a }) })
          .then(function (r) {
            if (r.status === 401) { window.location.href = '/login'; return; }
            if (!r.ok) throw new Error('Could not update code');
            $('#newPin').value = ''; $('#newPin2').value = '';
            toast('Access code updated on the server.');
          })
          .catch(function () { toast('Could not update code — check your connection.'); });
        return;
      }
      sha256('kilani:' + a + ':coach').then(function (h) {
        lsSet(K.pin, h ? 'sha:' + h : 'djb:' + djb2('kilani:' + a + ':coach'));
        $('#newPin').value = ''; $('#newPin2').value = '';
        toast('Access code updated.');
      });
    });
    $('#exportData').addEventListener('click', function () {
      var dump = {
        exported: new Date().toISOString(),
        roster: roster(), payments: payments(),
        plans: JSON.parse(lsGet(K.plans, '{}')), notes: lsGet(K.notes, ''), offers: offerData()
      };
      var blob = new Blob([JSON.stringify(dump, null, 2)], { type: 'application/json' });
      var a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = 'kilani-coach-data-' + today() + '.json';
      a.click();
      setTimeout(function () { URL.revokeObjectURL(a.href); }, 2000);
      toast('Export started.');
    });
    $('#resetData').addEventListener('click', function () {
      if (!confirm('Reset all demo members, payments and plans?')) return;
      lsDel(K.roster); lsDel(K.pay); lsDel(K.plans); lsDel(K.notes); lsDel(K.offers);
      renderAll(); toast('Demo data reset.');
    });

    /* member drawer actions (delegated) */
    document.addEventListener('click', function (e) {
      var t = e.target.closest('[data-closeDrawer],[data-inc],[data-dec],[data-plan],[data-savenote],[data-wa],[data-renew],[data-paid],[data-del],[data-open],[data-save-member],[data-add-progress],[data-member-code],[data-copy-code]');
      if (!t) return;
      if (t.hasAttribute('data-closeDrawer')) { closeDrawer(); return; }
      if (t.hasAttribute('data-open')) { openMember(t.getAttribute('data-open')); return; }
      if (t.hasAttribute('data-copy-code')) {
        var copyValue = t.getAttribute('data-copy-code');
        if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(copyValue).then(function(){ toast('Member code copied.'); });
        else { window.prompt('Copy member code:', copyValue); }
        return;
      }

      var list = roster();
      function find(id) { return list.filter(function (x) { return x.id === id; })[0]; }
      var id, m;

      if (t.hasAttribute('data-member-code')) {
        id = t.getAttribute('data-member-code');
        var code = randomMemberCode();
        if (!API) {
          m = find(id); if (!m) return;
          m.memberAccessCode = code; saveRoster(list); showMemberCode(code, true); return;
        }
        fetch('/api/member/access', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({memberId:id,code:code}) })
          .then(function(r){ if(r.status===401){window.location.href='/login';return null;} return r.json().then(function(d){return {ok:r.ok,data:d};}); })
          .then(function(result){ if(!result)return; if(!result.ok){toast(result.data.error||'Could not create member code.');return;} showMemberCode(code,false); })
          .catch(function(){toast('Could not create member code — check connection.');});
        return;
      }
      if (t.hasAttribute('data-save-member')) {
        id = t.getAttribute('data-save-member'); m = find(id); if (!m) return;
        var startValue = $('#memberStart').value, endValue = $('#memberEnd').value;
        var totalValue = Math.max(1, +$('#memberSessionsTotal').value || 1);
        var priceValue = Math.max(0, +$('#memberPrice').value || 0);
        if (!startValue || !endValue || endValue <= startValue) { toast('Expiry must be after the start date.'); return; }
        m.start = startValue; m.end = endValue; m.sessionsTotal = totalValue;
        m.sessionsUsed = Math.min(+m.sessionsUsed || 0, totalValue); m.price = priceValue;
        m.goal = $('#memberGoal').value; m.note = $('#memberNote').value;
        m.memberView = {
          note: $('#memberVisibleNote').value,
          programMonth: $('#memberProgramMonth').value.trim(),
          programText: $('#memberProgramText').value,
          visibility: {},
          nutrition: {
            kcal: +$('#memberKcal').value || 0,
            protein: +$('#memberProtein').value || 0,
            carbs: +$('#memberCarbs').value || 0,
            fat: +$('#memberFat').value || 0
          }
        };
        ['showMembership','showProgram','showNutrition','showSessions','showBilling','showOffers','showNote','showProgress'].forEach(function(k){
          var input = $('[data-viewflag="'+k+'"]'); m.memberView.visibility[k] = input ? input.checked : true;
        });
        saveRoster(list); renderAll(); openMember(id); toast('Member settings saved and published to their space.'); return;
      }
      if (t.hasAttribute('data-add-progress')) {
        id = t.getAttribute('data-add-progress'); m = find(id); if (!m) return;
        var weight = +$('#trackWeight').value || 0;
        var waist = +$('#trackWaist').value || 0;
        var bodyFat = +$('#trackBodyFat').value || 0;
        if (!weight && !waist && !bodyFat) { toast('Enter at least one measurement.'); return; }
        m.progress = m.progress || [];
        m.progress.push({date:today(),weight:weight || '',waist:waist || '',bodyFat:bodyFat || '',note:$('#trackNote').value.trim()});
        saveRoster(list); renderAll(); openMember(id); toast('Progress check-in logged.'); return;
      }

      if (t.hasAttribute('data-inc')) {
        id = t.getAttribute('data-inc'); m = find(id);
        m.sessionsUsed = Math.min(m.sessionsTotal, m.sessionsUsed + 1);
        saveRoster(list); renderAll(); openMember(id); return;
      }
      if (t.hasAttribute('data-dec')) {
        id = t.getAttribute('data-dec'); m = find(id);
        m.sessionsUsed = Math.max(0, m.sessionsUsed - 1);
        saveRoster(list); renderAll(); openMember(id); return;
      }
      if (t.hasAttribute('data-plan')) {
        id = t.getAttribute('data-plan'); m = find(id);
        var p = PLANS[t.value];
        m.planId = t.value; m.planName = p.name; m.mode = p.mode;
        m.sessionsTotal = p.sessions; m.price = p.price;
        m.sessionsUsed = Math.min(m.sessionsUsed, p.sessions);
        saveRoster(list); renderAll(); openMember(id); toast('Formula updated.'); return;
      }
      if (t.hasAttribute('data-savenote')) {
        id = t.getAttribute('data-savenote'); m = find(id);
        m.note = $('#memberNote').value;
        saveRoster(list); toast('Note saved.'); return;
      }
      if (t.hasAttribute('data-renew')) {
        id = t.getAttribute('data-renew'); m = find(id);
        m.start = today(); m.end = addMonth(today()); m.sessionsUsed = 0; m.paid = true;
        saveRoster(list);
        var pays = payments();
        pays.push({ date: today(), member: m.name, formula: m.planName, method: 'cash', amount: m.price, status: 'paid' });
        savePayments(pays);
        renderAll(); if ($('#memberDrawer').classList.contains('is-open')) openMember(id);
        toast(m.name + ' renewed for one month.'); return;
      }
      if (t.hasAttribute('data-paid')) {
        id = t.getAttribute('data-paid'); m = find(id);
        m.paid = !m.paid; saveRoster(list); renderAll(); openMember(id);
        toast(m.paid ? 'Marked as paid.' : 'Marked as unpaid.'); return;
      }
      if (t.hasAttribute('data-del')) {
        id = t.getAttribute('data-del'); m = find(id);
        if (!confirm('Remove ' + m.name + ' from the roster?')) return;
        saveRoster(list.filter(function (x) { return x.id !== id; }));
        closeDrawer(); renderAll(); toast('Member removed.'); return;
      }
      if (t.hasAttribute('data-wa')) {
        id = t.getAttribute('data-wa'); m = find(id);
        var num = String(m.phone).replace(/[^0-9]/g, '');
        if (num.length === 8) num = '216' + num;
        var text = encodeURIComponent('Ahla ' + m.name.split(' ')[0] + ', coach Kilani here about your ' + m.planName + ' abonnement.');
        try { window.open('https://wa.me/' + num + '?text=' + text, '_blank', 'noopener'); }
        catch (err) { toast('Demo: would open WhatsApp for ' + m.name + '.'); }
        return;
      }
    });

    /* resume unlocked session — in server mode the server already authenticated us */
    if (API) unlock();
    else if (ssGet(K.session)) unlock();
  }

  document.addEventListener('DOMContentLoaded', function () {
    if (API) {
      var g = document.getElementById('gate');
      if (g) g.classList.add('is-done');
    }
    setPage('overview');
    bind();
    paintDots();
    $('#memberDrawer').setAttribute('aria-hidden', 'true');
  });
})();

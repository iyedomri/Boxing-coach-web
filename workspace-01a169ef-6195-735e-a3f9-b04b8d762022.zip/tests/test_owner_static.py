"""Static acceptance checks for Owner Console separation and checkout safety."""
import pathlib
import re
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]


class OwnerStaticTest(unittest.TestCase):
    def test_public_checkout_is_off_and_has_no_raw_card_or_cvv_inputs(self):
        body = (ROOT / "src" / "body.html").read_text(encoding="utf-8")
        app = (ROOT / "src" / "app.js").read_text(encoding="utf-8")
        self.assertNotRegex(body, re.compile(r"<input\b[^>]*(?:card|cvc|cvv)", re.I))
        self.assertNotIn('id="coCard"', body)
        self.assertNotIn('id="coCvc"', body)
        self.assertIn("CASH · PAY IN PERSON", body)
        self.assertIn("D17 · INTEGRATION IN PROGRESS", body)
        self.assertNotIn("FLOUCI", body.upper())
        self.assertNotIn("MASTERCARD", body.upper())
        self.assertIn("var siteOps = { paymentsEnabled:false, bookingsEnabled:false", app)
        self.assertIn("if (!siteOps || siteOps.paymentsEnabled !== true)", app)
        self.assertIn("D17 integration is in progress", app)
        self.assertIn("Ask about cash enrolment", app)
        self.assertIn("arrange cash payment in person at the club.", app)
        self.assertIn("encodeURIComponent(cashMessage)", app)
        self.assertIn("No payment was taken.", app)

    def test_owner_console_is_separate_and_coach_can_only_request_access(self):
        owner = (ROOT / "src" / "owner-body.html").read_text(encoding="utf-8")
        admin = (ROOT / "src" / "admin-body.html").read_text(encoding="utf-8")
        coach_js = (ROOT / "src" / "admin.js").read_text(encoding="utf-8")
        backend = (ROOT / "server.py").read_text(encoding="utf-8")
        self.assertIn('id="ownerLoginPanel"', owner)
        self.assertIn('id="ownerRequestsCard"', owner)
        self.assertIn('Cash in person · D17 in progress', owner)
        self.assertIn('In progress · not live', owner)
        self.assertIn('data-owner-console', admin)
        self.assertIn("/api/owner/request", coach_js)
        self.assertIn('if not self.owner_authed():', backend)
        self.assertIn('OWNER_GRANT_SECONDS = 30 * 60', backend)
        self.assertIn('OWNER_ACCESS_KEY', backend)


if __name__ == "__main__":
    unittest.main()

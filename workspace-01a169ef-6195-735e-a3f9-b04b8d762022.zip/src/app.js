/* =========================================================================
   KILANI — app logic (demo, localStorage backed)
   ========================================================================= */
(function () {
  'use strict';

  var DAY = 86400000;
  var KEY = 'kilani_membership_v1';
  var MEM = {};                       /* in-memory fallback (sandboxed iframes block localStorage) */

  function lsGet(k, dflt) {
    try { var v = localStorage.getItem(k); return v === null ? (k in MEM ? MEM[k] : dflt) : v; }
    catch (e) { return k in MEM ? MEM[k] : dflt; }
  }
  function lsSet(k, v) {
    MEM[k] = v;
    try { localStorage.setItem(k, v); } catch (e) {}
  }
  function lsDel(k) {
    delete MEM[k];
    try { localStorage.removeItem(k); } catch (e) {}
  }
  function memberStorageKey(k) {
    return state.remoteMember && state.membership ? 'kilani_member_' + state.membership.id + '_' + k : k;
  }

  /* ---------------------------------------------------------------- data */
  var PLANS = {
    private: [
      {
        id: 'p4', tier: 'Private', name: 'Starter', price: 180, sessions: 4, weeks: 4,
        desc: 'Once a week, one to one. Technique, pads and a plan you can repeat alone.',
        feats: ['4 private sessions / month', 'Full boxing technique & pad work', 'Monthly training plan', 'WhatsApp support', 'Body measurements every 2 weeks', 'Nutrition plan', 'Video technique review'],
        no: [5, 6]
      },
      {
        id: 'p8', tier: 'Private', name: 'Fighter', price: 320, sessions: 8, weeks: 4, feature: true, flag: 'Most chosen',
        desc: 'Twice a week with the coach. The sweet spot for real transformation.',
        feats: ['8 private sessions / month', 'Full boxing technique & pad work', 'Strength & conditioning program', 'Monthly training plan', 'Nutrition plan + weekly check-in', 'Body measurements every 2 weeks', 'WhatsApp support 7 days', 'Video technique review']
      },
      {
        id: 'p12', tier: 'Private', name: 'Corner', price: 430, sessions: 12, weeks: 4,
        desc: 'Three sessions a week. Competition-minded, fully supervised.',
        feats: ['12 private sessions / month', 'Everything in Fighter', 'Sparring preparation', 'Priority booking on all slots', 'Custom meal structure', 'Direct coach line']
      }
    ],
    group: [
      {
        id: 'g4', tier: 'Club class', name: 'Boxing Fit', price: 90, sessions: 4, weeks: 4,
        desc: 'One boxe anglaise class a week with the club. High energy, zero experience needed.',
        feats: ['4 club classes / month', 'Boxe anglaise with coach Kilani', 'Cardio boxing & conditioning', 'Monthly training plan', 'WhatsApp group support', 'Nutrition plan', 'Private sessions']
      },
      {
        id: 'g8', tier: 'Club class', name: 'Double Round', price: 150, sessions: 8, weeks: 4, feature: true, flag: 'Best value',
        desc: 'Twice a week in the club class. The most popular way to train here.',
        feats: ['8 club classes / month', 'Boxe anglaise with coach Kilani', 'Boxing skills + strength circuits', 'Monthly training plan', 'Nutrition targets', 'Body measurements monthly', 'WhatsApp group support']
      },
      {
        id: 'gu', tier: 'Club class', name: 'Unlimited', price: 220, sessions: 14, weeks: 4,
        desc: 'Every group slot on the schedule, plus priority when a spot frees up.',
        feats: ['14 club classes / month', 'All class slots on the schedule', 'Priority spot when full', 'Everything in Double Round', '1 private session offered', 'Nutrition + measurements']
      }
    ]
  };

  var ADDONS = [
    { id: 'nutri', name: 'Nutrition coaching', price: 40, note: 'Custom meal structure + 2 revisions' },
    { id: 'video', name: 'Video technique review', price: 30, note: 'Send your shadow boxing, get feedback' },
    { id: 'kit', name: 'Start kit', price: 75, note: 'Wraps, gloves and a jump rope' }
  ];

  /* real class board from the club poster: adultes / juniors / cadets */
  var SCHEDULE = [
    { d: 'Mon', cls: 'Boxe anglaise · Cadets', hr: '18h15 – 19h15', tag: 'Cadets' },
    { d: 'Tue', cls: 'Adultes 19h30 · Juniors 18h15', hr: 'Two classes', tag: 'Adults+Juniors', multi: [
        { t: '18h15', n: 'Juniors' }, { t: '19h30', n: 'Adultes' }] },
    { d: 'Wed', cls: 'Boxe anglaise · Cadets', hr: '18h15 – 19h15', tag: 'Cadets' },
    { d: 'Thu', cls: 'Adultes 19h30 · Juniors 18h15', hr: 'Two classes', tag: 'Adults+Juniors', multi: [
        { t: '18h15', n: 'Juniors' }, { t: '19h30', n: 'Adultes' }] },
    { d: 'Fri', cls: 'Boxe anglaise · Cadets', hr: '18h15 – 19h15', tag: 'Cadets' },
    { d: 'Sat', cls: 'Adultes 18h00 · Juniors 17h15', hr: 'Two classes', tag: 'Adults+Juniors', multi: [
        { t: '17h15', n: 'Juniors' }, { t: '18h00', n: 'Adultes' }] },
    { d: 'Sun', cls: 'Rest & recovery', hr: 'Private slots only', tag: 'Recovery', rest: true }
  ];

  var PROGRAM = {
    'Fat loss': [
      { w: 'Week 1', sub: 'Base — movement quality & first engine work', blocks: [
        { k: 'Session 1', b: 'Technique + intervals', s: 'Stance, jab mechanics · 6 × 2 min bag rounds, 1 min rest · 25 min zone 2 at the end' },
        { k: 'Session 2', b: 'Full body strength', s: 'Goblet squat 4×8 · push-ups 4×10 · row 4×10 · carry 3×30 m · core 3 rounds' },
        { k: 'Session 3', b: 'Cardio boxing circuit', s: '8 rounds: shadow 2\u2032 / jump rope 1\u2032 / squat-press 40 s / rest 60 s' }
      ]},
      { w: 'Week 2', sub: 'Add density, keep the technique clean', blocks: [
        { k: 'Session 1', b: 'Jab–cross–hook', s: 'Pad work 5×3 min · footwork ladders · 20 min tempo run' },
        { k: 'Session 2', b: 'Lower + upper split', s: 'Deadlift 4×5 · split squat 3×10 · pull-ups 4×6 · press 3×8' },
        { k: 'Session 3', b: 'Metcon', s: '5 rounds: 12 swings / 10 burpees / 30 s heavy bag / 90 s rest' }
      ]},
      { w: 'Week 3', sub: 'Intensity block', blocks: [
        { k: 'Session 1', b: 'Speed & combinations', s: '6 × 3 min pads at 80% · slip rope · 1500 m row test' },
        { k: 'Session 2', b: 'Strength maintenance', s: 'Squat 4×5 @75% · incline press 4×8 · row 4×8 · core circuit' },
        { k: 'Session 3', b: 'Long conditioning', s: '40 min steady bag + bike · 10 min mobility' }
      ]},
      { w: 'Week 4', sub: 'Sharpen, test, deload', blocks: [
        { k: 'Session 1', b: 'Test day', s: 'Max clean rounds in 12 min · 2 min push-up test · photos & measurements' },
        { k: 'Session 2', b: 'Light technique', s: 'Shadow work only, 30 min · mobility 15 min' },
        { k: 'Session 3', b: 'Recovery', s: 'Walk 40 min · stretch · sleep target 8 h' }
      ]}
    ],
    'Muscle gain': [
      { w: 'Week 1', sub: 'Progressive overload baseline', blocks: [
        { k: 'Session 1', b: 'Push + pad power', s: 'Bench 4×6 · overhead press 3×8 · dips 3×8 · 4 rounds pads' },
        { k: 'Session 2', b: 'Pull + chassis', s: 'Pull-ups 4×6 · row 4×8 · face pull 3×15 · plank 3×45 s' },
        { k: 'Session 3', b: 'Legs', s: 'Squat 4×6 · Romanian deadlift 3×8 · lunge 3×10 · calf 4×12' }
      ]},
      { w: 'Week 2', sub: 'Volume up 10%', blocks: [
        { k: 'Session 1', b: 'Push + heavy bag', s: 'Incline press 4×8 · lateral raise 3×15 · 5 × 2 min power rounds' },
        { k: 'Session 2', b: 'Pull + grip', s: 'Weighted pull-ups 4×5 · chest-supported row 4×10 · farmer carry' },
        { k: 'Session 3', b: 'Legs + core', s: 'Front squat 4×5 · hip thrust 3×10 · hanging knee raise 3×12' }
      ]},
      { w: 'Week 3', sub: 'Peak week', blocks: [
        { k: 'Session 1', b: 'Upper power', s: 'Bench 5×5 @80% · push press 4×5 · 4 rounds pads' },
        { k: 'Session 2', b: 'Lower power', s: 'Deadlift 4×4 @82% · jump squat 3×6 · sled or hill 5×20 m' },
        { k: 'Session 3', b: 'Accessory pump', s: '12 min arms · 12 min shoulders · 10 min core' }
      ]},
      { w: 'Week 4', sub: 'Deload & measure', blocks: [
        { k: 'Session 1', b: 'Technique lifts', s: '60% of week 3 volume, focus on speed' },
        { k: 'Session 2', b: 'Mobility + bag work', s: '30 min flow · 6 easy rounds' },
        { k: 'Session 3', b: 'Check-in', s: 'Weight, measurements, photos, adjust calories' }
      ]}
    ],
    'Boxing skills': [
      { w: 'Week 1', sub: 'Stance, guard, jab', blocks: [
        { k: 'Session 1', b: 'Foundations', s: 'Stance & balance · jab mechanics 6×2 min · mirror work' },
        { k: 'Session 2', b: 'Footwork', s: 'Ladder drills · pivot & step-off · jab + step 5×3 min' },
        { k: 'Session 3', b: 'Conditioning', s: '6 rounds bag · 3 rounds shadow · rope 10 min' }
      ]},
      { w: 'Week 2', sub: 'Jab–cross, movement', blocks: [
        { k: 'Session 1', b: 'The 1–2', s: 'Pad work 6×3 min · cross mechanics · weight transfer drills' },
        { k: 'Session 2', b: 'Defence', s: 'Slip, roll, catch · partner drills 5×2 min' },
        { k: 'Session 3', b: 'Cardio boxing', s: '10 rounds 2 min on / 40 s off, technique first' }
      ]},
      { w: 'Week 3', sub: 'Combinations & angles', blocks: [
        { k: 'Session 1', b: 'Three-punch combos', s: '1–2–3 · 1–1–2 · 2–3–2 on pads, 8 rounds' },
        { k: 'Session 2', b: 'Angles + counter', s: 'Step-off counters · pivot after combination 6 rounds' },
        { k: 'Session 3', b: 'Controlled sparring', s: 'Technical rounds, 50% power, coach-supervised' }
      ]},
      { w: 'Week 4', sub: 'Put it together', blocks: [
        { k: 'Session 1', b: 'Free flow pads', s: '8 rounds, coach calls the numbers only' },
        { k: 'Session 2', b: 'Ring craft', s: 'Rope work · corner exits · ring generalship drills' },
        { k: 'Session 3', b: 'Test', s: '3 × 3 min rounds, filmed and reviewed together' }
      ]}
    ],
    'Cardio / fitness': [
      { w: 'Week 1', sub: 'Get the engine running', blocks: [
        { k: 'Session 1', b: 'Intro intervals', s: '8 rounds 1 min on / 1 min off, bodyweight + bag' },
        { k: 'Session 2', b: 'Strength circuit', s: '3 rounds: squat 12 / push-up 10 / row 12 / plank 40 s' },
        { k: 'Session 3', b: 'Zone 2', s: '30–40 min easy walk, bike or row' }
      ]},
      { w: 'Week 2', sub: 'Build the rounds', blocks: [
        { k: 'Session 1', b: 'Boxing cardio', s: '10 × 2 min bag rounds, 45 s rest' },
        { k: 'Session 2', b: 'Full body', s: 'Goblet squat 4×12 · press 4×10 · row 4×12 · core' },
        { k: 'Session 3', b: 'Zone 2', s: '40 min steady, nose breathing only' }
      ]},
      { w: 'Week 3', sub: 'Push the ceiling', blocks: [
        { k: 'Session 1', b: 'HIIT', s: '6 rounds: 30 s hard / 30 s easy on bike or rope' },
        { k: 'Session 2', b: 'Strength endurance', s: '5 rounds: 10 swings / 8 push-ups / 20 s plank / 200 m row' },
        { k: 'Session 3', b: 'Long easy', s: '45 min low intensity' }
      ]},
      { w: 'Week 4', sub: 'Test and reset', blocks: [
        { k: 'Session 1', b: 'Benchmark', s: 'Max rounds in 15 min, note the score' },
        { k: 'Session 2', b: 'Mobility', s: 'Hips, shoulders, 30 min flow' },
        { k: 'Session 3', b: 'Easy movement', s: 'Walk + stretch, prep next month' }
      ]}
    ],
    'Competition prep': [
      { w: 'Week 1', sub: 'Assessment & base', blocks: [
        { k: 'Session 1', b: 'Technical audit', s: 'Filmed rounds, identify 3 priorities for the month' },
        { k: 'Session 2', b: 'Strength base', s: 'Squat 5×5 · press 4×6 · pull 4×8' },
        { k: 'Session 3', b: 'Roadwork', s: '5 km easy + 6 rounds shadow' }
      ]},
      { w: 'Week 2', sub: 'Volume', blocks: [
        { k: 'Session 1', b: 'Pads 10 rounds', s: 'Combination volume, coach calls numbers' },
        { k: 'Session 2', b: 'Sparring', s: '6 × 2 min technical rounds' },
        { k: 'Session 3', b: 'Conditioning', s: 'Hill sprints 8×20 m + core' }
      ]},
      { w: 'Week 3', sub: 'Intensity', blocks: [
        { k: 'Session 1', b: 'Hard sparring', s: '8 rounds, competition pace, filmed' },
        { k: 'Session 2', b: 'Power', s: 'Deadlift 4×4 · med ball throws 5×5 · neck & grip' },
        { k: 'Session 3', b: 'Recovery', s: 'Pool / walk / stretch, sleep priority' }
      ]},
      { w: 'Week 4', sub: 'Sharpen', blocks: [
        { k: 'Session 1', b: 'Sharp rounds', s: '6 rounds, speed over power' },
        { k: 'Session 2', b: 'Game plan', s: 'Video review, opponent patterns, corner calls' },
        { k: 'Session 3', b: 'Weigh-in prep', s: 'Water & carb plan, light session only' }
      ]}
    ]
  };

  var MEALS = {
    'Fat loss': [
      { ic: '☀', n: 'Breakfast · 07:30', d: '2 eggs + 2 whites, 40 g oats, coffee', k: 420 },
      { ic: '◐', n: 'Lunch · 13:00', d: '150 g chicken, 150 g rice, big salad, olive oil', k: 620 },
      { ic: '⌁', n: 'Pre-training · 17:30', d: 'Banana + 1 tbsp honey + black coffee', k: 180 },
      { ic: '☾', n: 'Dinner · 20:30', d: '180 g fish or turkey, vegetables, 1 tbsp olive oil', k: 480 },
      { ic: '·', n: 'Optional', d: '150 g Greek yogurt + 10 almonds', k: 190 }
    ],
    'Muscle gain': [
      { ic: '☀', n: 'Breakfast · 07:30', d: '4 eggs, 80 g oats, 1 banana, honey', k: 720 },
      { ic: '◐', n: 'Lunch · 13:00', d: '200 g chicken, 250 g rice, vegetables, olive oil', k: 880 },
      { ic: '⌁', n: 'Pre-training · 17:30', d: 'Bread + tuna + dates', k: 420 },
      { ic: '✚', n: 'Post-training · 19:30', d: 'Whey or 300 g yogurt + honey + 1 fruit', k: 350 },
      { ic: '☾', n: 'Dinner · 21:00', d: '200 g beef or fish, potatoes, salad', k: 760 }
    ],
    'Boxing skills': [
      { ic: '☀', n: 'Breakfast · 07:00', d: '3 eggs, 60 g oats, fruit', k: 540 },
      { ic: '◐', n: 'Lunch · 13:00', d: '180 g chicken, 180 g pasta, salad', k: 720 },
      { ic: '⌁', n: 'Pre-training · 17:00', d: '2 dates + coffee', k: 130 },
      { ic: '☾', n: 'Dinner · 20:30', d: 'Fish, couscous (small), vegetables', k: 620 },
      { ic: '·', n: 'Before bed', d: '200 g yogurt + cinnamon', k: 180 }
    ],
    'Cardio / fitness': [
      { ic: '☀', n: 'Breakfast · 07:30', d: 'Yogurt bowl, oats, fruit, almonds', k: 450 },
      { ic: '◐', n: 'Lunch · 13:00', d: 'Chicken wrap + big salad', k: 580 },
      { ic: '⌁', n: 'Pre-training · 17:30', d: 'Apple + 10 almonds', k: 180 },
      { ic: '☾', n: 'Dinner · 20:30', d: 'Omelette 3 eggs, vegetables, bread slice', k: 480 }
    ],
    'Competition prep': [
      { ic: '☀', n: 'Breakfast · 06:30', d: 'Oats 80 g, 3 eggs, banana', k: 640 },
      { ic: '◐', n: 'Lunch · 12:30', d: '200 g chicken, 200 g rice, veg', k: 760 },
      { ic: '⌁', n: 'Pre-training · 16:30', d: 'Bread + honey + coffee', k: 320 },
      { ic: '☾', n: 'Dinner · 20:00', d: '200 g fish, potatoes, olive oil', k: 640 },
      { ic: '·', n: 'Weigh-in week', d: 'Coach adjusts water & carbs daily', k: 0 }
    ]
  };

  /* ------------------------------------------------------------- helpers */
  function $(s, r) { return (r || document).querySelector(s); }
  function $$(s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); }
  function dt(n) { return n + ' DT'; }
  function escHTML(value) { return String(value == null ? '' : value).replace(/[&<>\"']/g, function(c){ return {'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;',"'":'&#39;'}[c]; }); }
  function pad(n) { return n < 10 ? '0' + n : '' + n; }
  function fmtDate(iso) {
    var d = new Date(iso + 'T00:00:00');
    return d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
  }
  function todayISO() {
    var d = new Date();
    return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
  }
  function daysBetween(a, b) { return Math.round((b - a) / DAY); }
  function toast(msg) {
    var t = $('#toast');
    $('#toastTxt').textContent = msg;
    t.classList.add('is-on');
    clearTimeout(t._t);
    t._t = setTimeout(function () { t.classList.remove('is-on'); }, 3400);
  }

  /* coach-published plans and site operations flags */
  var published = {};
  var siteOps = { paymentsEnabled:false, bookingsEnabled:false, provider:'D17' };
  function applySiteOps() {
    var notice = $('#siteOpsNotice');
    if (!notice) return;
    var paymentsEnabled = !!(siteOps && siteOps.paymentsEnabled === true);
    var bookingsEnabled = !!(siteOps && siteOps.bookingsEnabled === true);
    if (!paymentsEnabled || !bookingsEnabled) {
      notice.hidden = false;
      notice.innerHTML = (!paymentsEnabled
        ? '<b>Payment options:</b> cash in person at the club; D17 integration is in progress and not live yet. '
        : '') + (!bookingsEnabled
        ? '<b>Live booking is not available yet.</b> Contact coach Kilani to arrange a session. '
        : '') + '<a href="https://wa.me/21694077310" target="_blank" rel="noopener">Message the coach</a>.'
    } else {
      notice.hidden = true;
      notice.textContent = '';
    }
    $$('#plansGrid [data-buy]').forEach(function (button) {
      var plan = findPlan(button.getAttribute('data-buy'));
      button.disabled = false;
      button.setAttribute('aria-disabled', 'false');
      if (!paymentsEnabled) {
        button.textContent = 'Ask about cash enrolment →';
        button.setAttribute('aria-label', 'Ask Kilani about ' + (plan ? plan.name : 'this plan') + ' and arrange in-person cash payment');
      } else {
        button.textContent = 'Choose ' + (plan ? plan.name : 'plan') + ' →';
        button.removeAttribute('aria-label');
      }
    });
  }
  function loadSiteOps() {
    if (window.location.protocol === 'file:') return;
    try {
      fetch('/api/site-status', { cache:'no-store' })
        .then(function (r) { return r.ok ? r.json() : null; })
        .then(function (data) { if (data) { siteOps = data; applySiteOps(); if (state.membership) renderSessions(); } })
        .catch(function () {});
    } catch (e) {}
  }
  function parseConfig(value) {
    if (!value) return null;
    if (typeof value === 'string') { try { return JSON.parse(value); } catch (e) { return null; } }
    return value;
  }
  function applyPublicOffers(value) {
    var config = parseConfig(value);
    if (!config || !config.plans) return;
    PLANS.private.concat(PLANS.group).forEach(function(p){
      var o = config.plans[p.id]; if (!o) return;
      p.name = o.name || p.name; p.price = Math.max(0, +o.price || 0);
      p.sessions = Math.max(1, +o.sessions || p.sessions); p.desc = o.desc || p.desc;
      if (Array.isArray(o.features)) p.feats = o.features;
      else if (typeof o.features === 'string') p.feats = o.features.split(/\n/).filter(Boolean);
      p.active = o.active !== false;
    });
    if (Array.isArray(config.addons)) {
      config.addons.forEach(function(a){
        var existing = ADDONS.filter(function(x){return x.id===a.id;})[0];
        if (existing) { existing.name=a.name||existing.name; existing.price=Math.max(0,+a.price||0); existing.note=a.note||''; existing.active=a.active!==false; }
      });
    }
  }
  function loadPublishedPlans() {
    function take(obj) {
      obj = parseConfig(obj);
      if (obj && typeof obj === 'object') published = obj;
    }
    try {
      take(localStorage.getItem('kilani_admin_plans_v1'));
      applyPublicOffers(localStorage.getItem('kilani_admin_offers_v1'));
    } catch (e) {}
    try {
      fetch('/api/public-plan', { cache: 'no-store' })
        .then(function (r) { return r.ok ? r.json() : null; })
        .then(function (data) {
          if (!data) return;
          if (data.plans) take(data.plans);
          if (data.offers) applyPublicOffers(data.offers);
          renderPlans();
          if (state.membership) renderMember();
        })
        .catch(function () {});
    } catch (e) {}
  }
  function toProgWeeks(pub) {
    return pub.weeks.map(function (w, i) {
      var lines = String(w.body || '').split(/\n+/).filter(function (l) { return l.trim(); });
      return {
        w: w.title || ('Week ' + (i + 1)),
        sub: lines.length + ' session' + (lines.length === 1 ? '' : 's') + ' · from your coach',
        blocks: lines.map(function (line) {
          var dash = line.indexOf('—');
          var head = dash > 0 ? line.slice(0, dash).trim() : line.trim();
          var tail = dash > 0 ? line.slice(dash + 1).trim() : '';
          var dot = head.indexOf('·');
          return {
            k: dot > 0 ? head.slice(0, dot).trim() : 'Session',
            b: dot > 0 ? head.slice(dot + 1).trim() : head,
            s: tail
          };
        })
      };
    });
  }

  /* -------------------------------------------------------------- state */
  var state = {
    mode: 'private',
    membership: null,
    remoteMember: false,
    draft: { planId: null, addons: [], pay: 'card' }
  };
  var memberAuthRequest = 0;

  function load() {
    try {
      var raw = lsGet(KEY, null);
      state.membership = raw ? JSON.parse(raw) : null;
    } catch (e) { state.membership = null; }
  }
  function save() {
    if (state.remoteMember && state.membership) {
      fetch('/api/member/checkin', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({sessionsUsed:state.membership.sessionsUsed}) })
        .then(function(r){ if(r.status===401) loadRemoteMember(); })
        .catch(function() {});
      return;
    }
    if (state.membership) lsSet(KEY, JSON.stringify(state.membership));
    else lsDel(KEY);
  }

  function updateMemberAccessUI() {
    var form = $('#memberAccessForm'), active = $('#memberAccessActive');
    if (!form || !active) return;
    form.hidden = !!state.remoteMember;
    active.hidden = !state.remoteMember;
    if (state.remoteMember && state.membership) $('#memberAccessName').textContent = state.membership.name;
  }
  function loginMember(code) {
    var msg = $('#memberAccessMessage');
    if (!/^[0-9]{8,10}$/.test(code)) { msg.textContent = 'Enter the 8–10 digit code from your coach.'; return; }
    msg.textContent = 'Checking your code…';
    var requestId = ++memberAuthRequest;
    fetch('/api/member/login', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({code:code}) })
      .then(function(r){ return r.json().then(function(d){return {ok:r.ok,status:r.status,data:d};}); })
      .then(function(result){
        if (requestId !== memberAuthRequest) return;
        if (!result.ok) { msg.textContent = result.data.error || 'Code not recognised. Ask your coach.'; return; }
        state.membership = result.data.member; state.remoteMember = true;
        msg.textContent = ''; $('#memberAccessCode').value = '';
        updateMemberAccessUI(); renderMember();
        toast('Welcome, ' + state.membership.name + '. Your personal space is ready.');
      })
      .catch(function(){ if (requestId === memberAuthRequest) msg.textContent = 'Member login is available on the secure coach server.'; });
  }
  function loadRemoteMember() {
    var requestId = ++memberAuthRequest;
    fetch('/api/member/me', { cache:'no-store' })
      .then(function(r){
        if (requestId !== memberAuthRequest) return null;
        if (r.status === 401) {
          state.remoteMember = false; state.membership = null; lsDel(KEY);
          updateMemberAccessUI(); renderMember();
          return null;
        }
        return r.ok ? r.json() : null;
      })
      .then(function(data){
        if (requestId !== memberAuthRequest || !data || !data.member) return;
        state.membership = data.member; state.remoteMember = true;
        updateMemberAccessUI(); renderMember();
      })
      .catch(function() {});
  }
  function logoutMember() {
    ++memberAuthRequest;
    fetch('/api/member/logout', { method:'POST' }).catch(function() {}).then(function(){
      state.remoteMember = false; state.membership = null; lsDel(KEY);
      updateMemberAccessUI(); renderMember();
      var msg = $('#memberAccessMessage'); if (msg) msg.textContent = 'You have signed out.';
    });
  }

  function findPlan(id) {
    var all = PLANS.private.concat(PLANS.group);
    for (var i = 0; i < all.length; i++) if (all[i].id === id) return all[i];
    return null;
  }

  function membershipeMetrics(m) {
    if (!m) return null;
    var start = new Date(m.start + 'T00:00:00').getTime();
    var end = new Date(m.end + 'T00:00:00').getTime();
    var now = Date.now();
    var total = Math.max(1, daysBetween(start, end));
    var elapsed = Math.min(total, Math.max(0, daysBetween(start, now)));
    var left = Math.max(0, daysBetween(now, end));
    var leftSessions = Math.max(0, m.sessionsTotal - m.sessionsUsed);
    return {
      total: total, elapsed: elapsed, daysLeft: left,
      pctDays: Math.round((elapsed / total) * 100),
      pctLeft: Math.round((left / total) * 100),
      sessionsLeft: leftSessions,
      pctSessions: Math.round(((m.sessionsTotal - leftSessions) / m.sessionsTotal) * 100),
      expired: left <= 0
    };
  }

  /* --------------------------------------------------------- plan cards */
  function renderPlans() {
    var grid = $('#plansGrid');
    var plans = PLANS[state.mode].filter(function(p){ return p.active !== false; });
    if (!plans.length) { grid.innerHTML = '<div class="card">These offers are temporarily unavailable. Message the coach for the current options.</div>'; return; }
    grid.innerHTML = plans.map(function (p) {
      var offs = p.no || [];
      var feats = p.feats.map(function (f, i) {
        return '<li' + (p.no && i >= p.no[0] ? ' class="off"' : '') + '>' + escHTML(f) + '</li>';
      }).join('');
      return '' +
        '<article class="plan' + (p.feature ? ' plan--feature' : '') + '">' +
          (p.flag ? '<span class="plan__flag">' + escHTML(p.flag) + '</span>' : '') +
          '<span class="plan__tier">' + escHTML(p.tier) + '</span>' +
          '<h3 class="plan__name">' + escHTML(p.name) + '</h3>' +
          '<div class="plan__price"><b>' + p.price + '</b><small>DT</small></div>' +
          '<div class="plan__per">per month · ' + p.sessions + ' sessions · <b>' + (Math.ceil(p.price / p.sessions)) + ' DT</b> / session</div>' +
          '<p class="plan__desc">' + escHTML(p.desc) + '</p>' +
          '<ul class="plan__feats">' + feats + '</ul>' +
          '<button class="btn ' + (p.feature ? 'btn--saffron' : 'btn--ink') + ' btn--block" data-buy="' + escHTML(p.id) + '">' +
            'Choose ' + escHTML(p.name) + ' →' +
          '</button>' +
        '</article>';
    }).join('');
    applySiteOps();
  }

  /* ------------------------------------------------------------ schedule */
  function renderSchedule() {
    $('#schedGrid').innerHTML = SCHEDULE.map(function (s) {
      var body = s.multi
        ? s.multi.map(function (m) {
            return '<div style="display:flex;gap:6px;align-items:baseline;margin-bottom:4px">' +
              '<b style="font-size:.72rem;color:var(--ink);font-variant-numeric:tabular-nums">' + m.t + '</b>' +
              '<span style="font-size:.74rem;color:var(--muted)">' + m.n + '</span></div>';
          }).join('')
        : '';
      return '<div class="sched__day' + (s.rest ? ' is-rest' : '') + '">' +
        '<h5>' + s.d + '</h5>' +
        (s.multi
          ? body
          : '<div class="cl">' + s.cls + '</div><div class="hr">' + s.hr + '</div>') +
        '<span class="sched__tag">' + s.tag + '</span>' +
      '</div>';
    }).join('');
  }

  /* ------------------------------------------------------------ checkout */
  var co = { step: 1, planId: null, addons: [] };

  function openCheckout(planId) {
    co.planId = planId;
    co.addons = [];
    co.step = 1;
    var p = findPlan(planId);
    if (!p) return;
    $('#coStart').value = todayISO();
    renderCheckout();
    $('#checkout').classList.add('is-open');
    $('#checkout').setAttribute('aria-hidden', 'false');
    document.body.classList.add('no-scroll');
  }
  function closeCheckout() {
    $('#checkout').classList.remove('is-open');
    $('#checkout').setAttribute('aria-hidden', 'true');
    document.body.classList.remove('no-scroll');
  }

  function draftTotals() {
    var p = findPlan(co.planId);
    var sub = p ? p.price : 0;
    var add = co.addons.reduce(function (sum, id) {
      var a = ADDONS.filter(function (x) { return x.id === id; })[0];
      return sum + (a ? a.price : 0);
    }, 0);
    var first = co.addons.indexOf('nutri') > -1 ? 0 : 0;
    return { sub: sub, add: add, total: sub + add };
  }

  function renderCheckout() {
    var p = findPlan(co.planId);
    if (!p) return;
    $('#coPlanName').textContent = p.name + ' · ' + p.tier;

    $('#coOptions').innerHTML = (state.mode === 'private' ? PLANS.private : PLANS.group).filter(function(x){return x.active !== false;}).map(function (x) {
      return '<button type="button" class="opt' + (x.id === co.planId ? ' is-sel' : '') + '" data-pick="' + escHTML(x.id) + '">' +
        '<span><b>' + escHTML(x.name) + ' — ' + x.sessions + ' sessions</b><small>' + dt(x.price) + ' / month · ' + (Math.ceil(x.price / x.sessions)) + ' DT per session</small></span>' +
        '<span class="pr">' + dt(x.price) + '</span></button>';
    }).join('');

    $('#coAddons').innerHTML = ADDONS.filter(function(a){return a.active !== false;}).map(function (a) {
      var on = co.addons.indexOf(a.id) > -1;
      return '<button type="button" class="opt' + (on ? ' is-sel' : '') + '" data-add="' + escHTML(a.id) + '">' +
        '<span><b>' + escHTML(a.name) + '</b><small>' + escHTML(a.note) + '</small></span>' +
        '<span class="pr">' + dt(a.price) + '<em>' + (on ? 'added' : '+ add') + '</em></span></button>';
    }).join('');

    var t = draftTotals();
    $('#coSum').innerHTML =
      '<div><span>' + escHTML(p.name) + ' · ' + escHTML(p.tier) + '</span><b>' + dt(t.sub) + '</b></div>' +
      (t.add ? '<div><span>Add-ons</span><b>' + dt(t.add) + '</b></div>' : '') +
      '<div><span>Sessions included</span><b>' + p.sessions + '</b></div>' +
      '<div><span>First renewal</span><b>' + fmtDate(addMonth($('#coStart').value || todayISO())) + '</b></div>';
    $('#coTotal').textContent = dt(t.total);
    if ($('#coPayAmt')) $('#coPayAmt').textContent = dt(t.total);

    $$('#coSteps i').forEach(function (el, i) { el.classList.toggle('is-on', i < co.step); });
    $$('.co__step').forEach(function (el) {
      el.classList.toggle('is-active', +el.getAttribute('data-step') === co.step);
    });
  }

  function addMonth(iso) {
    var d = new Date(iso + 'T00:00:00');
    var day = d.getDate();
    d.setMonth(d.getMonth() + 1);
    if (d.getDate() < day) d.setDate(0);
    return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
  }

  function activate() {
    if (!siteOps || siteOps.paymentsEnabled !== true) {
      closeCheckout();
      toast('No payment was taken. Online checkout is not connected; contact coach Kilani.');
      return;
    }
    var p = findPlan(co.planId);
    var start = $('#coStart').value || todayISO();
    var name = ($('#coName').value || '').trim();
    var phone = ($('#coPhone').value || '').trim();
    var total = draftTotals().total;
    state.membership = {
      name: name || 'Member',
      phone: phone,
      goal: $('#coGoal').value,
      planId: p.id,
      planName: p.name,
      mode: PLANS.private.indexOf(p) > -1 ? 'private' : 'group',
      sessionsTotal: p.sessions,
      sessionsUsed: 0,
      addons: co.addons.slice(),
      price: total,
      start: start,
      end: addMonth(start),
      startedAt: Date.now()
    };
    save();
    co.step = 4;
    var t = draftTotals();
    $('#coRecap').innerHTML =
      '<div><span>Member</span><b>' + escHTML(state.membership.name) + '</b></div>' +
      '<div><span>Abonnement</span><b>' + escHTML(p.name) + '</b></div>' +
      '<div><span>Start</span><b>' + fmtDate(start) + '</b></div>' +
      '<div><span>Renewal</span><b>' + fmtDate(state.membership.end) + '</b></div>' +
      '<div><span>Sessions</span><b>' + p.sessions + '</b></div>' +
      '<div class="tot"><span>Paid</span><b>' + dt(t.total) + '</b></div>';
    renderCheckout();
    renderMember();
    toast('Abonnement activated — welcome to the corner.');
  }

  /* ------------------------------------------------------- member render */
  function emptyPanel(icon, title, text, cta) {
    return '<div class="card dash-empty">' +
      '<div style="font-size:1.8rem">' + icon + '</div>' +
      '<h3 style="font-size:1.05rem">' + title + '</h3>' +
      '<p>' + text + '</p>' +
      '<button class="btn btn--primary btn--sm" data-scrollplans>' + cta + '</button>' +
    '</div>';
  }

  function renderMember() {
    var m = state.membership;
    var met = membershipeMetrics(m);
    var isMember = !!m && !met.expired;
    var view = m && m.memberView ? m.memberView : {};
    var visibility = view.visibility || {};
    updateMemberAccessUI();
    var tabFlags = {program:'showProgram',nutrition:'showNutrition',sessions:'showSessions',billing:'showBilling'};
    $$('#dashTabs button').forEach(function(btn){
      var key = tabFlags[btn.getAttribute('data-panel')];
      btn.hidden = !!(state.remoteMember && key && visibility[key] === false);
    });
    var activeTab = $('#dashTabs button.is-active');
    if (activeTab && activeTab.hidden) {
      $$('#dashTabs button').forEach(function(btn){btn.classList.toggle('is-active',btn.getAttribute('data-panel')==='overview');});
      $$('.panel').forEach(function(panel){panel.classList.toggle('is-active',panel.id==='panel-overview');});
    }
    $('#plans').style.display = state.remoteMember && visibility.showOffers === false ? 'none' : '';
    $('#membershipCard').style.display = state.remoteMember && visibility.showMembership === false ? 'none' : '';
    $('#nextCard').style.display = state.remoteMember && visibility.showSessions === false ? 'none' : '';
    $('#quickCard').style.display = state.remoteMember && visibility.showNote === false && visibility.showProgress === false ? 'none' : '';

    /* nav status */
    var ns = $('#navStatus');
    if (isMember) {
      ns.classList.add('is-on');
      $('#navStatusTxt').innerHTML = '<b>' + met.daysLeft + ' days</b> left · ends ' + escHTML(fmtDate(m.end)) + (visibility.showSessions === false ? '' : ' · ' + met.sessionsLeft + ' sessions');
    } else {
      ns.classList.remove('is-on');
    }

    /* header */
    $('#dashName').textContent = m ? m.name : 'Guest athlete';
    $('#dashSub').textContent = m
      ? (state.remoteMember && visibility.showMembership === false ? 'Personal member space' : (m.planName || (findPlan(m.planId) || {}).name || 'Abonnement') + ' · ' + m.goal) + (met.expired ? ' · expired' : '')
      : 'No active abonnement yet';

    $('#dashHeadActions').innerHTML = state.remoteMember
      ? '<div class="chip">Private member space</div>'
      : m
      ? '<div style="display:flex;gap:10px;flex-wrap:wrap">' +
          '<button class="btn btn--ghost btn--sm" data-reset>Reset demo</button>' +
          (visibility.showOffers === false ? '' : '<a href="#plans" class="btn btn--ink btn--sm">Renew / upgrade</a>') +
        '</div>'
      : '<div style="display:flex;gap:10px;flex-wrap:wrap">' +
          '<button class="btn btn--ghost btn--sm" data-demo>Preview as member</button>' +
          '<a href="#plans" class="btn btn--primary btn--sm">Subscribe</a>' +
        '</div>';

    /* ---- overview ---- */
    var card = $('#membershipCard');
    if (!m) {
      card.innerHTML =
        '<div class="card__head"><h4>Membership</h4><span class="tag">Inactive</span></div>' +
        '<div class="member-status">' +
          '<div class="ring"><svg viewBox="0 0 132 132"><circle class="track" cx="66" cy="66" r="56"/><circle class="bar" cx="66" cy="66" r="56" stroke-dasharray="351.8" stroke-dashoffset="351.8"/></svg>' +
            '<div class="ring__in"><b>0</b><span>days left</span></div></div>' +
          '<div><div class="ms__plan">No abonnement</div>' +
            '<p class="ms__sub">Choose a formula to start your month and unlock the plan.</p>' +
            '<a href="#plans" class="btn btn--saffron btn--sm">See the abonnements</a></div>' +
        '</div>';
    } else {
      var circ = 2 * Math.PI * 56;
      var ringOff = circ * (1 - (met.expired ? 0 : met.pctLeft / 100));
      card.innerHTML =
        '<div class="card__head"><h4>Membership</h4><span class="tag ' + (met.expired ? '' : 'tag--live') + '">' + (met.expired ? 'Expired' : 'Active') + '</span></div>' +
        '<div class="member-status">' +
          '<div class="ring">' +
            '<svg viewBox="0 0 132 132"><circle class="track" cx="66" cy="66" r="56"/>' +
            '<circle class="bar" cx="66" cy="66" r="56" stroke-dasharray="' + circ.toFixed(1) + '" stroke-dashoffset="' + ringOff.toFixed(1) + '"/></svg>' +
            '<div class="ring__in"><b>' + met.daysLeft + '</b><span>days left</span></div>' +
          '</div>' +
          '<div>' +
            '<div class="ms__head"><span class="ms__plan">' + escHTML(m.planName || (findPlan(m.planId) || {}).name || 'Abonnement') + ' <span>· ' + m.sessionsTotal + ' sessions</span></span>' +
              '<span class="tag">' + (m.mode === 'private' ? 'Private 1:1' : 'Club class') + '</span></div>' +
            '<p class="ms__sub">' + fmtDate(m.start) + ' → ' + fmtDate(m.end) + '</p>' +
            '<div class="ms__bars">' +
              '<div class="ms__bar-row"><div class="lbl"><span>Month elapsed</span><b>' + met.pctDays + '%</b></div><div class="track-bar"><i style="width:' + met.pctDays + '%"></i></div></div>' +
              '<div class="ms__bar-row"><div class="lbl"><span>Sessions used</span><b>' + m.sessionsUsed + ' / ' + m.sessionsTotal + '</b></div><div class="track-bar"><i class="olive" style="width:' + met.pctSessions + '%"></i></div></div>' +
              '<div class="ms__bar-row"><div class="lbl"><span>Sessions left</span><b>' + met.sessionsLeft + '</b></div><div class="track-bar"><i class="clay" style="width:' + (100 - met.pctSessions) + '%"></i></div></div>' +
            '</div>' +
            '<div class="countdown">' +
              '<div class="cd-box"><b>' + met.daysLeft + '</b><span>days</span></div>' +
              '<div class="cd-box"><b>' + (met.expired ? 0 : met.sessionsLeft) + '</b><span>sessions</span></div>' +
              '<div class="cd-box"><b>' + (met.expired ? '—' : Math.ceil(met.daysLeft / 7)) + '</b><span>weeks</span></div>' +
              '<div class="cd-box"><b>' + (met.expired ? '—' : fmtDate(m.end).split(' ')[0]) + '</b><span>' + (met.expired ? 'renew' : fmtDate(m.end).split(' ')[1]) + '</span></div>' +
            '</div>' +
            '<div class="ms__foot">' +
              '<span>' + (met.expired ? 'Month ended — renew to keep your slot.' : 'Renews on <b>' + fmtDate(m.end) + '</b>' + (state.remoteMember && visibility.showBilling === false ? '' : ' · ' + dt(m.price))) + '</span>' +
              (met.expired || state.remoteMember ? '' : '<button class="btn btn--saffron btn--sm" data-renew>Renew now</button>') +
            '</div>' +
          '</div>' +
        '</div>' +
        (met.expired ? (state.remoteMember ? '<div style="margin-top:16px"><button class="btn btn--saffron btn--sm btn--block" data-wa>Message coach to renew</button></div>' : '<div style="margin-top:16px"><a href="#plans" class="btn btn--saffron btn--sm btn--block">Renew my month</a></div>') : '');
    }

    /* next session */
    var next = $('#nextCard');
    if (m && met.expired) {
      next.innerHTML = '<div class="card__head"><h4>Next session</h4><span class="tag">Month ended</span></div>' +
        '<p style="margin:0 0 14px;color:var(--muted);font-size:.88rem">Your abonnement ended on <b>' + fmtDate(m.end) + '</b>. Renew to get a fresh month of sessions and a new plan.</p>' +
        (state.remoteMember ? '<button class="btn btn--primary btn--sm" data-wa>Message coach to renew</button>' : '<button class="btn btn--primary btn--sm" data-renew>Renew my month</button>');
    } else if (!isMember) {
      next.innerHTML = '<div class="card__head"><h4>Next session</h4></div>' +
        '<p style="margin:0;color:var(--muted);font-size:.88rem">Once you subscribe, your next booked slot appears here with a countdown.</p>';
    } else {
      var s = nextSlot();
      next.innerHTML = '<div class="card__head"><h4>Next session</h4><span class="tag ' + (s ? 'tag--live' : '') + '">' + (s ? 'Booked' : 'None') + '</span></div>' +
        (s
          ? '<div class="next-session">' +
              '<div class="date"><b>' + s.dayNum + '</b><span>' + s.mon + '</span></div>' +
              '<div><h5>' + s.title + '</h5><p>' + s.time + ' · ' + s.where + '</p></div>' +
            '</div>' +
            '<div style="margin-top:16px;display:flex;gap:8px;flex-wrap:wrap">' +
              '<button class="btn btn--ink btn--sm" data-gopanel="sessions">Manage sessions</button>' +
              '<button class="btn btn--ghost btn--sm" data-wa>Ask coach</button>' +
            '</div>'
          : '<p style="margin:0 0 12px;color:var(--muted);font-size:.88rem">All sessions used or no slot booked.</p><button class="btn btn--primary btn--sm" data-gopanel="sessions">Book a session</button>');
    }

    /* quick card */
    var q = $('#quickCard');
    if (state.remoteMember) {
      var memberNote = visibility.showNote === false ? '' : (view.note || '');
      var latest = (m.progress || []).length ? m.progress[m.progress.length - 1] : null;
      var progressHtml = visibility.showProgress !== false && latest
        ? '<div class="member-progress-mini"><small>Last progress check-in · ' + escHTML(fmtDate(latest.date)) + '</small>' +
          (latest.weight ? '<b>' + escHTML(latest.weight) + ' kg</b>' : '') +
          (latest.waist ? '<span>' + escHTML(latest.waist) + ' cm waist</span>' : '') +
          (latest.bodyFat ? '<span>' + escHTML(latest.bodyFat) + '% body fat</span>' : '') + '</div>' : '';
      var quickLinks = '<div style="display:flex;gap:8px;flex-wrap:wrap">' +
        (visibility.showProgram === false ? '' : '<button class="btn btn--ink btn--sm" data-gopanel="program">Open plan</button>') +
        (visibility.showNutrition === false ? '' : '<button class="btn btn--ghost btn--sm" data-gopanel="nutrition">Nutrition</button>') + '</div>';
      q.innerHTML = '<div class="card__head"><h4>Coach update</h4><span class="tag">Personal</span></div>' +
        (memberNote ? '<p style="margin:0 0 12px;font-size:.9rem;line-height:1.5">' + escHTML(memberNote).replace(/\n/g,'<br>') + '</p>' : '') + progressHtml + quickLinks;
    } else {
      q.innerHTML = '<div class="card__head"><h4>This week</h4><span class="tag">Coach note</span></div>' +
        ((m && met.expired)
          ? '<p style="margin:0 0 14px;font-size:.9rem;line-height:1.5">Your plan is paused until renewal. Keep moving: 30 minutes of walking and shadow boxing three times this week.</p>' +
            '<div style="display:flex;gap:8px;flex-wrap:wrap"><a href="#plans" class="btn btn--ink btn--sm">See abonnements</a></div>'
          : isMember
          ? '<p style="margin:0 0 14px;font-size:.9rem;line-height:1.5">' + weeklyNote(m) + '</p>' +
            '<div style="display:flex;gap:8px;flex-wrap:wrap"><button class="btn btn--ink btn--sm" data-gopanel="program">Open plan</button>' +
            '<button class="btn btn--ghost btn--sm" data-gopanel="nutrition">Nutrition</button></div>'
          : '<p style="margin:0 0 14px;font-size:.9rem;line-height:1.5">No plan yet — the monthly program is written for your goal after you subscribe.</p>' +
            '<button class="btn btn--ink btn--sm" data-scrollplans>Unlock my plan</button>');
    }

    renderProgram();
    renderNutritionPanel();
    renderSessions();
    renderBilling();
  }

  function weeklyNote(m) {
    var notes = [
      'Focus week: keep your guard high after every combination. Rounds are short — quality over speed.',
      'Focus week: breathe out on every punch. Two extra conditioning rounds at the end of session 2.',
      'Focus week: footwork first. If your feet are late, your hands are late.',
      'Focus week: sleep is part of the program. 8 hours, and log your weight on Wednesday.'
    ];
    return notes[Math.floor(Date.now() / DAY) % notes.length];
  }

  /* schedule derived from membership start */
  function slotList() {
    var m = state.membership;
    if (!m) return [];
    var out = [];
    var start = new Date(m.start + 'T00:00:00');
    var total = m.sessionsTotal;
    var titles = ['Private boxing', 'Strength & conditioning', 'Cardio boxing', 'Technique + pads'];
    var times = ['18:30 – 19:30', '07:00 – 08:00', '19:00 – 20:00', '18:00 – 19:00'];
    var stepDays = Math.max(2, Math.floor(27 / Math.max(1, total)));
    for (var i = 0; i < total; i++) {
      var d = new Date(start.getTime() + (2 + i * stepDays) * DAY);
      out.push({
        i: i,
        date: d,
        dayNum: pad(d.getDate()),
        mon: d.toLocaleDateString('en-GB', { month: 'short' }),
        title: titles[i % titles.length],
        time: times[i % times.length],
        where: m.mode === 'group' ? 'Club class · studio' : '1:1 · studio',
        done: i < m.sessionsUsed
      });
    }
    return out;
  }
  function nextSlot() {
    var list = slotList();
    for (var i = 0; i < list.length; i++) if (!list[i].done) return list[i];
    return null;
  }

  /* ---- program panel ---- */
  function renderProgram() {
    var el = $('#panel-program');
    var m = state.membership;
    var met = membershipeMetrics(m);
    if (!m) {
      el.innerHTML = emptyPanel('🔒', 'Training plan locked', 'The program of the month is written for your goal and your sessions. Subscribe or preview as a member to see it.', 'See the abonnements');
      return;
    }
    var view = m.memberView || {};
    var visibility = view.visibility || {};
    if (state.remoteMember && visibility.showProgram === false) { el.innerHTML = '<div class="card dash-empty"><h3>Program not shared yet</h3><p>Your coach has not enabled this section for your member space.</p></div>'; return; }
    var pub = published && published[m.goal];
    var custom = String(view.programText || '').trim();
    var prog = custom ? toProgWeeks({weeks:[{title:view.programMonth || 'Your individual plan',body:custom}]}) : ((pub && pub.weeks && pub.weeks.length) ? toProgWeeks(pub) : (PROGRAM[m.goal] || PROGRAM['Fat loss']));
    var monthLabel = view.programMonth || ((pub && pub.month) ? pub.month : fmtDate(m.start).slice(3));
    var remaining = met.expired ? 0 : met.daysLeft;
    el.innerHTML =
      '<div style="display:flex;justify-content:space-between;gap:14px;flex-wrap:wrap;align-items:flex-end;margin-bottom:16px">' +
        '<div><div class="eyebrow" style="margin-bottom:8px">' + escHTML(m.goal) + ' · ' + m.sessionsTotal + ' sessions / month</div>' +
        '<h3 style="font-size:1.25rem">Program · ' + escHTML(monthLabel) + '</h3></div>' +
        '<span class="chip">' + (met.expired ? 'Expired — renew to continue' : remaining + ' days in this block') + '</span>' +
      '</div>' +
      prog.map(function (w, i) {
        var open = i === Math.min(3, Math.floor((4 - Math.min(3, Math.ceil(remaining / 7))) || 0)) ? ' is-open' : '';
        return '<div class="prog-week' + open + '">' +
          '<button class="prog-week__head" data-week>' +
            '<span class="prog-week__n">0' + (i + 1) + '</span>' +
            '<span class="prog-week__t"><b>' + escHTML(w.w) + ' — ' + w.blocks.length + ' sessions</b><small>' + escHTML(w.sub) + '</small></span>' +
            '<span class="prog-week__chev">▾</span>' +
          '</button>' +
          '<div class="prog-week__body">' +
            w.blocks.map(function (b) {
              return '<div class="block-row"><div class="k">' + escHTML(b.k) + '</div><div><b>' + escHTML(b.b) + '</b><span>' + escHTML(b.s) + '</span></div></div>';
            }).join('') +
            '<div style="margin-top:14px"><button class="btn btn--ghost btn--sm" data-wa>Send feedback to coach</button></div>' +
          '</div>' +
        '</div>';
      }).join('') +
      '<div class="mini-note"><span>✳</span><span><b>How to use it:</b> tick each session when you finish. Your session counter above updates automatically, and the coach reviews your week every Sunday.</span></div>';
  }

  function pctOf(v, target) {
    if (!target) return 0;
    return Math.max(0, Math.min(100, Math.round(v / target * 100)));
  }

  /* ---- nutrition panel ---- */
  function renderNutritionPanel() {
    var el = $('#panel-nutrition');
    var m = state.membership;
    if (!m) {
      el.innerHTML = emptyPanel('🔒', 'Nutrition locked', 'Members get a meal structure and macro targets built on the food they actually eat. Subscribe to unlock it.', 'See the abonnements');
      return;
    }
    var view = m.memberView || {}, visibility = view.visibility || {};
    if (state.remoteMember && visibility.showNutrition === false) { el.innerHTML = '<div class="card dash-empty"><h3>Nutrition not shared</h3><p>Your coach has not enabled this section for your member space.</p></div>'; return; }
    var targets = view.nutrition || {};
    var base = +targets.kcal || ({ 'Fat loss': 1900, 'Muscle gain': 2750, 'Boxing skills': 2350, 'Cardio / fitness': 2100, 'Competition prep': 2500 }[m.goal] || 2100);
    var p = +targets.protein || Math.round(base * 0.32 / 4), c = +targets.carbs || Math.round(base * 0.42 / 4), f = +targets.fat || Math.round(base * 0.26 / 9);
    var meals = MEALS[m.goal] || MEALS['Fat loss'];
    var eaten = 0;
    var savedEaten = JSON.parse(lsGet(memberStorageKey('meals'), '[]'));
    function ring(pct, color) {
      var cir = 2 * Math.PI * 30;
      return '<div class="mr__ring"><svg viewBox="0 0 78 78">' +
        '<circle class="t" cx="39" cy="39" r="30"/>' +
        '<circle class="b" cx="39" cy="39" r="30" stroke="' + color + '" stroke-dasharray="' + cir.toFixed(1) + '" stroke-dashoffset="' + (cir * (1 - pct / 100)).toFixed(1) + '"/></svg>' +
        '<div class="mr__in">' + Math.round(pct) + '%</div></div>';
    }
    el.innerHTML =
      '<div class="dash__grid">' +
        '<div class="card">' +
          '<div class="card__head"><h4>Targets · ' + m.goal + '</h4><span class="tag">' + base + ' kcal</span></div>' +
          '<div class="macro-rings">' +
            '<div class="mr">' + ring(pctOf(eaten, p * 4), '#C05B33') + '<small>Protein ' + p + ' g</small></div>' +
            '<div class="mr">' + ring(pctOf(eaten, c * 4), '#6F7A4B') + '<small>Carbs ' + c + ' g</small></div>' +
            '<div class="mr">' + ring(pctOf(eaten, f * 9), '#E4A02C') + '<small>Fat ' + f + ' g</small></div>' +
          '</div>' +
          '<div style="margin-top:16px">' +
            meals.map(function (meal, i) {
              var on = savedEaten.indexOf(i) > -1;
              if (on) eaten += meal.k;
              return '<div class="meal-row' + (on ? ' is-on' : '') + '">' +
                '<span class="ic">' + meal.ic + '</span>' +
                '<span><b>' + meal.n + '</b><small>' + meal.d + '</small></span>' +
                '<span style="display:flex;align-items:center;gap:10px"><span class="kc">' + (meal.k ? meal.k + ' kcal' : '—') + '</span>' +
                '<button class="meal-check' + (on ? ' is-on' : '') + '" data-meal="' + i + '">✓</button></span>' +
              '</div>';
            }).join('') +
          '</div>' +
          '<div class="mini-note"><span>✳</span><span><b>' + eaten + ' / ' + base + ' kcal</b> logged today · ' +
            (eaten >= base ? 'target reached, well done.' : Math.round((base - eaten) / 10) * 10 + ' kcal left · about ' + Math.max(1, Math.round((base - eaten) / 550)) + ' meal(s).') +
          '</span></div>' +
        '</div>' +
        '<div style="display:grid;gap:18px">' +
          '<div class="card card--clay">' +
            '<div class="card__head"><h4>Water</h4><span class="tag">35 ml / kg</span></div>' +
            '<div class="water" id="waterWrap">' +
              Array.apply(null, Array(8)).map(function (_, i) {
                var won = +(lsGet(memberStorageKey('water'), '0'));
                return '<button data-water="' + i + '" class="' + (i < won ? 'is-on' : '') + '" aria-label="Glass ' + (i + 1) + '"></button>';
              }).join('') +
            '</div>' +
            '<p style="margin:12px 0 0;font-size:.8rem;color:#7A4A22">Tap a glass each time you drink 250 ml. Aim for 8 on training days.</p>' +
          '</div>' +
          '<div class="card">' +
            '<div class="card__head"><h4>Coach&#39;s rules</h4></div>' +
            '<ul style="margin:0;padding-left:16px;font-size:.84rem;color:#3E493E;line-height:1.7">' +
              '<li>Protein at every meal — palm-sized portion.</li>' +
              '<li>Carbs around training, less at night.</li>' +
              '<li>One free meal per week, planned, not accidental.</li>' +
              '<li>Send photos of your plate on Sunday for feedback.</li>' +
            '</ul>' +
          '</div>' +
          '<button class="btn btn--ghost btn--block" data-wa>Request a nutrition update</button>' +
        '</div>' +
      '</div>';
  }

  /* ---- sessions panel ---- */
  function renderSessions() {
    var el = $('#panel-sessions');
    var m = state.membership;
    if (state.remoteMember && m && m.memberView && m.memberView.visibility && m.memberView.visibility.showSessions === false) { el.innerHTML = '<div class="card dash-empty"><h3>Sessions not shared</h3><p>Your coach has hidden this section from your member space.</p></div>'; return; }
    if (!m) {
      el.innerHTML = emptyPanel('🔒', 'No sessions yet', 'Your booked slots, check-ins and history live here once your abonnement is active.', 'See the abonnements');
      return;
    }
    var list = slotList();
    var met = membershipeMetrics(m);
    el.innerHTML =
      '<div style="display:flex;justify-content:space-between;gap:14px;flex-wrap:wrap;align-items:flex-end;margin-bottom:16px">' +
        '<div><div class="eyebrow" style="margin-bottom:8px">' + (m.mode === 'private' ? 'Private 1:1' : 'Club class') + ' · ' + escHTML(m.planName || (findPlan(m.planId) || {}).name || 'Abonnement') + '</div>' +
        '<h3 style="font-size:1.25rem">' + met.sessionsLeft + ' sessions left this month</h3></div>' +
        '<div style="display:flex;gap:8px"><span class="chip">' + m.sessionsUsed + ' done</span><span class="chip">' + met.daysLeft + ' days left</span></div>' +
      '</div>' +
      (siteOps && siteOps.bookingsEnabled !== true ? '<div class="mini-note"><span>!</span><span><b>Sample schedule only — these are not booked appointments.</b> Contact your coach to arrange or reschedule a session.</span></div>' : '') +
      '<div class="session-list">' +
        list.map(function (s) {
          return '<div class="session-item' + (s.done ? ' is-done' : '') + '">' +
            '<div class="si__day">' + pad(s.date.getDate()) + '<br>' + s.mon + '</div>' +
            '<div><div class="si__title">' + s.title + '</div><div class="si__meta">' + s.time + ' · ' + s.where + '</div></div>' +
            '<button class="si__check" data-check="' + s.i + '" aria-label="Mark done">✓</button>' +
          '</div>';
        }).join('') +
      '</div>' +
      '<div class="mini-note"><span>✳</span><span><b>Rules:</b> free cancellation up to 6 h before. Missed sessions without notice are counted as used.</span></div>' +
      '<div style="margin-top:16px;display:flex;gap:8px;flex-wrap:wrap">' +
        '<button class="btn btn--ink btn--sm" data-wa>Reschedule with coach</button>' +
        '<button class="btn btn--ghost btn--sm" data-gopanel="program">View program</button>' +
      '</div>';
  }

  /* ---- billing panel ---- */
  function renderBilling() {
    var el = $('#panel-billing');
    var m = state.membership;
    if (state.remoteMember && m && m.memberView && m.memberView.visibility && m.memberView.visibility.showBilling === false) { el.innerHTML = '<div class="card dash-empty"><h3>Billing details hidden</h3><p>Contact the coach if you need a copy of your subscription information.</p></div>'; return; }
    if (!m) {
      el.innerHTML = emptyPanel('🧾', 'No billing record yet', 'Your coach records confirmed payments and membership dates here. Cash is arranged in person; D17 online integration is in progress. Contact Kilani to enrol.', 'See the abonnements');
      return;
    }
    var met = membershipeMetrics(m);
    var payLabel = 'Coach-recorded';
    el.innerHTML =
      '<div class="dash__grid">' +
        '<div class="card">' +
          '<div class="card__head"><h4>Payments</h4><span class="tag">' + (met.expired ? 'Renewal due' : 'Up to date') + '</span></div>' +
          '<div class="table-wrap"><table class="receipts"><thead><tr><th>Date</th><th>Formula</th><th>Method</th><th>Amount</th><th>Status</th></tr></thead><tbody>' +
            '<tr><td>' + fmtDate(m.start) + '</td><td>' + escHTML(m.planName || (findPlan(m.planId) || {}).name || 'Abonnement') + '</td><td>' + escHTML(payLabel) + '</td><td><b>' + dt(m.price) + '</b></td><td><span class="badge-paid">' + (m.paid === false ? 'Due' : 'Paid') + '</span></td></tr>' +
            (m.start !== todayISO() ? '<tr><td>' + fmtDate(m.end) + '</td><td>Membership expiry</td><td>—</td><td>' + dt(m.price) + '</td><td>' + (met.expired ? '<span class="badge-paid" style="background:#F7E3D4;color:#96411F">Renewal due</span>' : '<span class="badge-paid" style="background:#F1EBDD;color:#6B7566">Contact coach</span>') + '</td></tr>' : '') +
          '</tbody></table></div>' +
          '<div style="margin-top:16px;display:flex;gap:8px;flex-wrap:wrap">' +
            (state.remoteMember
              ? '<button class="btn btn--ghost btn--sm" data-wa>Ask coach about billing</button>'
              : '<button class="btn btn--ghost btn--sm" data-invoice>Invoice preview (demo)</button><button class="btn btn--ghost btn--sm" data-pause>Pause request (demo)</button>') +
          '</div>' +
          '<div class="mini-note"><span>✳</span><span>Payment records are maintained by the coach. No automatic payment or card details are stored in this site.</span></div>' +
        '</div>' +
        '<div style="display:grid;gap:18px">' +
          '<div class="card card--forest">' +
            '<div class="card__head"><h4>Membership status</h4></div>' +
            '<div class="co__total" style="margin:0"><div><small>Expiry date</small><div style="font-size:1.1rem;font-family:var(--font-display);margin-top:4px">' + fmtDate(m.end) + '</div></div><b>' + dt(m.price) + '<small style="display:block;font-size:.62rem;opacity:.7">monthly rate</small></b></div>' +
            '<div class="mini-note" style="color:rgba(242,237,225,.6)"><span>✳</span><span>' + (met.expired ? 'Your membership has expired. Contact the coach to confirm renewal.' : met.daysLeft + ' days remaining. This site does not charge automatically; contact Kilani about renewal.') + '</span></div>' +
            '<div style="margin-top:14px">' + (state.remoteMember ? '<button class="btn btn--saffron btn--sm btn--block" data-wa>Ask coach about renewal</button>' : '<button class="btn btn--saffron btn--sm btn--block" data-renew>Renewal preview (demo)</button>') + '</div>' +
          '</div>' +
          '<div class="card">' +
            '<div class="card__head"><h4>Payment details</h4></div>' +
            '<p class="muted" style="margin:0">Only cash in person and D17 are offered. Arrange cash payment with Kilani at the club; D17 online integration is in progress and is not live yet. No card numbers, CVV, bank details, or payment-method reference are stored here.</p>' +
          '</div>' +
          (state.remoteMember ? '' : '<button class="btn btn--ghost btn--block" data-reset>Reset demo data</button>') +
        '</div>' +
      '</div>';
  }

  /* --------------------------------------------------------- demo member */
  function demoMember() {
    var p = findPlan('p8');
    var startD = new Date(Date.now() - 12 * DAY);
    var start = startD.getFullYear() + '-' + pad(startD.getMonth() + 1) + '-' + pad(startD.getDate());
    state.membership = {
      name: 'Yassine Trabelsi',
      phone: '94 077 310',
      goal: 'Fat loss',
      planId: p.id,
      planName: p.name,
      mode: 'private',
      sessionsTotal: p.sessions,
      sessionsUsed: 3,
      addons: ['nutri'],
      price: p.price + 40,
      start: start,
      end: addMonth(start),
      startedAt: Date.now()
    };
    save();
    renderMember();
    toast('Demo member loaded — 12 days into the month.');
  }

  /* ---------------------------------------------------------------- bind */
  function bind() {
    $('#memberAccessSubmit').addEventListener('click', function () { loginMember($('#memberAccessCode').value.trim()); });
    $('#memberAccessCode').addEventListener('keydown', function(e){ if(e.key==='Enter'){ e.preventDefault(); loginMember($('#memberAccessCode').value.trim()); } });
    $('#memberAccessLogout').addEventListener('click', logoutMember);

    /* nav */
    var nav = $('#nav');
    var onScroll = function () { nav.classList.toggle('is-stuck', window.scrollY > 8); };
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();

    var mm = $('#mobileMenu');
    $('#burger').addEventListener('click', function () { mm.classList.toggle('is-open'); });
    $$('#mobileMenu a').forEach(function (a) {
      a.addEventListener('click', function () { mm.classList.remove('is-open'); });
    });
    $('#navStatus').addEventListener('click', function () {
      document.getElementById('dashboard').scrollIntoView({ behavior: 'smooth' });
    });

    /* plan tabs */
    $$('.plans__toggle button').forEach(function (b) {
      b.addEventListener('click', function () {
        state.mode = b.getAttribute('data-mode');
        $$('.plans__toggle button').forEach(function (x) {
          x.classList.toggle('is-active', x === b);
          x.setAttribute('aria-selected', x === b ? 'true' : 'false');
        });
        renderPlans();
      });
    });

    /* delegated clicks */
    document.addEventListener('click', function (e) {
      var t = e.target.closest('[data-buy],[data-pick],[data-add],[data-next],[data-back],[data-close],[data-finish],[data-gopanel],[data-check],[data-week],[data-meal],[data-water],[data-reset],[data-demo],[data-scrollplans],[data-wa],[data-invoice],[data-pause],[data-renew],[data-paysubmit]');
      if (!t) return;

      if (t.hasAttribute('data-buy')) {
        if (state.remoteMember) { toast('Your coach manages this abonnement — message him to change it.'); return; }
        var pid = t.getAttribute('data-buy');
        var found = findPlan(pid);
        if (!found) return;
        if (!siteOps || siteOps.paymentsEnabled !== true) {
          var cashMessage = 'Hi Kilani, I am interested in ' + found.name + ' (' + found.price + ' DT/month). I would like to arrange cash payment in person at the club.';
          window.location.href = 'https://wa.me/21694077310?text=' + encodeURIComponent(cashMessage);
          return;
        }
        state.mode = PLANS.private.indexOf(found) > -1 ? 'private' : 'group';
        openCheckout(pid);
        return;
      }
      if (t.hasAttribute('data-pick')) {
        co.planId = t.getAttribute('data-pick');
        renderCheckout();
        return;
      }
      if (t.hasAttribute('data-add')) {
        var id = t.getAttribute('data-add');
        var ix = co.addons.indexOf(id);
        if (ix > -1) co.addons.splice(ix, 1); else co.addons.push(id);
        renderCheckout();
        return;
      }
      if (t.hasAttribute('data-next')) {
        var n = +t.getAttribute('data-next');
        if (n === 3) {
          var ok = ($('#coName').value || '').trim().length > 1 && ($('#coPhone').value || '').trim().length > 5;
          $('#errStep2').classList.toggle('is-on', !ok);
          if (!ok) return;
        }
        co.step = n;
        renderCheckout();
        return;
      }
      if (t.hasAttribute('data-back')) { co.step = +t.getAttribute('data-back'); renderCheckout(); return; }
      if (t.hasAttribute('data-close')) { closeCheckout(); return; }
      if (t.hasAttribute('data-paysubmit')) { activate(); return; }
      if (t.hasAttribute('data-finish')) {
        closeCheckout();
        document.getElementById('dashboard').scrollIntoView({ behavior: 'smooth' });
        return;
      }
      if (t.hasAttribute('data-gopanel')) {
        var pn = t.getAttribute('data-gopanel');
        $$('#dashTabs button').forEach(function (b) { b.classList.toggle('is-active', b.getAttribute('data-panel') === pn); });
        $$('.panel').forEach(function (p) { p.classList.toggle('is-active', p.id === 'panel-' + pn); });
        return;
      }
      if (t.hasAttribute('data-scrollplans')) {
        document.getElementById('plans').scrollIntoView({ behavior: 'smooth' });
        return;
      }
      if (t.hasAttribute('data-week')) {
        t.parentElement.classList.toggle('is-open');
        return;
      }
      if (t.hasAttribute('data-check')) {
        var m = state.membership;
        if (!m) return;
        var idx = +t.getAttribute('data-check');
        m.sessionsUsed = idx < m.sessionsUsed ? idx : idx + 1;
        save();
        renderMember();
        toast(m.sessionsUsed >= m.sessionsTotal ? 'All sessions used — renew to keep training.' : 'Session logged. ' + (m.sessionsTotal - m.sessionsUsed) + ' left this month.');
        return;
      }
      if (t.hasAttribute('data-meal')) {
        var mi = +t.getAttribute('data-meal');
        var arr = JSON.parse(lsGet(memberStorageKey('meals'), '[]'));
        var pos = arr.indexOf(mi);
        if (pos > -1) arr.splice(pos, 1); else arr.push(mi);
        lsSet(memberStorageKey('meals'), JSON.stringify(arr));
        renderNutritionPanel();
        return;
      }
      if (t.hasAttribute('data-water')) {
        var wi = +t.getAttribute('data-water');
        var won = +(lsGet(memberStorageKey('water'), '0'));
        lsSet(memberStorageKey('water'), String(wi + 1 === won ? wi : wi + 1));
        renderNutritionPanel();
        return;
      }
      if (t.hasAttribute('data-reset')) {
        if (state.remoteMember) { logoutMember(); return; }
        state.membership = null;
        lsDel(KEY);
        lsDel(memberStorageKey('meals'));
        lsDel(memberStorageKey('water'));
        renderMember();
        toast('Demo reset — dashboard locked again.');
        return;
      }
      if (t.hasAttribute('data-demo')) { demoMember(); return; }
      if (t.hasAttribute('data-wa')) { toast('Demo: this would open WhatsApp with coach_kilani_.'); return; }
      if (t.hasAttribute('data-invoice')) { toast('Demo: invoice PDF would download here.'); return; }
      if (t.hasAttribute('data-pause')) { toast('Demo: pause request sent to the coach (max 15 days).'); return; }
      if (t.hasAttribute('data-renew')) {
        if (state.remoteMember) { toast('Your coach manages renewals — message him to continue.'); return; }
        var m2 = state.membership;
        if (!m2) return;
        var newStart = todayISO();
        m2.start = newStart;
        m2.end = addMonth(newStart);
        m2.sessionsUsed = 0;
        save(); renderMember();
        toast('Month renewed from today — ' + m2.sessionsTotal + ' sessions and 30 days on the clock.');
        return;
      }
    });

    /* poster lightbox */
    var lb = $('#lightbox'), lbImg = $('#lightboxImg');
    document.addEventListener('click', function (e) {
      var opener = e.target.closest('[data-poster]');
      if (opener) {
        var im = opener.querySelector('img');
        lbImg.src = im ? im.src : opener.getAttribute('data-poster');
        lbImg.alt = im ? im.alt : 'Club poster';
        lb.classList.add('is-open');
        lb.setAttribute('aria-hidden', 'false');
        document.body.classList.add('no-scroll');
        return;
      }
      if (e.target.closest('[data-lbclose]') || e.target === lb) {
        lb.classList.remove('is-open');
        lb.setAttribute('aria-hidden', 'true');
        document.body.classList.remove('no-scroll');
      }
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && lb.classList.contains('is-open')) {
        lb.classList.remove('is-open');
        document.body.classList.remove('no-scroll');
      }
    });

    /* dashboard tabs */
    $('#dashTabs').addEventListener('click', function (e) {
      var b = e.target.closest('button[data-panel]');
      if (!b) return;
      $$('#dashTabs button').forEach(function (x) { x.classList.toggle('is-active', x === b); });
      $$('.panel').forEach(function (p) { p.classList.toggle('is-active', p.id === 'panel-' + b.getAttribute('data-panel')); });
    });

    /* checkout modal escape */
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && $('#checkout').classList.contains('is-open')) closeCheckout();
    });

    /* checkout live updates */
    ['coStart', 'coName', 'coPhone'].forEach(function (id) {
      var el = document.getElementById(id);
      if (el) el.addEventListener('input', function () { if (co.step < 4) renderCheckout(); });
    });

    /* faq */
    $$('.faq__item').forEach(function (item) {
      var q = $('.faq__q', item), a = $('.faq__a', item);
      q.addEventListener('click', function () {
        var open = item.classList.contains('is-open');
        $$('.faq__item').forEach(function (o) {
          o.classList.remove('is-open');
          $('.faq__a', o).style.maxHeight = '0px';
        });
        if (!open) {
          item.classList.add('is-open');
          a.style.maxHeight = a.scrollHeight + 'px';
        }
      });
    });

    /* trial form */
    var tf = $('#trialForm');
    if (tf) tf.addEventListener('submit', function (e) {
      e.preventDefault();
      toast('Request received, ' + ($('#fName').value || 'champ') + '. The coach replies within 24 h (demo).');
      tf.reset();
    });

    /* macro calculator */
    function calcMacros() {
      var sex = $('#cSex').value, age = +$('#cAge').value || 28;
      var w = +$('#cW').value || 78, h = +$('#cH').value || 178;
      var act = +$('#cAct').value, goal = +$('#cGoal').value;
      var bmr = 10 * w + 6.25 * h - 5 * age + (sex === 'm' ? 5 : -161);
      var tdee = bmr * act;
      var kcal = Math.round((tdee * (1 + goal)) / 10) * 10;
      var protein = Math.round((w * (goal > 0 ? 2.0 : 2.2)) / 5) * 5;
      var fat = Math.round((kcal * 0.27) / 9 / 5) * 5;
      var carbs = Math.round((kcal - protein * 4 - fat * 9) / 4 / 5) * 5;
      $('#oKcal').textContent = kcal;
      $('#oP').textContent = protein;
      $('#oC').textContent = Math.max(0, carbs);
      $('#oF').textContent = fat;
    }
    ['cSex', 'cAge', 'cW', 'cH', 'cAct', 'cGoal'].forEach(function (id) {
      var el = document.getElementById(id);
      if (el) el.addEventListener('input', calcMacros);
    });
    if ($('#cSex')) calcMacros();

    /* hide floating credit when the footer credit is on screen */
    var credit = document.getElementById('credit');
    var fb = document.querySelector('.footer__bottom');
    if (credit && fb && 'IntersectionObserver' in window) {
      new IntersectionObserver(function (entries) {
        entries.forEach(function (en) { credit.classList.toggle('is-hidden', en.isIntersecting); });
      }, { threshold: .2 }).observe(fb);
    }

    /* reveal on scroll */
    if ('IntersectionObserver' in window) {
      var io = new IntersectionObserver(function (entries) {
        entries.forEach(function (en) {
          if (en.isIntersecting) { en.target.classList.add('is-in'); io.unobserve(en.target); }
        });
      }, { threshold: .12, rootMargin: '0px 0px -40px 0px' });
      $$('.rv').forEach(function (el) { io.observe(el); });
    } else {
      $$('.rv').forEach(function (el) { el.classList.add('is-in'); });
    }

    /* live countdown refresh every minute */
    setInterval(function () { if (state.membership) renderMember(); }, 60000);
  }

  /* ---------------------------------------------------------------- init */
  document.addEventListener('DOMContentLoaded', function () {
    $('#year').textContent = new Date().getFullYear();
    load();
    renderPlans();
    renderSchedule();
    bind();
    renderMember();
    loadPublishedPlans();
    loadSiteOps();
    loadRemoteMember();
  });
})();

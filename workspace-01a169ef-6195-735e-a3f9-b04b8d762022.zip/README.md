# KILANI — Boxing & Conditioning (demo website)

> Website made by **Iyed Omri** — Instagram [@iyver](https://instagram.com/iyver)

A self-contained website and coach dashboard for **Mohamed Ben Kilani** (@coach_kilani_, 2× Sahel Regional Champion) and his
**Boxing Club** in Ribat, Monastir — "Fight for Life". Private coaching plus boxe anglaise classes for **adultes, juniors and cadets**.

**The HTML pages are self-contained**, but use `server.py` with MySQL for real server-side coach access and shared admin data:

| File | For | Entry |
|---|---|---|
| `index.html` | the public website (clients) | `/` |
| `admin.html` | Kilani’s private coach dashboard | public footer → “Coach login” → server login |
| `owner.html` | Separate creator-only Owner Console | `/owner` → creator key or approved temporary grant |
| `server.py` | server-side auth, MySQL-backed private data and owner controls | `python3 server.py` |

A newly initialized **local** MySQL database uses the demo PIN **`16976614`** (8 digits); change it in **Settings → Access code** before public use. A Vercel deployment never seeds that demo PIN: when Vercel initializes an empty database it requires a private `COACH_INITIAL_PIN` environment variable, which should be removed after you change the PIN in Settings. If an existing `state.json` is imported in a local migration, its PIN hash is preserved. Opening `admin.html` directly as a file is only the offline demo gate (`1959`); it is not secure.

---

## What's inside

| Section | What it does |
|---|---|
| **Hero + coach** | Identity, stats from the profile (2× champion, 5.7K, 341 posts), Instagram + WhatsApp links |
| **Abonnements** | Private 1:1 and Group tabs, 3 formulas each, price per session, feature lists, add-ons |
| **Checkout & booking status** | Live checkout and booking are deliberately unavailable until a verified backend exists. No card-number or CVV fields are present. D17 is the intended provider, but merchant setup/API credentials and verified payment callbacks are still prerequisites. |
| **Member space** | Five tabs — **Overview, Training plan, Nutrition, Sessions, Billing**. Members can sign in with an individual code that Kilani creates in the dashboard. |
| **Monthly countdown** | Days remaining and expiry date stay in the navigation status line. The overview also shows the month ring, sessions used/left and renewal date when those details are enabled. |
| **Training plan** | 4-week program per goal (Fat loss, Muscle gain, Boxing skills, Cardio, Competition prep), expandable weeks, session blocks |
| **Nutrition** | Macro target rings, day's meals with check-off, water tracker, coach rules + public macro calculator |
| **Sessions** | Session tracking and schedule preview; live booking is not connected. Members contact the coach to arrange or reschedule. |
| **Billing** | Coach-maintained payment status/history and membership dates; no customer payment is processed by the site. |
| **The club** | His two real posters embedded from Instagram, click to enlarge in a lightbox |
| **Schedule** | The club's real class board — adultes Mar/Jeu 19h30 + Sam 18h00, juniors Mar/Jeu 18h15 + Sam 17h15, cadets Lun/Mer/Ven 18h15 |
| **Extras** | Class-group section, testimonials, FAQ, free-trial form, WhatsApp CTA |

## Coach dashboard (`admin.html`)

In server mode, `/admin.html` redirects to a separate login page; the dashboard HTML is not sent until the server verifies the code. The PIN is stored as a salted PBKDF2-HMAC-SHA256 hash; older salted SHA-256 hashes are upgraded after a successful login. The session uses an `HttpOnly`, `SameSite=Lax`, HMAC-signed cookie bound to the current PIN hash, so changing the PIN invalidates existing sessions. **5 wrong attempts → 60 s lockout**, an idle **15-minute auto-lock** logs out, and the server cookie expires after 12 hours. Clicking **Lock** logs out server-side too.

If you open `admin.html` as a static file, it falls back to the browser-only demo PIN gate. That fallback is for preview only, not access control.

What Kilani can do inside:

| Page | Actions |
|---|---|
| **Overview** | KPIs (active / expiring / sessions delivered / revenue), "action needed" list with one-tap WhatsApp + renew, today's classes, revenue chart, coach notes |
| **Members** | Search/filter the roster; track dates, formula, sessions, payments, measurements and coach-only notes. Set a private access code, log progress, and edit each member’s message, personal program, nutrition targets and visibility controls. |
| **Attendance** | Tick who showed up for a class; saving updates those members’ session counts. A member’s own check-in can update only their own record. |
| **Monthly plan** | Edit the 4-week program per goal and publish it to members who do not have a personal override. |
| **Offers** | Edit and publish the global private/group subscriptions and add-ons: names, prices, included sessions/features, descriptions and visibility. |
| **Payments** | Collected / outstanding / monthly average, payment table and manual payment records. |
| **Settings** | Change the access PIN, export JSON, reset demo data, lock. |

The coach's **roster, payments, private notes, progress history, personal member settings, published programs and offer catalog** are stored in MySQL and sync across devices. The server creates `kilani_app_state` (site-wide state), `kilani_member_access` (PBKDF2 access-code hashes), and `kilani_owner_control` (owner switches, approval requests and audit events). New member codes also have a keyed lookup digest so code-only login does not need to run PBKDF2 across every roster entry; the raw code is never stored. Older salted SHA-256/PBKDF2 hashes are verified and upgraded after a successful login. Raw member codes are shown to Kilani only when created/reset and are never included in public or coach-state API payloads. A member session can read and update only that member’s record; resetting their code also invalidates existing sessions. Hidden program/nutrition/message/progress/billing fields are omitted from that member’s API response, not merely hidden in the page. The public read-only endpoint serves only published plans and global offers—never roster records. The only payment methods shown are **cash in person** and **D17**; the plan CTA opens a WhatsApp enquiry to arrange cash payment with the coach at the club. The D17 integration is in progress and not live. Online checkout remains off; no card/CVV entry, charge, or simulated payment is provided. Merchant setup, official integration details, credentials, and verified callbacks still need to be completed. Payout details stay in the D17 merchant account.

## Creator Owner Console (`/owner`)

The Owner Console is a separate top-level area and is not part of Kilani’s normal member/coach workflow. Set a private `OWNER_ACCESS_KEY` of at least 32 bytes in the server environment (for example, generate a secret with `python3 -c 'import secrets; print(secrets.token_urlsafe(48))'`). Never commit it, include it in HTML, or reuse the coach PIN. Sign in at `/owner`; the server issues a separate HttpOnly owner cookie. Owner access can approve/deny Kilani’s scoped request, grant exactly 30 minutes, review the recent activity log, and revoke an active grant. Kilani requests **Change site controls** or **View D17 setup status** from Creator Controls in the coach Settings page; the request is tied to that coach session.

The owner switches separately control maintenance, payment pause, and booking pause. Maintenance leaves `/owner` and owner APIs accessible. Payment/booking switches do **not** activate an integration. The public checkout and live booking remain disabled because D17 is not connected; no card PAN, CVV, or full bank details are collected. Payout references/details remain in the provider-managed merchant portal. Owner state persists in MySQL (`kilani_owner_control`); the optional `STORAGE_BACKEND=file` mode is only for local demo/testing.

### Deploying this project to Vercel

The workspace now includes a Vercel adapter and deployment configuration, but **the site has not been deployed**. Vercel serves only `index.html` as a public static page. Coach/owner pages and `/api/*` are routed through the authenticated Python Function; do not change the output directory to the project root or publish `admin.html` as a static file. Vercel uses ephemeral function storage, so production state must be in remote MySQL—not `state.json`.

1. **Create a private GitHub repository** and push this project to it. Keep it private because the repository contains the coach/owner interface source and demo assets. The current workspace has no Git remote/repository yet.
2. **Provision a managed MySQL database** with TLS, backups, and a low-privilege application user. Prefer a Europe/Paris region near the Vercel Function region (`cdg1`). Make sure the provider allows outbound connections from Vercel or offers a serverless connection pooler; the app keeps only a small per-function pool.
3. In Vercel, choose **Add New → Project → Import Git Repository**, select the repository, set **Framework Preset: Other**, and keep the project Root Directory at the repository root. `vercel.json` supplies the build command, static output folder, rewrites and function region.
4. Before the first deployment, open **Project → Settings → Environment Variables** and add the production values below. Store all passwords/keys in Vercel, never in Git, the HTML, or chat. Use a separate staging database and secrets for Preview deployments.
5. Deploy a **Preview** first, then test the homepage, member login, coach login, owner access, and privacy checks. A logged-out request to `/admin.html` must redirect to `/login`; it must never return the dashboard. After successful checks, deploy the production branch.
6. Add the domain under **Project → Settings → Domains**, follow the DNS records Vercel displays, then retest the site and cookies over HTTPS.
7. Before accepting real traffic, enable Vercel Firewall/platform rate limits for `/login`, `/api/member/login`, and `/api/owner/login`; the app's in-memory lockout is only a per-function-instance safeguard. Confirm database backups and a restore procedure.

Required environment variables for Vercel:

| Variable | Value / purpose |
|---|---|
| `STORAGE_BACKEND` | `mysql` |
| `MYSQL_HOST`, `MYSQL_PORT`, `MYSQL_USER`, `MYSQL_PASSWORD`, `MYSQL_DATABASE` | Credentials for the managed MySQL database; keep the DB user least-privileged. |
| `MYSQL_POOL_SIZE` | Start with `2`; do not increase without checking the provider's connection limit. |
| `SESSION_SECRET` | A unique random value of at least 32 bytes, stable across deployments. |
| `MEMBER_CODE_PEPPER` | A different unique random value of at least 32 bytes; changing it later requires resetting member access codes. |
| `OWNER_ACCESS_KEY` | A third unique random value of at least 32 bytes if the Creator Owner Console is to be used. |
| `COACH_INITIAL_PIN` | A private 8–10 digit PIN, only needed if the production database is empty on first initialization. Change it in coach Settings, then remove this environment variable and redeploy. |
| `MYSQL_SSL_CA_PEM` | Only if the MySQL provider requires its custom CA certificate; otherwise leave unset. |

**Do not deploy the current files as an unconfigured static site.** If Vercel cannot see GitHub, the database, or environment variables, stop before production; the backend will not safely persist data or authenticate users. Checkout and bookings remain disabled; Cash is arranged in person and D17 remains not live.

### Server setup and security

The server uses **MySQL by default**. Create the database and application user with your hosting provider (the user needs `SELECT`, `INSERT`, `UPDATE`, `DELETE`, and `CREATE` privileges on that database; the app creates its tables, but does not create the database/user).

```bash
python3 -m pip install -r requirements.txt
cp .env.example .env
# Edit .env with the provider's real host, database name, username and password.
set -a; . ./.env; set +a
python3 build.py
python3 server.py          # serves on 0.0.0.0:8080 (override with PORT)
```

On the first connection, the server creates `kilani_app_state`, `kilani_member_access`, and `kilani_owner_control`. If the database has no state row and a legacy `state.json` exists, its roster, plans, offers, notes, PIN hash and member-code hashes are imported once; the original file is left untouched as a backup. No MySQL host or credentials are bundled in this project, so it cannot connect until you supply a MySQL instance and set the environment values. Keep `.env` private; it is ignored by Git. Remote MySQL requires certificate and hostname verification (optionally set `MYSQL_SSL_CA` to your provider's CA file); TLS may only be disabled for a loopback development database. Set stable private values for both `SESSION_SECRET` and `MEMBER_CODE_PEPPER` (each at least 32 bytes) when running multiple instances. Otherwise the server creates local `.session_secret` and `.member_code_pepper` files. Keep these files backed up and private: losing the member-code pepper requires resetting member access codes. Changing that pepper likewise requires resetting codes.

For an offline demo only, you can explicitly use the old JSON-file backend with `STORAGE_BACKEND=file python3 server.py`. That mode writes `state.json`; it is not MySQL and is not recommended for production. In MySQL mode, all member/admin edits are saved to the database.

**Important before deployment:** never use the local demo coach PIN `16976614` in production; protect DB credentials and signing keys, and keep private backups. For non-Vercel hosting, configure your HTTPS reverse proxy to overwrite `X-Forwarded-Proto`; set `TRUSTED_PROXY_IPS` only when that proxy also overwrites `X-Forwarded-For`. Standard Vercel deployments supply their own HTTPS/forwarded headers, and the Vercel-specific checklist above applies. POST APIs check Origin/Fetch Metadata and cap request bodies at 4 MiB. Production should include managed backups, monitoring, platform rate limiting, and MFA or stronger coach authentication. Static hosting of `admin.html` alone cannot provide server-side protection.

Run API, authentication and storage regression tests with `python3 -m unittest discover -s tests -v`. The tests use temporary file storage and pure MySQL configuration/serialization tests; they do not bind a listener or require a database server. A real MySQL connection/TLS integration test still requires your provider's credentials. See [`SECURITY.md`](SECURITY.md) for the audit scope, results, and remaining deployment actions.

### Try the demo in this order
1. On the public page, compare **Private** and **Group** formulas; checkout and live booking stay disabled. Use **Preview as member** to inspect the demo space.
2. For the protected portal, enter through **Coach login** and sign in with the server PIN. Choose an existing roster member (new clients must be added to the roster manually), open their record, then choose **Generate / reset access code** and share the displayed code with them.
3. Enter that code in the **My Space** sign-in panel on the public site. The member sees only their own profile; the countdown and expiry date remain visible.
4. In the member drawer, edit the individual program/nutrition/message, measurements, subscription dates/formula and visibility; **Save this member** publishes the settings.
5. In **Offers**, edit and publish the public subscription cards and add-ons. The public site lists only cash in person and D17 (integration in progress); D17 checkout remains off until merchant integration and verified payment callbacks are ready. For owner-level settings, configure `OWNER_ACCESS_KEY`, sign in at `/owner`, and approve Kilani’s exact-scope request only when needed; each grant lasts 30 minutes.

---

## Photos

All photos now come from his own Instagram (cropped out of screenshots, no AI people):

| File | Used for |
|---|---|
| `assets/coach-bag.webp` | Hero — heavy-bag shot from his profile photo |
| `assets/coach-ring.webp` | Coach section + class-groups section |
| `assets/avatar.webp` | Circular avatar in the member dashboard (masked circle) |
| `assets/poster-adults.webp` | Gallery — class schedule poster |
| `assets/poster-private.webp` | Gallery — private coaching poster |
| `assets/nutrition.webp` | Nutrition section (still AI — replace with his own food/meal photos) |

Full-resolution, uncropped posters are saved in `posters/` for print or social reuse.
Originals of the AI images remain in `assets/originals/`.

## Design

Deliberately **not** blue/black: bone paper `#F2EDE1`, deep forest `#1E2A22`, terracotta `#C05B33`,
saffron `#E4A02C`, olive accent + a little paper grain. Type pairing: heavy grotesque headings,
serif italic accents, clean sans body. Boxing references (sticker badge, tape label, ticket-style
plan cards) instead of generic dashboard blue.

---

## Editing

```
index.html          ← public site (generated, don't hand-edit)
admin.html          ← coach dashboard (generated; serve via server.py)
login.html          ← server login page (generated from src/login.html)
server.py           ← auth gate, session cookie, private API + shared state
api/index.py        ← Vercel Python Function adapter and secure rewrite-path restoration
vercel.json         ← Vercel routes, private function bundle and public output config
vercel_build.py     ← builds the Vercel output with only index.html public
.vercelignore       ← keeps local state, secrets and demo-only files out of Vercel uploads
state.json          ← private legacy/file-mode state; imported once into an empty MySQL store, never publish
.session_secret     ← local HMAC signing key when SESSION_SECRET is not configured
.member_code_pepper ← local keyed member-code lookup key; back up privately
.env.example        ← MySQL environment-variable template; copy to private .env
requirements.txt    ← MySQL Connector/Python dependency
build.py            ← rebuilds both pages + login.html from src/
src/styles.css      ← public site design tokens + styles
src/body.html       ← site structure & copy · {{IMG:name}} placeholders
src/app.js          ← public site logic, member portal and published-plan/offer reader
src/admin.css       ← dashboard-only styles
src/admin-body.html ← dashboard structure
src/admin.js        ← dashboard logic, individual member controls, offer editor + server-state sync
src/login.html      ← login page source
assets/*.webp       ← images (originals in assets/originals/)
```

After any edit in `src/`:

```bash
python3 build.py          # builds index.html + admin.html + login.html
```

**Where to change things (in `src/app.js`):**

- `PLANS` — formulas, prices (DT), sessions per month, feature lists. `private` and `group` arrays.
- `ADDONS` — nutrition / video review / start kit.
- `PROGRAM` — the monthly training plan per goal (weeks → sessions → exercises).
- `MEALS` — nutrition day template per goal.
- `SCHEDULE` — weekly group slots.
- Colours → `src/styles.css` `:root` variables.
- Coach details (WhatsApp 94 077 310, Instagram, gym = Boxing Club · Ribat, Monastir) → `src/body.html` (contact section + footer + FAQ).

---

## Demo vs. production

Working in this demo:

- **Coach login + shared admin data** — server-side PIN check, HttpOnly signed session, rate-limited login, and private shared MySQL state by default. An explicit JSON-file mode remains for offline demo/testing. The initial PIN is 8 digits; change it.
- **Published monthly programs + global offers** — Kilani can publish goal-based plans and edit subscription cards/add-ons; the public page reads only those public catalog values.
- **Member portal** — Kilani creates/resets an individual 8–10 digit code for a roster member. The member gets a seven-day HttpOnly session, can view only their own enabled sections, and can check in against their own session count. Access-code hashes, coach-only notes, and other members’ data are not returned to them.
- **Individual tracking** — subscription dates/formula, sessions, progress measurements, personal program, nutrition targets, member-visible message and per-section visibility are controlled in the member drawer. Coach-only progress notes remain private.
- **Public checkout** — deliberately unavailable; there is no simulated “paid” activation and no card-number/CVV entry. New clients are added to the roster by Kilani after enrolment is confirmed.
- **D17 payments** — intended provider, but no verified merchant account/API documentation, credentials, callback/webhook validation, or live payment has been set up. Payouts stay provider-managed. Keep customer checkout off until the official integration is completed and tested.
- **Live booking** — deliberately unavailable. The schedule is informational and coach/member session tracking is not a live reservation calendar.
- **Owner Console** — separate owner key, maintenance/payment/booking controls, auditable 30-minute creator-approved grants, and early API regression tests. Deploy with a unique `OWNER_ACCESS_KEY` and verified MySQL; do not use the offline demo for production.
- **Photos** — hero, coach, avatar and posters use his real Instagram photos/posters (cropped from screenshots). Ask him for original high-resolution files before print. The nutrition image is a food-photo placeholder, not a generated person.
- **Language** — the site is in English while his posters are French; a FR/EN switch would suit his audience.
- **Prices** — indicative only; confirm them with the coach.

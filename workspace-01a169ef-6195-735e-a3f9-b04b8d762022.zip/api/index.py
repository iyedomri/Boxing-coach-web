"""Vercel Function adapter for the existing authenticated HTTP handler.

Vercel rewrites protected-page and API paths to /api and passes the original
route in __vercel_route. The public homepage is the only generated HTML page
published as a static asset; coach and owner pages are bundled for this
function and remain behind server-side authorization.
"""
from __future__ import annotations

import pathlib
import sys
import urllib.parse

ROOT = pathlib.Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from server import Handler  # noqa: E402


def _restore_original_path(function_path: str) -> str:
    """Restore the user-facing path captured by a Vercel rewrite."""
    parsed = urllib.parse.urlsplit(function_path)
    params = urllib.parse.parse_qs(parsed.query, keep_blank_values=True)
    route_values = params.pop("__vercel_route", [])
    if not route_values:
        return function_path
    if len(route_values) != 1:
        return "/__invalid_vercel_route__"

    original = urllib.parse.urlsplit(route_values[0])
    if (
        original.scheme
        or original.netloc
        or original.fragment
        or not original.path.startswith("/")
        or original.path.startswith("//")
        or "\\" in original.path
    ):
        return "/__invalid_vercel_route__"

    original_query = urllib.parse.parse_qs(original.query, keep_blank_values=True)
    for key, values in params.items():
        original_query.setdefault(key, []).extend(values)
    query = urllib.parse.urlencode(original_query, doseq=True)
    return original.path + ("?" + query if query else "")


class handler(Handler):
    """Vercel's Python runtime instantiates this BaseHTTPRequestHandler class."""

    def _restore_route(self):
        self.path = _restore_original_path(self.path)

    def do_GET(self):
        self._restore_route()
        return super().do_GET()

    def do_POST(self):
        self._restore_route()
        return super().do_POST()
